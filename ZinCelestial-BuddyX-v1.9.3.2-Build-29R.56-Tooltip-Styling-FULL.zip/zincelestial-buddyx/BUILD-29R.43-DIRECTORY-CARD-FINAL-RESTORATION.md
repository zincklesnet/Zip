# Build 29R.43 Directory Card Final Restoration

- Version: 1.9.2.0
- Build: 29R.43
- Baseline: ZinCelestial-BuddyX-v1.9.1.9-Build-29R.42-Member-Group-Directory-Card-Restoration-FULL.zip
- Scope: complete desktop arrow removal and final member/group directory card restoration.
- Settings schema: version 1.
- Package: ZinCelestial-BuddyX-v1.9.2.0-Build-29R.43-Directory-Card-Final-Restoration-FULL.zip
