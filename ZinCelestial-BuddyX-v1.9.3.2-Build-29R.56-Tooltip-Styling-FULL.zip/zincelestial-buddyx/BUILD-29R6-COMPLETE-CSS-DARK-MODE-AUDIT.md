# Build 29R.6 Complete CSS and Dark-Mode Audit

## Scope

- Scanned every CSS file in the active theme package.
- Reviewed white and near-white literals, light-mode palettes, dark-mode selectors, widgets, cards, forms, notices, BuddyPress, bbPress, WooCommerce, tables, menus, profile surfaces, and Community Layout surfaces.
- Added a final coordinated color-scheme layer loaded after the retained design-system foundation.

## Corrections

- Darkened light-mode page, surface, raised, soft, border, muted-text, and link colors.
- Established dark-mode page, surface, raised, form, border, primary-text, muted-text, and link tokens.
- Forced common widget, card, activity, forum, commerce, table, notice, menu, profile, and Community Layout surfaces away from white in dark mode.
- Corrected text, link, placeholder, metadata, heading, form, and table contrast in dark mode.
- Preserved semantic status and accent colors outside the audited neutral surfaces.

## Static contrast calculations

| Pair | Foreground | Background | Ratio | WCAG AA normal text |
|---|---|---|---:|---|
| Light primary text | `#101827` | `#f2f4f8` | 16.13:1 | Pass |
| Light muted text | `#4b5870` | `#f2f4f8` | 6.51:1 | Pass |
| Light link | `#3f35a8` | `#f2f4f8` | 8.34:1 | Pass |
| Dark primary text | `#f4f7ff` | `#0d1422` | 17.18:1 | Pass |
| Dark muted text | `#b5c0d4` | `#0d1422` | 10.05:1 | Pass |
| Dark link | `#79ddff` | `#0d1422` | 11.93:1 | Pass |
| Dark input text | `#f4f7ff` | `#111b2c` | 16.1:1 | Pass |

## White-literal review

- White text on accent buttons and dark tooltips remains intentional.
- Administration preview samples may retain white because they are editor-only visual samples, not frontend dark-mode widgets.
- Frontend dark-mode widget and card surfaces are overridden by the final audited color-scheme layer.

## Limitations

- This is a static source and palette audit. A live rendered-site scan was not available in this environment.
- Plugin markup outside the included selectors may require an additional live-site selector pass if a third-party plugin outputs its own inline white backgrounds.
