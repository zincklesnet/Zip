# Build 29R.17 Layout Correction

## Baseline

- Theme: ZinCelestial-BuddyX
- Source: ZinCelestial-BuddyX-v1.8.9.3-Build-29R.16-Canonical-Directory-Panel-FULL
- Proposed version: 1.8.9.4
- Proposed build: 29R.17
- Settings schema: Version 1, unchanged

## Scope

- Match the News Feed center-column padding and activity structure to the member activity screen.
- Prevent the Members directory center and right columns from shifting right during scrolling.
- Apply the directory correction to full-width and boxed layouts.
- Place Member Command above Community signal in the canonical experience panel.

## Implementation

- Added a late-loading CSS correction layer instead of rewriting the protected design system.
- Neutralized the superseded calculated-width and negative-right-margin directory heading rule.
- Added shrink containment to grid tracks, member cards, widgets, media, and nested BuddyPress wrappers.
- Constrained activity media to the News Feed center column.
- Added DOM-order reconciliation for Member Command followed by Community signal.
- Retained a CSS order fallback for delayed or AJAX-rendered directory markup.

## Preservation Boundary

- Preserve Grid and Compact directory modes.
- Preserve signature member cards, achievement displays, sidebars, and widgets.
- Preserve light and dark modes.
- Preserve the existing administration settings page and saved zcbx_settings data.
- Preserve settings schema version 1.
- No Customizer expansion.
- No unrelated roadmap work.

## Files

- assets/zcbx-build-29r17-layout-correction.css
- assets/zcbx-build-29r17-layout-correction.js
- inc/build-29r17-layout-correction.php

## Integration

Load `inc/build-29r17-layout-correction.php` once from the existing theme bootstrap or functions.php.

## Static Checks Performed

- JavaScript syntax check passed.
- CSS opening and closing brace counts match.
- No database or settings migration introduced.

## Packaging Status

The correction assets and enqueue integration are complete. Final full-theme packaging requires the editable Build 29R.16 source tree.
