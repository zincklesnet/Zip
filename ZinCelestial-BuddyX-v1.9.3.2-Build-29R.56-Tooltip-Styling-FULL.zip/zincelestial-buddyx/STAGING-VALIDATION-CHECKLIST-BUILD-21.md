# Build 21 Staging Validation Checklist

## Static controls
- [x] Complete Build 20 package used as source.
- [x] Version and manifest advanced to Build 21.
- [x] Protected checksums retained.
- [x] Settings schema version 1 retained.
- [x] Customizer authority retained.
- [x] Platform asset separation retained.
- [x] Traceability, promotion, rollback, and triage controls added.
- [x] ZIP CRC and single-root checks passed.

## Live certification
- [ ] Install and activate without errors.
- [ ] PHP syntax checks pass.
- [ ] Visual evidence passes in both modes and all required viewports.
- [ ] Accessibility and reduced-motion evidence passes.
- [ ] Community, forum, commerce, marketplace, and extended-page checks pass.
- [ ] Rollback rehearsal passes.
- [ ] Every blocker is closed or the candidate is rejected.
- [ ] Explicit stable-promotion approval is recorded.

Decision: HOLD until all live gates pass.
