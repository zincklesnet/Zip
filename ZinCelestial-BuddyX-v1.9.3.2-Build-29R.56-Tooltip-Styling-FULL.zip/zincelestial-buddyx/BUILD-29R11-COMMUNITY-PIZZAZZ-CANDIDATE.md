# Build 29R.11 Community Pizzazz Candidate

## Structural correction
- Moves the Members heading above the live content/sidebar layout host at runtime.
- Makes the directory heading a true full-row element instead of using negative-margin compensation.

## Candidate visual systems
- Member Command Deck with grid and compact view controls.
- Community status ribbon.
- Signature member-card accent rails and hover/focus lift.
- Signature avatar rings.
- Achievement constellation wrapper for GamiPress and compatible reward output.
- Selective glass treatment on interactive command surfaces.
- Coordinated light/dark styling and reduced-motion fallback.

## Scope boundary
- Testable visual candidate only.
- No Customizer work, schema migration, saved-setting changes, or navigation assignment.
- Stage 4 Signature Icon Library remains the next official roadmap milestone.
