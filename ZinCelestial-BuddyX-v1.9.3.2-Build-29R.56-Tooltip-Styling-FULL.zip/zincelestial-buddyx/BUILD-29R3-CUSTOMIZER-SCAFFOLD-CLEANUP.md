# Build 29R.3 Customizer Scaffold Cleanup

## Source
- Reconstructed from Build 29R.1 with the approved Build 29R.2 removal boundary.
- Protected source baseline remains Build 28 v1.8.7.6.

## Removed
- ZinCelestial Community Experience Customizer registration, controls, sections, preview hooks, assets, registries, and documentation-only certification artifacts.
- Community Layout Customizer registration.
- `CommunitySettingsMigrator.php`.
- `CommunityMigrationSnapshot.php`.
- `NavigationInventory.php`.
- Passive Customizer ownership scaffold.

## Preserved
- Standard WordPress and BuddyX Customizer.
- ZinCelestial administration settings page.
- Existing `zcbx_settings` data and schema version 1.
- Frontend runtime and Community Layout shell behavior.
- Externalized skin component-library boundary.

## Next roadmap milestone
- Stage 4 Signature Icon Library planning and implementation.
