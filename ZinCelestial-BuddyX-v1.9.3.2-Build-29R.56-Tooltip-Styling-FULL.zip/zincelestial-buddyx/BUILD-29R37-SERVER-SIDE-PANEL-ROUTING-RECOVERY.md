# Build 29R.37 Server-Side Panel Routing Recovery

## Root cause corrected
Build 29R.36 depended on JavaScript finding panels through rendered form ancestry. The installed WordPress page did not provide the assumed direct-child relationship, so the panel list was empty. Every click failed validation and reverted to Dashboard. The server-rendered fallback also could not isolate panels reliably through that relationship.

## Recovery
- Added `zcbx-admin-panel` directly to every top-level administration panel.
- Main navigation now queries the explicit panel class without relying on form ancestry.
- Converted every icon navigation control into a real link with a validated `zcbx-panel` query parameter.
- Added server-side active-panel validation and server-rendered isolation.
- Navigation works through a normal page request even if administration JavaScript fails.
- JavaScript enhances links for immediate panel switching when available.
- Added inline important display and visibility updates during enhanced switching.
- Preserved independent nested Library tabs.

## Preserved
- Global `zcbx-field-row` structure and reference appearance.
- Unified Libraries, accessibility behavior, group/profile icons, saved settings, schema version 1, activity parity, and native BuddyX sidebars.
