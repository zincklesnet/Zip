# Build 23 Admin Renderer Correction

Replaced the concatenated HTML renderers in `inc/admin.php` with direct PHP/HTML templates.

Affected renderer fragments from Build 22:
- `zcbx_sel`: label, default value, select name, option value/state/name.
- `zcbx_on`: label, default state, checkbox name/state.
- `zcbx_range`: label, default/unit, range attributes/name/value, output value.
- `zcbx_color`: label, default value, color input name/value.
- `zcbx_media`: label, field name/value, preview image, select/remove button state.

The exact literal fragment `' . esc_html($label) . '` no longer exists in these renderers.
