# Build 29R.7 Live Directory Visual Correction

## Evidence
Correction scope was based on the uploaded live member-directory screenshot.

## Corrected
- Suppressed the separate desktop dropdown-toggle control that produced a second oversized arrow.
- Kept the site header sticky in document flow and offset below the WordPress toolbar.
- Added scroll clearance for fixed or sticky navigation.
- Standardized member-directory row and column gaps.
- Coordinated member-card surfaces, borders, shadows, cover areas, names, and action buttons.
- Removed the conflicting red action-button border.
- Gave the right sidebar a distinct coordinated surface and widget boundary.
- Added matching dark-mode card and sidebar surfaces without white fallbacks.

## Preserved
- Mobile menu behavior.
- Schema version 1.
- Community Layout runtime.
- Standard WordPress and BuddyX Customizer.
- Deferred ZinCelestial Community Experience Customizer decision.
