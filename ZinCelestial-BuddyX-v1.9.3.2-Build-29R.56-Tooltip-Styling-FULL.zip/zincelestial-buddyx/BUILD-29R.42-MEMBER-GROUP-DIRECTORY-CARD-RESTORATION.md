# Build 29R.42 Member and Group Directory Card Restoration

- Version: 1.9.1.9
- Build: 29R.42
- Protected baseline: ZinCelestial-BuddyX-v1.9.1.8-Build-29R.41-Member-Directory-Visual-Restoration-FULL.zip
- Scope: Member Directory cards, Group Directory cards, and oversized desktop submenu arrow removal only.
- Settings schema: version 1.
- Package: ZinCelestial-BuddyX-v1.9.1.9-Build-29R.42-Member-Group-Directory-Card-Restoration-FULL.zip
