# Build 29R.46 Member Identity and Signature View Controls

- Keeps the member username/name directly above GamiPress output.
- Repairs Grid and Compact view switching, including BuddyPress dynamic directory refreshes.
- Replaces text buttons with ZinCelestial Signature Icons.
- Adds accessible hover/focus names and descriptions.
- Preserves the Build 29R.45 card engine and all unrelated behavior.
