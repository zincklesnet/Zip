# Build 29R.49 Member Directory Runtime Stability

- Removes the recursive member-card mutation loop.
- Disconnects the observer during card normalization.
- Reconnects only after the bounded update completes.
- Debounces BuddyPress Ajax refresh handling.
- Moves identity only when the DOM order is actually incorrect.
- Removes only explicitly decorative line breaks.
