# Installation

Upload the full ZIP and replace `zincelestial-buddyx`. Validate the Customizer, frontend, settings, and diagnostics on staging.

Validate Community Layout Customizer save/reload and member/group frontend application on staging.
