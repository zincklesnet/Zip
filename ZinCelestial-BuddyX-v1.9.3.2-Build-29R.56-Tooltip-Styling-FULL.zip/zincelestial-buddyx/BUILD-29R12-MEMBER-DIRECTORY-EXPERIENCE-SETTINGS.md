# Build 29R.12 Member Directory Experience Settings

## Added to the existing administration page
- Enable Community Pizzazz.
- Default Grid or Compact view.
- Allow visitors to switch views.
- Remember visitor choice in browser local storage.
- Use Compact view on tablets by default.
- Enable Command Deck and status ribbon.
- Configure glass treatment.
- Enable Signature card accents and avatar rings.
- Configure accent intensity and hover movement.
- Enable achievement constellation and limit visible achievement groups.

## Architecture
- Uses existing `zcbx_settings`.
- Settings schema remains version 1.
- No Customizer implementation or migration.
