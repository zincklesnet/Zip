# Build 29R.25 Profile Menu Signature Icons

## Implemented
- Expanded the Signature Icon Registry with BuddyPress profile-navigation icons.
- Added a safe frontend payload and a defined profile-menu slug-to-icon map.
- Applied registry icons to Activity, Profile, Sites, Notifications, Messages, Friends, Groups, Forums, Settings, Points, and Ranks menu contexts.
- Preserved administrator-provided custom icon images as the highest-priority choice.
- Added mutation-safe handling for navigation rebuilt by existing runtime scripts.

## Preserved
- Existing profile menu ordering, visibility, labels, accessibility, and custom icon URL behavior.
- Shared Element, Component, and Signature Icon Libraries placement.
- News Feed activity parity, native BuddyX sidebars, saved settings, and schema version 1.
