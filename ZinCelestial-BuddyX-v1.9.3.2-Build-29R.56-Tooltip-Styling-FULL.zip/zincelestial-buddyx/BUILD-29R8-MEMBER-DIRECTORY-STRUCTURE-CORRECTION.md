# Build 29R.8 Member Directory Structure Correction

## Screenshot findings corrected
- Removed the split background and vertical seam behind the Members heading.
- Expanded the title surface across the available directory width and centered the heading.
- Removed inherited inner card gutters that inset the member cover area.
- Made the member cover/avatar region full width.
- Centered and consistently overlapped the avatar.
- Centered reward badges, member name, and activity text.
- Standardized card height, internal spacing, border, radius, and overflow.
- Added equivalent dark-mode title and avatar-border surfaces.

## Scope
Member-directory title and member cards only. No Customizer, schema, navigation, or Community Layout behavior changes.
