# VS-10 Component Token Mapping

| Component family | Primary semantic roles | Integration aliases | Mapping status |
|---|---|---|---|
| VS-2 Core controls | action, field, text, border, focus, disabled, status | WordPress controls, BuddyPress forms, bbPress forms, WooCommerce controls | mapped |
| VS-3 Feedback and communication | surface, text, border, success, warning, error, information, overlay | notices, messages, banners, tooltips, popovers | mapped |
| VS-4 Navigation and shells | canvas, surface, elevated surface, text, border, accent, focus | WordPress menus, BuddyPress navigation, account menus, side menus | mapped |
| VS-5 Cards, lists, tables, data | surface, elevated surface, text, muted text, border, accent, data states | activity, directory, inbox, table, statistics and calendar surfaces | mapped |
| VS-6 WordPress and community | core component mappings only | WordPress, BuddyPress and bbPress selectors | mapped |
| VS-7 Commerce and marketplaces | core component mappings plus commerce status roles | WooCommerce, WCFM, Dokan, WC Vendors, MultiVendorX and YITH aliases | mapped |
| VS-8 Extended pages | canvas, surface, text, border, accent, status | support, legal, recipes, aliases, businesses, galleries, polls and Community Experience | mapped |

## Mapping requirements

- `mapped` means the family has an approved semantic-role path. It does not mean visual certification is complete.
- Integration selectors may adapt structure, but visual values must resolve to the shared token system.
- Any component-specific token must identify its semantic fallback.
- Mapping exceptions must be entered in the token exception register before promotion.
