# Component Inventory

The uploaded-board element and component implementation was externalized from the active theme after Build 28.

- Active theme runtime: does not globally load the board-derived component layer.
- Reusable source: ZinCelestial Skin Component Library v1.0.0.
- Skin/template integrations must opt in explicitly.
- Historical Visual System records remain for project history only.
