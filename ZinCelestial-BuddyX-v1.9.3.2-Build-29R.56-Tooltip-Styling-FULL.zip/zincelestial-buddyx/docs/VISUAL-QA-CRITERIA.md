# VS-10 Visual QA Criteria

## Token certification

- Every certified component family has a recorded semantic token mapping.
- Integration aliases resolve to core semantic or component tokens.
- Hard-coded visual values are either removed or recorded in the exception register.
- Light and dark mode use coordinated semantic roles.
- State colors and focus presentation use shared accessibility-safe roles.
- Motion uses shared timing and reduced-motion rules.

## Visual certification

- Light and dark references exist at desktop, tablet, and mobile sizes.
- Normal, hover, focus, active, selected, loading, disabled, success, warning, and error states are covered where applicable.
- Keyboard order, visible focus, contrast, touch targets, overflow, zoom, reduced motion, and integration behavior pass.
- WordPress, BuddyPress, bbPress, WooCommerce, marketplace, and extended page workflows retain native ownership.

## Lock conditions

The visual QA lock remains closed when mappings are missing, exceptions are undocumented, evidence is missing, certification is blocked or not run, protected checksums fail, schema authority changes, or platform asset separation is violated.
