# WooCommerce Services

`Compatibility\WooCommerceServices` reports whether WooCommerce is available and exposes read-only capability flags for products, orders, customers, coupons, and account services. It performs no writes and registers no storefront components.
