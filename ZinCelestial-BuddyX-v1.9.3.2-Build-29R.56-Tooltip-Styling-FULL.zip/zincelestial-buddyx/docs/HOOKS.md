# Hooks

Project hooks use the `zcbx_` prefix. See source for registration and execution order.


## BuddyPress service actions

- `zcbx_buddypress_services_registered`
- `zcbx_buddypress_services_unavailable`


## WooCommerce service actions

- `zcbx_woocommerce_services_registered`
- `zcbx_woocommerce_services_unavailable`


## Dashboard widget actions

- `zcbx_dashboard_widget_registered`
- `zcbx_dashboard_widgets_registered`
