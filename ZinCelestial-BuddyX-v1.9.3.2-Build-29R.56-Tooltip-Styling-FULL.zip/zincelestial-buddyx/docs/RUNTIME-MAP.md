# Runtime Map

`platform.php` owns covers, backgrounds, widgets, subheader, and card images. `refinement-runtime.php` owns avatar frames and content surfaces. `save-engine.php` is protected.
