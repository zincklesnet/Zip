# System Diagnostics

Open Appearance > ZinCelestial > System Diagnostics. The panel is read-only.


v1.8.0 also exposes passive module and integration registry status in the diagnostics snapshot.


v1.8.1 adds read-only BuddyPress service and capability status to the diagnostics snapshot.


v1.8.2 adds read-only WooCommerce service and capability status to the diagnostics snapshot.


v1.8.3 adds read-only dashboard widget registry status to the diagnostics snapshot.
