# Service Registry

Core, Community, Platform, Settings, Compatibility, and Admin services are registered through the bootstrap.

## Community Experience scaffold
- Community\ExperiencePlatform
- Community\CustomizerOwnershipRegistry
- Community\CustomizerSettingsReader
- Community\CommunitySettingsMigrator
- Community\CommunityMigrationSnapshot
- Community\NavigationInventory
- Admin\CommunityExperiencePage

All v1.8.5 Community Experience services are passive or disabled for write operations.
