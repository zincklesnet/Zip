# Build 21 Defect Triage Policy

## Blocking defects

- Fatal errors, parse errors, activation failures, data loss, permission failures, broken save behavior, missing protected systems, inaccessible primary navigation, white surfaces in dark mode, or critical integration breakage.

## Non-blocking review defects

- Minor spacing, alignment, or visual-polish differences that do not break access, readability, operation, or approved design-system rules.

## Decision rules

- Every defect requires steps, expected result, actual result, environment, mode, viewport, severity, evidence, owner, and retest result.
- A blocker keeps promotion on hold.
- An exception requires a written rationale, bounded scope, risk statement, and explicit approval.
- Closed defects require recorded retest evidence.
