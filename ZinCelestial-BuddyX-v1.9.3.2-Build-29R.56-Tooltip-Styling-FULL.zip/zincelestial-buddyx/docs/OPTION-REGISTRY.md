# Option Registry

Customizer settings remain inside the per-site `zcbx_settings` option under schema version 1. The registry describes defaults, controls, sanitizers, and transports without creating a second persistence system.
