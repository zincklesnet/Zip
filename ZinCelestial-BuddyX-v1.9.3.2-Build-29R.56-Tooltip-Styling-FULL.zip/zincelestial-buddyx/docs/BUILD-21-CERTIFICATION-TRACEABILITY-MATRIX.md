# Build 21 Certification Traceability Matrix

This matrix links every release gate to required evidence and an explicit decision. A gate cannot pass from assumption, static packaging results, or missing evidence.

| Gate | Scope | Required record | Decision |
|---|---|---|---|
| Package integrity | Complete theme ZIP | CRC, single-root, inventory, checksum report | Passed statically |
| Protected systems | Save engines, asset loader, schema, Customizer | Checksum comparison | Passed statically |
| Activation | WordPress staging | Install, activate, logs, recovery result | Pending |
| PHP syntax | All PHP files | PHP CLI output | Pending |
| Visual parity | Light and dark modes | Desktop, tablet, mobile evidence | Pending |
| Accessibility | Keyboard, focus, labels, contrast, announcements | Test record and evidence | Pending |
| Reduced motion | Motion-bearing surfaces | Reduced-motion test record | Pending |
| Community integrations | BuddyPress and bbPress | Surface regression results | Pending |
| Commerce integrations | WooCommerce and marketplace adapters | Flow and surface results | Pending |
| Extended pages | Support, legal, recipes, aliases, businesses, galleries, polls | Template results | Pending |
| Rollback readiness | Stable Build 16 recovery | Rollback rehearsal record | Pending |
| Stable promotion | Entire release | Explicit approval record | Hold |
