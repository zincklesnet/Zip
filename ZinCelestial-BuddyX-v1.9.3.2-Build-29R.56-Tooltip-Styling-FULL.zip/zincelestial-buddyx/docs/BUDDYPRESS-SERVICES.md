# BuddyPress Services

`Community\BuddyPressServices` reports whether BuddyPress is available and exposes read-only capability flags for members, groups, activity, notifications, and messages. It performs no writes and registers no frontend components.
