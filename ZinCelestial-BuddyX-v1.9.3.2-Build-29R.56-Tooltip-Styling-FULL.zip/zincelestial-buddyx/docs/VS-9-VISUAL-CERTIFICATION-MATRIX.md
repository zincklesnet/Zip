# VS-9 Visual Certification Matrix

## Certification status model

Allowed statuses: `planned`, `in-progress`, `implemented`, `certified`, `blocked`.

A component or integration surface may be marked `certified` only when all required evidence is recorded for light mode, dark mode, desktop, tablet, mobile, keyboard focus, contrast, reduced motion, and regression review.

## Evidence viewports

- Desktop: 1440 x 900
- Tablet: 1024 x 768
- Mobile: 390 x 844

## Certification matrix

| Family | Build coverage | Light | Dark | Desktop | Tablet | Mobile | Keyboard and focus | Contrast | Reduced motion | Regression | Status |
|---|---|---|---|---|---|---|---|---|---|---|---|
| VS-2 Core controls | Implemented | Required | Required | Required | Required | Required | Required | Required | Required | Required | implemented |
| VS-3 Feedback, status, communication | Implemented | Required | Required | Required | Required | Required | Required | Required | Required | Required | implemented |
| VS-4 Navigation and shells | Implemented | Required | Required | Required | Required | Required | Required | Required | Required | Required | implemented |
| VS-5 Cards, lists, tables, data | Implemented | Required | Required | Required | Required | Required | Required | Required | Required | Required | implemented |
| VS-6 WordPress, BuddyPress, bbPress | Implemented | Required | Required | Required | Required | Required | Required | Required | Required | Required | implemented |
| VS-7 WooCommerce and marketplaces | Implemented | Required | Required | Required | Required | Required | Required | Required | Required | Required | implemented |
| VS-8 Extended page systems | Implemented | Required | Required | Required | Required | Required | Required | Required | Required | Required | implemented |

## Evidence rules

- Store evidence under `docs/visual-certification/<family>/<mode>/<viewport>/`.
- Use filenames that identify the component, state, mode, and viewport.
- Record intentional visual changes in `CHANGELOG.md` before accepting a new reference.
- Never replace a reference image without documenting the reason.
- Failed or missing evidence keeps the relevant row at `implemented` or `blocked`, never `certified`.
