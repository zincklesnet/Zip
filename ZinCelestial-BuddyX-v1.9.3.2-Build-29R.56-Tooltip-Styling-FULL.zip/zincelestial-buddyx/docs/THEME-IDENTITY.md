# Theme Identity

- Public theme: ZinCelestial
- Technical project: ZinCelestial-BuddyX
- Parent: BuddyX
- Design system: ZinCelestial Neon
- Default skin: ZinCelestial Default
- Default mode: Dark
