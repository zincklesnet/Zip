# Build 17 Release Governance

## Release identity

- Version: 1.8.6.5
- Build: Build 17
- Milestone: VS-9 Visual Certification and Release Governance
- Source baseline: ZinCelestial-BuddyX-v1.8.6.4-Build-16-VS-8-Extended-Page-System-Integration-FULL.zip
- Current status: approved for packaging as a certification-hold staging candidate; not approved for promotion

## Promotion gates

Release promotion is blocked unless all of the following are complete:

- Manifest tree and checksums pass.
- PHP, JavaScript, and JSON validation pass in appropriate validation environments.
- Protected checksums pass.
- Prohibited platform assets remain absent.
- Every VS-2 through VS-8 family is certified for light and dark modes.
- Desktop, tablet, and mobile evidence is complete.
- Keyboard, contrast, responsive, and reduced-motion checks pass.
- Integration regression checks pass.
- `ROADMAP.md`, `CHANGELOG.md`, `BUILD-MANIFEST.json`, and the component inventory agree.
- Explicit packaging approval is recorded.

## Release decision states

- `HOLD`: certification incomplete or a required gate failed.
- `READY_FOR_PACKAGING_APPROVAL`: all automated and staging gates passed, but no package has been authorized.
- `APPROVED_FOR_PACKAGING`: explicit approval received.
- `PROMOTED`: complete ZIP validated and approved as the stable baseline.

## Current decision

`APPROVED_FOR_PACKAGING` for staging-candidate packaging only. Promotion remains blocked pending staging visual evidence and certification.
