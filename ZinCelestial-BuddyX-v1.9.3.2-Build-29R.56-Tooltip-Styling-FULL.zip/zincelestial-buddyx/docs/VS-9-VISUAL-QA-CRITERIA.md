# VS-9 Visual QA Criteria

## Required checks

1. Light mode has no dark-only surfaces, unreadable text, or missing state contrast.
2. Dark mode has no white fallback surfaces, broken semantic tokens, or unreadable text.
3. Desktop, tablet, and mobile layouts have no clipping, overlap, inaccessible off-screen controls, or unintended horizontal scrolling.
4. Keyboard focus is visible and follows a usable order.
5. Controls retain normal, hover, focus, active, selected, loading, disabled, success, warning, and error states where applicable.
6. Reduced-motion mode removes nonessential animation and transition effects.
7. WordPress, BuddyPress, bbPress, WooCommerce, and marketplace workflows retain native ownership and behavior.
8. Customizer authority, settings schema version 1, protected save systems, and platform asset separation remain unchanged.
9. Reference evidence exists for each required mode and viewport.
10. Any regression, missing evidence, or undocumented exception blocks promotion.

## Certification result

Each family receives one result: `certified`, `blocked`, or `not-run`. The full release is promotable only when every required family is `certified` and static package validation passes.
