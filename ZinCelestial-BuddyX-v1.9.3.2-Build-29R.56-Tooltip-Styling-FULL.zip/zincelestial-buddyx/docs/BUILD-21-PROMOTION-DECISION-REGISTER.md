# Build 21 Promotion Decision Register

## Current decision

- Decision: HOLD.
- Stable baseline: Build 16, version 1.8.6.4.
- Candidate: Build 21, version 1.8.6.9.
- Reason: live staging, PHP, visual, accessibility, responsive, reduced-motion, integration, rollback, and explicit approval evidence remain required.

## Promotion record template

- Decision ID:
- Candidate package:
- Candidate checksum:
- Evidence index version:
- Open blocker count:
- Approved exceptions:
- Rollback rehearsal result:
- Decision: HOLD / REJECT / PROMOTE
- Decision authority:
- Decision date:
- Notes:
