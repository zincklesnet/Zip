# Build 20 Defect Record Template

- Defect ID:
- Surface:
- Integration:
- Mode: light / dark
- Viewport: desktop / tablet / mobile
- Severity:
- Reproduction steps:
- Expected result:
- Actual result:
- Accessibility impact:
- Evidence reference:
- Resolution status:
- Retest result:
