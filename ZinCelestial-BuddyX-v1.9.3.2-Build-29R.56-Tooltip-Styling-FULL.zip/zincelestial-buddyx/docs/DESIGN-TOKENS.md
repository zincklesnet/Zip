# VS-10 Design Token Policy

## Authority

This document defines mandatory token usage for the default ZinCelestial theme. Components and integration aliases must resolve presentation through the shared semantic token system. Parallel design systems are prohibited.

## Required token layers

1. Foundation tokens define raw color, spacing, radius, typography, shadow, motion, and sizing values.
2. Semantic tokens express purpose, including canvas, surface, text, border, accent, status, focus, overlay, and disabled roles.
3. Component tokens may alias semantic tokens for documented component needs.
4. Integration aliases must resolve to existing semantic or component tokens and must not introduce independent visual values.

## Mandatory rules

- New component styles must use an existing token or add a documented token through governance review.
- Light and dark values must be coordinated through semantic roles.
- Hard-coded colors, spacing, radii, shadows, and motion values require a recorded exception.
- Focus, disabled, loading, success, warning, and error states must use semantic state tokens.
- Reduced-motion behavior must use shared motion rules.
- WordPress, BuddyPress, bbPress, WooCommerce, and marketplace selectors remain aliases over the core system.
- Token changes must be recorded in the roadmap, changelog, component inventory, and build manifest.

## Promotion gate

Promotion is blocked when a component lacks a token mapping, an exception is undocumented, an integration alias bypasses the core system, or required visual evidence is missing.
