# Dashboard Widget Registry

`Core\DashboardWidgetRegistry` stores sanitized, passive widget definitions. v1.8.3 does not render widgets or enqueue additional assets. The registry is exposed through read-only diagnostics.
