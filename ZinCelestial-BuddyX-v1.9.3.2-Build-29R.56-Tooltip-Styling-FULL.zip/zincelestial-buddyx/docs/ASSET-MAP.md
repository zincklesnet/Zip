# Asset Map

`inc/assets.php` is the active loader. Do not also register `Services/AssetManager.php`.
