# Settings Schema

Settings remain stored per site in `zcbx_settings`. v1.8.5 retains schema version 1 and adds no migration or automatic writes. The save engine remains protected and unchanged.
