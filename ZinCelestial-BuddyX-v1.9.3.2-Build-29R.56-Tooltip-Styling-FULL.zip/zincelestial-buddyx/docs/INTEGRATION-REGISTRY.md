# Integration Registry

`Compatibility\IntegrationRegistry` stores normalized runtime active state and health derived from the validated plugin detector. It performs no option writes.
