# Community Experience Platform

v1.8.5 adds passive scaffolding for the future transfer of selected BuddyPress Nouveau and BuddyX Customizer controls. The Customizer remains authoritative and frontend behavior is unchanged.

## Planned sections
- Overview
- Site Experience
- Member Experience
- Group Experience
- Migration & Ownership
- Diagnostics
