# Legacy Review

The profile hotfix and loader snippet are retained for reference and are not auto-loaded by the current bootstrap.
