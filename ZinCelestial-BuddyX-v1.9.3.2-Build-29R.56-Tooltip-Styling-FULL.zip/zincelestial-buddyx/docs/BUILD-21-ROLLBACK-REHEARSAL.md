# Build 21 Rollback Rehearsal

Rollback certification must be completed on staging before stable promotion.

1. Record the active candidate version and configuration.
2. Back up theme files, settings, and relevant records.
3. Replace the candidate with the approved Build 16 stable package.
4. Confirm activation, frontend rendering, Customizer access, protected settings, and community layouts.
5. Review PHP and WordPress logs.
6. Record elapsed recovery time without treating it as a release promise.
7. Restore the candidate only if the rollback result is complete and documented.

No automated data removal or schema migration is authorized by this rehearsal.
