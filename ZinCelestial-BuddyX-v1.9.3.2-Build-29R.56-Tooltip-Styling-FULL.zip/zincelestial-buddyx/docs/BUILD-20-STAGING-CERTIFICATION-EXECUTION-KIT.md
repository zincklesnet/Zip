# Build 20 Staging Certification Execution Kit

Build 20 continues VS-10 without expanding runtime scope or introducing VS-11.

## Certification order

1. Install and activate the complete package on staging.
2. Run PHP syntax checks and capture results.
3. Capture light and dark evidence at desktop, tablet, and mobile sizes.
4. Test keyboard traversal, focus visibility, contrast, reduced motion, and responsive behavior.
5. Test WordPress, BuddyPress, bbPress, WooCommerce, marketplace, and extended-page surfaces.
6. Record every failure with surface, mode, viewport, steps, expected result, actual result, and evidence.
7. Promote only after all required gates pass and explicit approval is recorded.

## Protected constraints

- Settings schema version 1 remains authoritative.
- Customizer authority remains unchanged.
- Protected save-engine files remain checksum-identical.
- The main theme must not contain or enqueue platform.css or platform.js.
- Build 16 remains the stable baseline until explicit promotion approval.
