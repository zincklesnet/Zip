# Read-Only Dashboard Surface

The ZinCelestial Dashboard tab renders the passive Platform Health, BuddyPress Services, and WooCommerce Services definitions. It performs no writes and adds no settings fields.
