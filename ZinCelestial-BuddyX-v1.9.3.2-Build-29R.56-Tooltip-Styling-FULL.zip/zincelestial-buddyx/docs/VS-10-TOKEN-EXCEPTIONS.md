# VS-10 Token Exception Register

## Policy

Token exceptions are temporary, narrow, documented deviations from the shared semantic token system. An exception must include the affected selector or component, the exact value, the reason, the owner, the removal condition, and the review status.

## Active exceptions

No Build 18 exceptions are approved at this stage. The automated audit findings remain under review and have not been classified as approved exceptions.

## Required entry format

- Component or selector:
- Property and value:
- Semantic token considered:
- Reason an existing token cannot be used:
- Accessibility and dark-mode impact:
- Removal condition:
- Status: proposed, approved, blocked, or removed

Undocumented exceptions block release promotion.
