# Architecture

`functions.php` loads `Core/Bootstrap.php`, which registers the autoloader, guarded legacy modules, and services.
