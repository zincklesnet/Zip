# Build 20 Evidence Index

Use one evidence record per tested surface. Do not mark a gate passed without attached staging evidence.

| Gate | Required evidence | Status |
|---|---|---|
| Installation and activation | Activation result and error-log review | Pending |
| PHP syntax | PHP CLI output | Pending |
| Light mode | Desktop, tablet, and mobile captures | Pending |
| Dark mode | Desktop, tablet, and mobile captures | Pending |
| Accessibility | Keyboard, focus, labels, contrast, and announcements | Pending |
| Reduced motion | Reduced-motion behavior capture | Pending |
| WordPress and community | Surface-by-surface regression record | Pending |
| Commerce and marketplace | Flow and surface regression record | Pending |
| Extended pages | Template and responsive regression record | Pending |
| Promotion | Explicit approval record | Pending |
