# Module Standards

Modules register a unique slug, callback, and optional dependencies through `Core\ModuleRegistry`. Duplicate slugs and dependency cycles do not boot.
