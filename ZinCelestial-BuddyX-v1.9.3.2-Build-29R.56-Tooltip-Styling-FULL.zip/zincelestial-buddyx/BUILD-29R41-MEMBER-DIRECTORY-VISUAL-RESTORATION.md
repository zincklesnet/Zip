# Build 29R.41 Member Directory Visual Restoration

## Restored
- Restored the compact Member Command card, narrow Community Signal ribbon, and immediate directory-tab rhythm shown in reference image `2.png`.
- Restored the approved two-column member card grid shown in reference image `1.png`.
- Member covers now occupy the full card top instead of rendering as detached blocks inside the identity column.
- Avatars overlap the cover boundary; achievement and point rows remain with the avatar section.
- Member identity, activity, and friendship actions remain contained inside each card.
- Card height, spacing, and alignment are consistent across the grid.

## Runtime normalization
- Recognized cover elements are moved to the first card position and made visible.
- A non-avatar image inside the avatar panel is wrapped and promoted as a normalized cover when no recognized cover wrapper exists.

## Preserved
- Server-rendered administration shell, live icon variants, 24px administration icons, settings schema version 1, native BuddyX sidebars, and News Feed activity parity.
