# Build 29R.36 Administration Panel Isolation Recovery

## Root cause
The top-level controller selected every `.z section` generically and relied on non-important display rules. Later administration styles and plugin CSS could allow non-selected panels to render, producing a continuous page containing Dashboard, Libraries, Member Directory, Header, Background, Cover Images, and the remaining settings panels.

## Corrected
- Scoped the main controller to direct `form > section[data-panel]` children only.
- Added hard `display:none !important` and visibility isolation for every inactive top-level panel.
- Added synchronized `hidden`, `aria-hidden`, active class, aria-selected, and roving tabindex states.
- Added safe saved-tab validation and Dashboard fallback.
- Kept nested Element, Component, and Signature Icon library panels independent from main navigation.
- Added pre-initialization isolation so panels cannot flash together before JavaScript starts.

## Preserved
- The globally corrected `zcbx-field-row` appearance shown in reference screenshots 1–19.
- Unified libraries, accessibility behavior, group/profile icons, activity parity, native BuddyX sidebars, saved settings, and schema version 1.
