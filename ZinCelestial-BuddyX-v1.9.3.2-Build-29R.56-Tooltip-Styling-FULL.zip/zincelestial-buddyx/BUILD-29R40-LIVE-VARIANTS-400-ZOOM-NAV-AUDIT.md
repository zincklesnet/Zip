# Build 29R.40 Live Variants, 400% Zoom, and Navigation Audit

## Root cause
The variant definitions existed in `assets/signature-icons.css`, but the ZinCelestial administration page loaded only `assets/admin.css`. The preview SVG therefore changed its variant class correctly while Badge, Glow, and Button had no variant presentation rules available on that page.

## Corrected
- Enqueued the shared Signature Icon stylesheet on the administration page before `admin.css`.
- Added explicit administration preview rules for Plain, Badge, Glow, and Button.
- Added a visible background and stronger presentation for Glow so the selected state is unmistakable.
- Added live `data-variant` state and an updated accessible preview label.
- Retained fresh SVG replacement and live icon, size, color, variant, and shortcode updates.

## Navigation and zoom audit
- All top-level navigation link targets remain 48px with 24px SVGs at normal widths.
- At 320 CSS pixels, targets remain 44px with 24px SVGs.
- Registry and fallback navigation SVG classes are covered by the same size rule.
- Navigation remains server-routed and does not depend on JavaScript.
