# Member and Group Directory Card Audit — Build 29R.43

## Baseline
- Theme: ZinCelestial-BuddyX
- Version: 1.9.2.0
- Build: 29R.43
- Package: ZinCelestial-BuddyX-v1.9.2.0-Build-29R.43-Directory-Card-Final-Restoration-FULL.zip

## Visual evidence
The supplied installed screenshots show:
- Member and group avatars clipped at the card top.
- Reward and point controls above member identity content.
- Missing top cover images on most cards.
- Large beige blocks below the identity and action content.
- One unrelated member image rendered inside the lower beige block.
- Group cards using avatar, identity, and action content without the required cover-first structure.

## Confirmed root causes

### 1. Three card engines remain active in one stylesheet
`assets/members-groups-layout.css` contains:
- The original Build 29R.20 member-card rules.
- The Build 29R.41 grid-restoration rules.
- The Build 29R.43 final-restoration layer.

The Build 29R.41 layer still forces:
- `display:grid!important`
- `grid-template-rows:118px auto minmax(0,1fr)!important`
- `height:100%!important`
- `min-height:430px!important`
- fixed grid rows for cover, avatar/rewards, and identity

These declarations remain active because their selectors include the server body class and grid-view class, and the properties use `!important`.

### 2. The 29R.43 layer does not reset the grid template
The final layer changes the card to `display:flex!important`, but it does not remove every older grid-specific row assignment from children. The browser therefore receives competing order, row, height, and minimum-height instructions.

### 3. Cover discovery is unreliable
`assets/community-pizzazz.js` only recognizes a narrow list of direct-child cover classes. When a verified cover is not found, the script clones `.item-avatar > img:not(.avatar)`. That image is not guaranteed to be a member or group cover. The unrelated lower image in the installed screenshot is consistent with this fallback.

### 4. A second runtime mutates cover visibility
`assets/layout-runtime-cleanup.js` hides recognized cover elements in Compact mode and copies the cover to an inline avatar-panel background. The script runs on initial load and after DOM mutations. This creates a second source of cover state changes outside the card engine.

### 5. Member and group markup are treated as one structure
The current normalizer applies one direct-child contract to member and group cards. BuddyPress member and group directory output does not necessarily expose cover, avatar, metadata, creator, and action regions through identical direct-child classes.

### 6. Equal-height behavior is still active
The Build 29R.41 card uses `height:100%!important` and `min-height:430px!important`. The grid aligns items to stretch in the same generation. These rules produce the large lower beige areas when expected content/cover regions are absent or reordered.

## Enqueue and runtime findings
- `members-groups-layout.css` is loaded as the directory card stylesheet.
- `community-pizzazz.js` performs class assignment and cover normalization.
- `layout-runtime-cleanup.js` performs additional cover hiding/background copying in Compact mode.
- Mutation observers can rerun both normalization and cleanup behavior after BuddyPress updates the directory.

## Required removal list
Before implementing another design layer, remove these obsolete systems from `assets/members-groups-layout.css`:
1. Original Build 29R.20 member-card presentation rules.
2. Build 29R.41 member grid/card restoration rules.
3. All Compact-mode cover relocation rules tied to the retired structure.
4. Fixed card `height:100%` and `min-height:430px` rules.
5. Fixed `grid-template-rows` and child `grid-row` assignments.
6. Old `.item-avatar` background, overflow, and padding presentation rules.

Remove or replace these runtime behaviors:
1. Arbitrary `.item-avatar > img:not(.avatar)` cover fallback.
2. Cover relocation by moving existing DOM nodes.
3. Compact-mode cover hiding/background copying in `layout-runtime-cleanup.js`.
4. Shared member/group normalization that assumes identical markup.

## Replacement architecture

### Member card adapter
Create a member-only adapter that:
- Identifies the member list entry and `.list-wrap`.
- Uses a positively identified member cover only.
- Leaves rewards and achievement markup in its plugin-generated container.
- Adds semantic region classes without moving plugin content unless a verified container exists.
- Applies the approved visual order through one canonical stylesheet.

### Group card adapter
Create a separate group-only adapter that:
- Identifies the group list entry and `.list-wrap`.
- Uses a positively identified group cover only.
- Preserves group privacy, member count, activity, creator, and membership action markup.
- Applies the approved visual order through group-specific region classes.

### Canonical card stylesheet
Use one final card engine only:
- Three columns on wide screens.
- Two columns at the tablet breakpoint.
- One column on narrow screens.
- Auto card height.
- No forced blank rows.
- Cover at top when verified.
- Avatar overlapping the cover.
- Identity and metadata in normal document flow.
- Actions last.
- No background placeholders when a cover is unavailable.

## Expected visual contract

### Member cards
1. Verified cover image.
2. Overlapping circular avatar.
3. Member name and username.
4. Rewards, achievements, and ratings in contained rows.
5. Utility icons.
6. Friendship, Follow, and Message actions.

### Group cards
1. Verified group cover image.
2. Overlapping group avatar.
3. Group title.
4. Activity, privacy, and member count.
5. Utility icons.
6. Creator information when supplied.
7. Join, Leave, or Request Membership action.

## Audit conclusion
Build 29R.43 should not receive another additive CSS override. The correct next implementation is a cleanup build that removes the retired card engines and replaces them with separate member and group adapters plus one canonical stylesheet.
