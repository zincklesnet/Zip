# Build 29R.26 Signature Icon Context API

## Implemented
- Added stable alias resolution for common icon names.
- Added category retrieval and a filterable context-to-icon map.
- Added `zcbx_signature_icon()` and `zcbx_signature_icon_for_context()` developer helpers.
- Added copy-shortcode controls to the Signature Icon Library.
- Kept fallback behavior centralized through the registry.

## Preserved
- Profile menu signature-icon integration and custom image priority.
- Element Library, Component Library, and Signature Icon Library remain together in ZinCelestial Administration.
- News Feed activity parity, native BuddyX sidebars, saved settings, and schema version 1 remain unchanged.
