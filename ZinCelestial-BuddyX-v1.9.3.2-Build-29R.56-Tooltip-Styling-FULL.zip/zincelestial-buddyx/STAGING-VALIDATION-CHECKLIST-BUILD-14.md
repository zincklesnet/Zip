# Build 14 Staging Validation Checklist

- [ ] Activate with BuddyX, BuddyPress and bbPress; verify no PHP or console errors.
- [ ] Verify WordPress posts, pages, archives, comments, search, forms, navigation and messages.
- [ ] Verify BuddyPress member/group directories, headers, profiles, activity, notifications and messages.
- [ ] Verify galleries, polls, privacy and member/group frontpages.
- [ ] Verify bbPress forums, topics, replies, notices, profiles and forms.
- [ ] Verify native hooks, permissions, extension points and plugin data ownership.
- [ ] Verify responsive layouts, keyboard access, reduced motion and light/dark parity.
- [ ] Approve promotion to stable baseline.
