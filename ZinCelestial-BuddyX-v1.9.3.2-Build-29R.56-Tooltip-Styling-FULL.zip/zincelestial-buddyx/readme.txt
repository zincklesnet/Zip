ZinCelestial-BuddyX
Author: Zinckles
Version: 1.9.3.2
Build: 29R.56
Parent theme: BuddyX
Package: ZinCelestial-BuddyX-v1.9.3.2-Build-29R.56-Tooltip-Styling-FULL.zip
Settings schema: 1
