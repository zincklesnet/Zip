# Build 29R.16 Canonical Directory Panel

- Removes the second BuddyPress render hook that produced duplicate experience controls on the live directory.
- Assigns one canonical experience-panel ID.
- Removes duplicate panels defensively after initial render and BuddyPress AJAX refreshes.
- Moves the existing Members title container above the complete directory shell.
- Removes duplicate Members title containers and normalizes the title row width and alignment.
- Preserves Grid/Compact behavior and settings schema version 1.
