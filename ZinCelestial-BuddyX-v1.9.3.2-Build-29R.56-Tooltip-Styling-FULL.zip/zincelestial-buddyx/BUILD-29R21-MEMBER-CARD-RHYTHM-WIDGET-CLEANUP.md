# Build 29R.21 Member Card Rhythm and Widget Cleanup

## Baseline
- Build 29R.20 Members and Groups Layout Cleanup.
- Native BuddyX Site Sidebar Customizer remains authoritative.
- Settings schema remains version 1.

## Corrected
- Compact member covers are absorbed into the left visual panel and hidden as standalone lower blocks.
- Grid member-card vertical padding is reduced.
- Member actions remain contained and align consistently at the lower edge of identity content.
- Native Groups cards receive compact height safeguards without redesigning BuddyX output.
- Retired ZinCelestial Member/Group widget regions are unregistered after all registration callbacks.
- Repeated widget instances and language switchers are hidden at runtime when identical output occurs in multiple page regions.

## Preserved
- Member Command, Community signal, Grid/Compact controls, rewards, avatar rings, light/dark modes.
- Native BuddyX member/group sidebars and sticky behavior.
- Removed ZinCelestial Community Layout shell and schema version 1.
