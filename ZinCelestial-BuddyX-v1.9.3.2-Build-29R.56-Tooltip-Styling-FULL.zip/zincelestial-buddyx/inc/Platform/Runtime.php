<?php
namespace ZinCelestial\BuddyX\Platform;
defined( 'ABSPATH' ) || exit;
final class Runtime {public static function register():void{if(is_callable('zcbx_register_platform'))zcbx_register_platform();Hooks::register();Ajax::register();Rest::register();do_action('zcbx_platform_runtime_registered');}}
