<?php
namespace ZinCelestial\BuddyX\Platform;
defined( 'ABSPATH' ) || exit;
final class Hooks {public static function register():void{do_action('zcbx_platform_hooks_registered');}}
