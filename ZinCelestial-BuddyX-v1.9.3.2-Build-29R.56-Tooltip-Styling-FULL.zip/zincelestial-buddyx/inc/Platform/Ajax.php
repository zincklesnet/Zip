<?php
namespace ZinCelestial\BuddyX\Platform;
defined( 'ABSPATH' ) || exit;
final class Ajax {public static function register():void{do_action('zcbx_ajax_services_registered');}}
