<?php
namespace ZinCelestial\BuddyX\Platform;
defined( 'ABSPATH' ) || exit;
final class Rest {public static function register():void{add_action('rest_api_init',array(self::class,'routes'));}public static function routes():void{do_action('zcbx_register_rest_routes');}}
