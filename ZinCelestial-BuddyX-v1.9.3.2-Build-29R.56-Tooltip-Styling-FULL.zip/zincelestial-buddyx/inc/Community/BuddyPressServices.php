<?php
namespace ZinCelestial\BuddyX\Community;
defined( 'ABSPATH' ) || exit;

final class BuddyPressServices {
    public static function register(): void {
        if ( ! self::available() ) {
            do_action( 'zcbx_buddypress_services_unavailable' );
            return;
        }

        do_action( 'zcbx_buddypress_services_registered', self::capabilities() );
    }

    public static function available(): bool {
        return function_exists( 'buddypress' );
    }

    public static function capabilities(): array {
        return array(
            'members'       => function_exists( 'bp_is_user' ),
            'groups'        => function_exists( 'bp_is_group' ),
            'activity'      => function_exists( 'bp_get_activity_directory_permalink' ),
            'notifications' => function_exists( 'bp_notifications_get_notifications_for_user' ),
            'messages'      => function_exists( 'messages_get_unread_count' ),
        );
    }
}
