<?php
namespace ZinCelestial\BuddyX\Community;
defined( 'ABSPATH' ) || exit;
final class ProfilePermissions {public static function can_manage(int $user_id=0):bool{$user_id=$user_id?:get_current_user_id();return $user_id>0&&(current_user_can('edit_user',$user_id)||current_user_can('manage_options'));}}
