<?php
namespace ZinCelestial\BuddyX\Community\Conditions;
defined( 'ABSPATH' ) || exit;

final class VisibilityRuleEvaluator {
    public static function side_visible( string $context, string $side, array $settings ): bool {
        $audience = sanitize_key( (string) ( $settings[ 'community_' . $side . '_audience' ] ?? 'all' ) );
        if ( 'logged-in' === $audience && ! is_user_logged_in() ) {
            return false;
        }
        if ( 'logged-out' === $audience && is_user_logged_in() ) {
            return false;
        }

        if ( 'member' === $context ) {
            $scope = sanitize_key( (string) ( $settings[ 'community_' . $side . '_member_scope' ] ?? 'all' ) );
            $self  = function_exists( 'bp_is_my_profile' ) && bp_is_my_profile();
            if ( 'self' === $scope && ! $self ) {
                return false;
            }
            if ( 'others' === $scope && $self ) {
                return false;
            }
        }

        if ( 'group' === $context ) {
            $scope  = sanitize_key( (string) ( $settings[ 'community_' . $side . '_group_scope' ] ?? 'all' ) );
            $member = function_exists( 'groups_is_user_member' ) && function_exists( 'bp_get_current_group_id' ) && is_user_logged_in()
                ? (bool) groups_is_user_member( get_current_user_id(), bp_get_current_group_id() )
                : false;
            if ( 'members' === $scope && ! $member ) {
                return false;
            }
            if ( 'non-members' === $scope && $member ) {
                return false;
            }
        }

        return true;
    }

    public static function region_visible( string $side, string $region, array $settings ): bool {
        $key = 'community_' . $side . '_' . $region . '_enabled';
        return ! isset( $settings[ $key ] ) || ! empty( $settings[ $key ] );
    }
}
