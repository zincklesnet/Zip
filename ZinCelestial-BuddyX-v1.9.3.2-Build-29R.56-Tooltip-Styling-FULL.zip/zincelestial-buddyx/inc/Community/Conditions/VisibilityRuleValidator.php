<?php
namespace ZinCelestial\BuddyX\Community\Conditions;
defined( 'ABSPATH' ) || exit;
final class VisibilityRuleValidator { public static function valid(array $r): bool { return isset($r['field'],$r['operator'])&&in_array(sanitize_key((string)$r['field']),array('context','component','viewing_self','logged_in','device'),true)&&in_array(sanitize_key((string)$r['operator']),array('equals','not_equals'),true); } }
