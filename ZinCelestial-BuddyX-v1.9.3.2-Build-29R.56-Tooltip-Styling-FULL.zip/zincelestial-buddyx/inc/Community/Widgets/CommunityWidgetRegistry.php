<?php
namespace ZinCelestial\BuddyX\Community\Widgets;
defined( 'ABSPATH' ) || exit;
final class CommunityWidgetRegistry { private static array $definitions=array(); public static function register(array $d): bool { if(!WidgetDefinitionValidator::valid($d)){return false;}$id=sanitize_key((string)$d['id']);if(''===$id||isset(self::$definitions[$id])){return false;}self::$definitions[$id]=$d;return true;} public static function all(): array{return self::$definitions;} }
