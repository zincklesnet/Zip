<?php
namespace ZinCelestial\BuddyX\Community\Widgets;
defined( 'ABSPATH' ) || exit;
final class WidgetDefinitionValidator { public static function valid(array $d): bool { if(empty($d['id'])||empty($d['title'])){return false;}$c=isset($d['contexts'])&&is_array($d['contexts'])?$d['contexts']:array();return !array_diff($c,array('member','group')); } }
