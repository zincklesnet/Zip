<?php
namespace ZinCelestial\BuddyX\Community;
defined( 'ABSPATH' ) || exit;
final class HeaderNavigation { public static function register():void { if(is_callable('zcbx_register_header_navigation'))zcbx_register_header_navigation(); do_action('zcbx_header_navigation_service_registered'); } }
