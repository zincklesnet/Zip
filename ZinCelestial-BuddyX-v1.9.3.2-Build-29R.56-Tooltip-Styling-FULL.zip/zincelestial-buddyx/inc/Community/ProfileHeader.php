<?php
namespace ZinCelestial\BuddyX\Community;
defined( 'ABSPATH' ) || exit;
final class ProfileHeader {public static function register():void{if(function_exists('buddypress')&&is_callable('zcbx_register_profile_header'))zcbx_register_profile_header();do_action('zcbx_profile_header_service_registered');}}
