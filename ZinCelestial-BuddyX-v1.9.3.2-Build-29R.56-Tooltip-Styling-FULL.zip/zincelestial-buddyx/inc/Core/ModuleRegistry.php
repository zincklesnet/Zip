<?php
namespace ZinCelestial\BuddyX\Core;
defined( 'ABSPATH' ) || exit;

final class ModuleRegistry {
    private static array $modules = array();
    private static array $booted  = array();

    public static function register( string $slug, callable $callback, array $dependencies = array() ): bool {
        $slug = sanitize_key( $slug );
        if ( '' === $slug || isset( self::$modules[ $slug ] ) ) {
            return false;
        }
        self::$modules[ $slug ] = array(
            'callback'     => $callback,
            'dependencies' => array_values( array_unique( array_filter( array_map( 'sanitize_key', $dependencies ) ) ) ),
        );
        return true;
    }

    public static function boot(): void {
        foreach ( array_keys( self::$modules ) as $slug ) {
            self::boot_module( $slug );
        }
        do_action( 'zcbx_modules_booted', self::statuses() );
    }

    public static function statuses(): array {
        $statuses = array();
        foreach ( self::$modules as $slug => $module ) {
            $statuses[ $slug ] = array(
                'registered'   => true,
                'booted'       => ! empty( self::$booted[ $slug ] ),
                'dependencies' => $module['dependencies'],
            );
        }
        return $statuses;
    }

    private static function boot_module( string $slug, array $stack = array() ): bool {
        if ( ! empty( self::$booted[ $slug ] ) ) {
            return true;
        }
        if ( ! isset( self::$modules[ $slug ] ) || in_array( $slug, $stack, true ) ) {
            return false;
        }
        $stack[] = $slug;
        foreach ( self::$modules[ $slug ]['dependencies'] as $dependency ) {
            if ( ! self::boot_module( $dependency, $stack ) ) {
                return false;
            }
        }
        call_user_func( self::$modules[ $slug ]['callback'] );
        self::$booted[ $slug ] = true;
        do_action( 'zcbx_module_booted', $slug );
        return true;
    }
}
