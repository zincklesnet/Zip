<?php
namespace ZinCelestial\BuddyX\Core;
defined( 'ABSPATH' ) || exit;

final class DashboardWidgetRegistry {
    private static array $widgets = array();

    public static function register( string $slug, array $definition ): bool {
        $slug = sanitize_key( $slug );
        if ( '' === $slug || isset( self::$widgets[ $slug ] ) ) {
            return false;
        }

        self::$widgets[ $slug ] = array(
            'title'       => isset( $definition['title'] ) ? sanitize_text_field( (string) $definition['title'] ) : $slug,
            'description' => isset( $definition['description'] ) ? sanitize_text_field( (string) $definition['description'] ) : '',
            'source'      => isset( $definition['source'] ) ? sanitize_key( (string) $definition['source'] ) : 'core',
            'enabled'     => ! array_key_exists( 'enabled', $definition ) || ! empty( $definition['enabled'] ),
        );

        do_action( 'zcbx_dashboard_widget_registered', $slug, self::$widgets[ $slug ] );
        return true;
    }

    public static function register_defaults(): void {
        self::register( 'platform-health', array(
            'title'       => 'Platform Health',
            'description' => 'Read-only platform and service health summary.',
            'source'      => 'core',
        ) );
        self::register( 'buddypress-services', array(
            'title'       => 'BuddyPress Services',
            'description' => 'Read-only BuddyPress capability summary.',
            'source'      => 'buddypress',
            'enabled'     => class_exists( '\\ZinCelestial\\BuddyX\\Community\\BuddyPressServices' ) && \ZinCelestial\BuddyX\Community\BuddyPressServices::available(),
        ) );
        self::register( 'woocommerce-services', array(
            'title'       => 'WooCommerce Services',
            'description' => 'Read-only WooCommerce capability summary.',
            'source'      => 'woocommerce',
            'enabled'     => class_exists( '\\ZinCelestial\\BuddyX\\Compatibility\\WooCommerceServices' ) && \ZinCelestial\BuddyX\Compatibility\WooCommerceServices::available(),
        ) );

        do_action( 'zcbx_dashboard_widgets_registered', self::all() );
    }

    public static function all(): array {
        return self::$widgets;
    }

    public static function get( string $slug ): array {
        $slug = sanitize_key( $slug );
        return self::$widgets[ $slug ] ?? array();
    }
}
