<?php
namespace ZinCelestial\BuddyX\Core;
defined( 'ABSPATH' ) || exit;
final class Autoloader {
 private const PREFIX='ZinCelestial\\BuddyX\\';
 public static function register():void { spl_autoload_register(array(self::class,'load')); }
 private static function load(string $class):void {
  if(0!==strpos($class,self::PREFIX)) return;
  $file=ZCBX_PATH.'inc/'.str_replace('\\','/',substr($class,strlen(self::PREFIX))).'.php';
  if(is_readable($file)) require_once $file;
 }
}
