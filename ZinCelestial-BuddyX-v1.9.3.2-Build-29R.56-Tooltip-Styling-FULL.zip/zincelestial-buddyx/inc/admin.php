<?php
defined('ABSPATH') || exit;

function zcbx_register_admin() {
    add_action('admin_menu', function () {
        add_theme_page('ZinCelestial BuddyX', 'ZinCelestial', 'edit_theme_options', 'zcbx-control', 'zcbx_page');
    });
    add_action('admin_enqueue_scripts', function ($hook) {
        if ('appearance_page_zcbx-control' !== $hook) return;
        wp_enqueue_media();
        wp_enqueue_style('zcbx-signature-icons-admin', ZCBX_URL . 'assets/signature-icons.css', array(), ZCBX_VERSION);
        wp_enqueue_style('zcbx-admin', ZCBX_URL . 'assets/admin.css', array('zcbx-signature-icons-admin'), ZCBX_VERSION);
        wp_enqueue_script('zcbx-admin', ZCBX_URL . 'assets/admin.js', array('jquery'), ZCBX_VERSION, true); wp_enqueue_script('zcbx-save-engine', ZCBX_URL . 'assets/save-engine.js', array('zcbx-admin'), ZCBX_VERSION, true);
    });
}

function zcbx_sel($s, $key, $label, $options) {
    $current = $s[$key] ?? '';
    $default = zcbx_defaults()[$key] ?? '';
    ?>
    <label class="f zcbx-field-row"><span><strong><?php echo esc_html($label); ?></strong><small>Default: <?php echo esc_html($default); ?></small></span><select name="zcbx_settings[<?php echo esc_attr($key); ?>]">
    <?php foreach ($options as $value => $name) : ?><option value="<?php echo esc_attr($value); ?>" <?php selected($current, $value); ?>><?php echo esc_html($name); ?></option><?php endforeach; ?>
    </select></label><?php
}
function zcbx_on($s, $key, $label) {
    $default = !empty(zcbx_defaults()[$key]) ? 'Enabled' : 'Disabled'; ?>
    <label class="f zcbx-field-row"><span><strong><?php echo esc_html($label); ?></strong><small>Default: <?php echo esc_html($default); ?></small></span><input type="checkbox" name="zcbx_settings[<?php echo esc_attr($key); ?>]" value="1" <?php checked(!empty($s[$key])); ?>></label><?php
}
function zcbx_range($s, $key, $label, $min, $max, $step = 1, $unit = '') {
    $value = $s[$key] ?? ''; $default = zcbx_defaults()[$key] ?? ''; ?>
    <label class="f zcbx-field-row"><span><strong><?php echo esc_html($label); ?></strong><small>Default: <?php echo esc_html($default . $unit); ?></small></span><span class="zr"><input type="range" aria-label="<?php echo esc_attr($label); ?>" min="<?php echo esc_attr($min); ?>" max="<?php echo esc_attr($max); ?>" step="<?php echo esc_attr($step); ?>" name="zcbx_settings[<?php echo esc_attr($key); ?>]" value="<?php echo esc_attr($value); ?>"><output aria-live="polite"><?php echo esc_html($value . $unit); ?></output></span></label><?php
}
function zcbx_color($s, $key, $label, $opacity = '') {
    $value = $s[$key] ?? '#000000'; $default = zcbx_defaults()[$key] ?? ''; ?>
    <label class="f zcbx-field-row"><span><strong><?php echo esc_html($label); ?></strong><small>Default: <?php echo esc_html($default); ?></small></span><input type="color" name="zcbx_settings[<?php echo esc_attr($key); ?>]" value="<?php echo esc_attr($value); ?>"></label><?php
    if ($opacity) { zcbx_range($s, $opacity, $label . ' opacity', 0, 1, .05); }
}
function zcbx_media($s, $key, $label) {
    $url = esc_url($s[$key] ?? ''); ?>
    <div class="f zcbx-field-row zcbx-media-field"><span><strong><?php echo esc_html($label); ?></strong><small>Choose from the WordPress Media Library</small></span><div class="zcbx-media-control"><input type="hidden" class="zcbx-media-url" name="zcbx_settings[<?php echo esc_attr($key); ?>]" value="<?php echo esc_attr($url); ?>"><div class="zcbx-media-preview"><?php if ($url) : ?><img src="<?php echo esc_url($url); ?>" alt=""><?php else : ?><span>No image selected</span><?php endif; ?></div><p><button type="button" class="button zcbx-media-select"><?php echo esc_html($url ? 'Replace image' : 'Select image'); ?></button> <button type="button" class="button zcbx-media-remove"<?php echo $url ? '' : ' style="display:none"'; ?>>Remove</button></p></div></div><?php
}
function zcbx_preview($type, $title) {
    echo '<div class="zcbx-live-preview" data-preview="' . esc_attr($type) . '"><strong>' . esc_html($title) . '</strong><div class="zcbx-preview-stage"><div class="zcbx-preview-image"></div><div class="zcbx-preview-overlay"></div><div class="zcbx-preview-card"><span></span><b></b></div></div><small>Live preview updates while controls move.</small></div>';
}
function zcbx_admin_icon($key) {
    $registry_map = array(
        'dashboard' => 'command-dashboard',
        'libraries' => 'library-signature',
        'icons' => 'library-signature',
        'member-directory' => 'community-members',
        'profile-menu' => 'profile-orbit',
        'diagnostics' => 'status-info',
        'tools' => 'settings-core',
    );
    if ( isset( $registry_map[ $key ] ) ) {
        return \ZinCelestial\BuddyX\DesignSystem\SignatureIconRegistry::render( $registry_map[ $key ] );
    }
    $paths = array(
        'header'=>'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18"/>',
        'backgrounds'=>'<path d="M3 18l5-6 4 4 3-3 6 5"/><circle cx="8" cy="7" r="2"/>',
        'cover-images'=>'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 14l5-5 4 4 3-3 6 6"/>',
        'card'=>'<rect x="3" y="5" width="18" height="14" rx="3"/><circle cx="8" cy="11" r="2"/><path d="M12 10h6M12 14h4"/>',
        'avatar'=>'<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-7 8-7s8 3 8 7"/>',
        'items'=>'<path d="M5 5h14v14H5zM8 9h8M8 13h8"/>',
        'visibility'=>'<path d="M2 12s4-6 10-6 10 6 10 6-4 6-10 6S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
        'effects'=>'<path d="M12 2v4M12 18v4M4.9 4.9l2.8 2.8M16.3 16.3l2.8 2.8M2 12h4M18 12h4M4.9 19.1l2.8-2.8M16.3 7.7l2.8-2.8"/><circle cx="12" cy="12" r="4"/>',
        'widgets'=>'<rect x="3" y="4" width="8" height="7" rx="1"/><rect x="13" y="4" width="8" height="4" rx="1"/><rect x="13" y="10" width="8" height="10" rx="1"/><rect x="3" y="13" width="8" height="7" rx="1"/>',
        'subheader'=>'<path d="M3 5h18v5H3zM5 14h14M8 18h8"/>',
        'surfaces'=>'<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M3 10h18M9 10v10"/>',
    );
    $shape = $paths[ $key ] ?? '<circle cx="12" cy="12" r="8"/><path d="M8 12h8"/>';
    return '<svg class="zcbx-admin-signature-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' . $shape . '</svg>';
}

function zcbx_admin_critical_style() { ?>
<style id="zcbx-admin-critical">
.z{max-width:1180px}.z>header{display:flex;justify-content:space-between;align-items:center;margin:18px 0 0;padding:24px 28px;border-radius:18px 18px 0 0;background:linear-gradient(135deg,#34246d,#6957ea);color:#fff}.z>header h1{margin:0;color:#fff}.z>header p{margin:5px 0 0;color:#e9e5ff}.ztabs{display:flex;gap:6px;overflow:auto;padding:12px;background:#fff;border:1px solid #dedfea}.ztabs button{flex:none;padding:9px 12px;border:0;border-radius:9px;background:#f3f2fa;cursor:pointer}.ztabs button.active{background:#6957ea;color:#fff}.z section{display:none;padding:24px;background:#fff;border:1px solid #dedfea;border-top:0}.z section.active{display:block}.z .f{display:grid;grid-template-columns:minmax(210px,.8fr) minmax(260px,1.2fr);gap:18px;align-items:center;padding:14px 0;border-bottom:1px solid #ececf2}.z .note{padding:12px 14px;border-radius:10px;background:#f1efff;color:#433780}.layout-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px}.layout-card{padding:14px;border:1px solid #dfe3ed;border-radius:12px}.layout-preview{display:block;height:70px;margin-bottom:8px;border-radius:8px;background:#eceaf8}.z h3{margin-top:22px}
</style><?php }

function zcbx_background_controls($s, $prefix, $title) {
    echo '<div class="zcbx-background-card zcbx-refined-card"><h3>' . esc_html($title) . '</h3><div class="zcbx-control-preview-grid"><div class="zcbx-control-column">';
    zcbx_on($s, $prefix . '_background_enabled', 'Enable background');
    zcbx_media($s, $prefix . '_background_image', 'Background image');
    zcbx_media($s, $prefix . '_background_mobile_image', 'Mobile background image');
    zcbx_sel($s, $prefix . '_background_repeat', 'Repeat', array('no-repeat'=>'No repeat','repeat'=>'Repeat','repeat-x'=>'Repeat X','repeat-y'=>'Repeat Y','space'=>'Space','round'=>'Round'));
    zcbx_sel($s, $prefix . '_background_attachment', 'Attachment', array('scroll'=>'Scroll','fixed'=>'Fixed','local'=>'Local'));
    zcbx_sel($s, $prefix . '_background_size', 'Size', array('auto'=>'Auto','cover'=>'Cover','contain'=>'Contain','100%'=>'100%'));
    zcbx_sel($s, $prefix . '_background_position', 'Position preset', array('center center'=>'Center','top center'=>'Top center','top left'=>'Top left','top right'=>'Top right','bottom center'=>'Bottom center','bottom left'=>'Bottom left','bottom right'=>'Bottom right'));
    zcbx_range($s, $prefix . '_background_position_x', 'Horizontal position', 0, 100, 1, '%');
    zcbx_range($s, $prefix . '_background_position_y', 'Vertical position', 1, 1000, 1, '%');
    zcbx_range($s, $prefix . '_background_zoom', 'Zoom', 25, 300, 1, '%');
    zcbx_range($s, $prefix . '_background_opacity', 'Image opacity', 0, 1, .05);
    zcbx_range($s, $prefix . '_background_blur', 'Image blur', 0, 30, 1, 'px');
    zcbx_color($s, $prefix . '_background_overlay', 'Overlay color', $prefix . '_background_overlay_opacity');
    zcbx_sel($s, $prefix . '_background_overlay_type', 'Overlay type', array('solid'=>'Solid','gradient'=>'Gradient','glass'=>'Glass'));
    zcbx_sel($s, $prefix . '_background_parallax', 'Parallax', array('off'=>'Off','subtle'=>'Subtle','medium'=>'Medium','strong'=>'Strong'));
    echo '</div><aside class="zcbx-preview-column">';
    zcbx_preview($prefix . '-background', $title . ' Preview');
    echo '</aside></div></div>';
}
function zcbx_identity_card_controls($s) {
    echo '<div class="zcbx-background-card zcbx-refined-card"><h3>Identity Card Background</h3><div class="zcbx-control-preview-grid"><div class="zcbx-control-column">';
    zcbx_media($s, 'profile_card_image', 'Background image');
    zcbx_sel($s, 'profile_card_image_repeat', 'Repeat', array('no-repeat'=>'No repeat','repeat'=>'Repeat','repeat-x'=>'Repeat X','repeat-y'=>'Repeat Y'));
    zcbx_range($s, 'profile_card_image_x', 'Horizontal position', 0, 100, 1, '%');
    zcbx_range($s, 'profile_card_image_y', 'Vertical position', 1, 1000, 1, '%');
    zcbx_range($s, 'profile_card_image_zoom', 'Zoom', 25, 300, 1, '%');
    zcbx_range($s, 'profile_card_image_opacity', 'Image opacity', 0, 1, .05);
    zcbx_range($s, 'profile_card_image_blur', 'Image blur', 0, 30, 1, 'px');
    zcbx_sel($s, 'profile_card_image_fit', 'Fit', array('cover'=>'Cover','contain'=>'Contain','fill'=>'Stretch / Fill','original'=>'Original size'));
    zcbx_color($s, 'profile_card_image_overlay', 'Overlay color', 'profile_card_image_overlay_opacity');
    zcbx_sel($s, 'profile_card_image_overlay_type', 'Overlay type', array('solid'=>'Solid','gradient'=>'Gradient','glass'=>'Glass'));
    echo '</div><aside class="zcbx-preview-column">'; zcbx_preview('profile-card', 'Identity Card Preview'); echo '</aside></div></div>';
}

function zcbx_cover_controls($s, $prefix, $title) {
    $k = $prefix . '_cover_image_';
    echo '<div class="zcbx-background-card zcbx-refined-card"><h3>' . esc_html($title) . '</h3><div class="zcbx-control-preview-grid"><div class="zcbx-control-column">';
    zcbx_media($s, $prefix . '_cover_image', 'Cover image');
    zcbx_media($s, $prefix . '_cover_mobile_image', 'Mobile cover image');
    zcbx_sel($s, $k . 'repeat', 'Repeat', array('no-repeat'=>'No repeat','repeat'=>'Repeat','repeat-x'=>'Repeat X','repeat-y'=>'Repeat Y','space'=>'Space','round'=>'Round'));
    zcbx_sel($s, $k . 'attachment', 'Attachment', array('scroll'=>'Scroll','fixed'=>'Fixed','local'=>'Local'));
    zcbx_sel($s, $k . 'position', 'Position preset', array('center center'=>'Center','top center'=>'Top center','top left'=>'Top left','top right'=>'Top right','bottom center'=>'Bottom center','bottom left'=>'Bottom left','bottom right'=>'Bottom right'));
    zcbx_range($s, $k . 'x', 'Horizontal position', 0, 100, 1, '%');
    zcbx_range($s, $k . 'y', 'Vertical position', 1, 1000, 1, '%');
    zcbx_range($s, $k . 'zoom', 'Zoom', 25, 300, 1, '%');
    zcbx_range($s, $k . 'opacity', 'Image opacity', 0, 1, .05);
    zcbx_range($s, $k . 'blur', 'Image blur', 0, 30, 1, 'px');
    zcbx_sel($s, $k . 'fit', 'Fit', array('cover'=>'Cover','contain'=>'Contain','fill'=>'Stretch / Fill','original'=>'Original size'));
    zcbx_color($s, $k . 'overlay', 'Overlay color', $k . 'overlay_opacity');
    zcbx_sel($s, $k . 'overlay_type', 'Overlay type', array('solid'=>'Solid','gradient'=>'Gradient','glass'=>'Glass'));
    zcbx_sel($s, $k . 'parallax', 'Parallax', array('off'=>'Off','subtle'=>'Subtle','medium'=>'Medium','strong'=>'Strong'));
    echo '</div><aside class="zcbx-preview-column">';
    zcbx_preview($prefix . '-cover', $title . ' Preview');
    echo '</aside></div></div>';
}

function zcbx_diagnostics_panel(){
 $d=\ZinCelestial\BuddyX\Admin\Diagnostics::snapshot();$yes='<strong style="color:#167c3a">Yes</strong>';$no='<strong style="color:#bb1e31">No</strong>';
 echo '<section class="zcbx-admin-panel" data-panel="diagnostics"><h2>System Diagnostics</h2><p class="note">Read-only platform health information. This panel does not change settings or plugin data.</p>';
 echo '<h3>Environment</h3><table class="widefat striped"><tbody>';foreach(array('Theme version'=>$d['theme_version']??'','WordPress version'=>$d['wordpress']??'','PHP version'=>$d['php']??'','Schema version'=>$d['schema_version']??0)as$l=>$v)echo'<tr><th scope="row">'.esc_html($l).'</th><td><code>'.esc_html((string)$v).'</code></td></tr>';echo'</tbody></table>';
 echo '<h3>Detected Integrations</h3><table class="widefat striped"><thead><tr><th>Integration</th><th>Detected</th></tr></thead><tbody>';foreach((array)($d['plugins']??array())as$k=>$v)echo'<tr><th scope="row">'.esc_html(ucwords(str_replace(array('-','_'),' ',$k))).'</th><td>'.($v?$yes:$no).'</td></tr>';echo'</tbody></table>';
 echo '<h3>Services</h3><table class="widefat striped"><thead><tr><th>Service</th><th>Available</th></tr></thead><tbody>';foreach((array)($d['services']??array())as$k=>$v)echo'<tr><th scope="row">'.esc_html(ucwords(str_replace(array('-','_'),' ',$k))).'</th><td>'.($v?$yes:$no).'</td></tr>';echo'</tbody></table>';
 $x=(array)($d['save_engine']??array());$time=!empty($x['last_good_timestamp'])?wp_date('Y-m-d H:i:s T',(int)$x['last_good_timestamp']):'Not available';echo'<h3>Protected Save Engine</h3><table class="widefat striped"><tbody><tr><th>Protected</th><td>'.(!empty($x['protected'])?$yes:$no).'</td></tr><tr><th>Save handler registered</th><td>'.(!empty($x['handler_registered'])?$yes:$no).'</td></tr><tr><th>Last-known-good snapshot</th><td>'.(!empty($x['last_good_available'])?$yes:$no).'</td></tr><tr><th>Last snapshot time</th><td><code>'.esc_html($time).'</code></td></tr></tbody></table></section>';
}
function zcbx_dashboard_surface() {
    $d = \ZinCelestial\BuddyX\Admin\Diagnostics::snapshot();
    $widgets = (array) ( $d['dashboard_widgets'] ?? array() );
    $services = (array) ( $d['services'] ?? array() );
    $bp = (array) ( $d['buddypress'] ?? array() );
    $wc = (array) ( $d['woocommerce'] ?? array() );
    echo '<section class="zcbx-admin-panel" data-panel="dashboard"><h2>Dashboard</h2><p class="note">Read-only platform overview. No settings or plugin data are changed here.</p>';
    echo '<div class="zcbx-background-manager">';
    foreach ( $widgets as $slug => $widget ) {
        $enabled = ! empty( $widget['enabled'] );
        echo '<article class="zcbx-background-card"><h3>' . esc_html( $widget['title'] ?? $slug ) . '</h3>';
        echo '<p>' . esc_html( $widget['description'] ?? '' ) . '</p>';
        echo '<p><strong>Status:</strong> ' . ( $enabled ? '<span style="color:#167c3a">Available</span>' : '<span style="color:#bb1e31">Not available</span>' ) . '</p>';
        if ( 'platform-health' === $slug ) {
            $available = count( array_filter( $services ) );
            echo '<p><strong>Theme:</strong> <code>' . esc_html( (string) ( $d['theme_version'] ?? '' ) ) . '</code></p>';
            echo '<p><strong>Services available:</strong> ' . esc_html( (string) $available ) . ' / ' . esc_html( (string) count( $services ) ) . '</p>';
        } elseif ( 'buddypress-services' === $slug ) {
            foreach ( $bp as $name => $value ) echo '<p><strong>' . esc_html( ucwords( str_replace( '_', ' ', $name ) ) ) . ':</strong> ' . ( $value ? 'Yes' : 'No' ) . '</p>';
        } elseif ( 'woocommerce-services' === $slug ) {
            foreach ( $wc as $name => $value ) echo '<p><strong>' . esc_html( ucwords( str_replace( '_', ' ', $name ) ) ) . ':</strong> ' . ( $value ? 'Yes' : 'No' ) . '</p>';
        }
        echo '</article>';
    }
    echo '</div></section>';
}

function zcbx_admin_panels() {
    return array(
        'dashboard'        => array( 'label' => 'Dashboard', 'readonly' => true ),
        'libraries'        => array( 'label' => 'Libraries', 'readonly' => true ),
        'member-directory' => array( 'label' => 'Member Directory Experience', 'readonly' => false ),
        'header'           => array( 'label' => 'Header & Cover', 'readonly' => false ),
        'backgrounds'      => array( 'label' => 'Background Manager', 'readonly' => false ),
        'cover-images'     => array( 'label' => 'Header Cover Images', 'readonly' => false ),
        'card'             => array( 'label' => 'Identity Card', 'readonly' => false ),
        'avatar'           => array( 'label' => 'Avatar', 'readonly' => false ),
        'profile-menu'     => array( 'label' => 'Profile Menu', 'readonly' => false ),
        'icons'            => array( 'label' => 'Signature Icons', 'readonly' => false ),
        'items'            => array( 'label' => 'Menu Items', 'readonly' => false ),
        'visibility'       => array( 'label' => 'Profile Content', 'readonly' => false ),
        'effects'          => array( 'label' => 'Effects', 'readonly' => false ),
        'widgets'          => array( 'label' => 'Widget Titles', 'readonly' => false ),
        'subheader'        => array( 'label' => 'Site Sub Header', 'readonly' => false ),
        'surfaces'         => array( 'label' => 'Content Surfaces', 'readonly' => false ),
        'diagnostics'      => array( 'label' => 'System Diagnostics', 'readonly' => true ),
        'tools'            => array( 'label' => 'System Tools', 'readonly' => true ),
    );
}

function zcbx_extract_admin_panel( $html, $panel ) {
    $panel = sanitize_key( $panel );
    $pattern = '~<section class="zcbx-admin-panel" data-panel="' . preg_quote( $panel, '~' ) . '">.*?</section>~s';
    if ( preg_match( $pattern, $html, $match ) ) return $match[0];
    return '';
}

function zcbx_page() {
    zcbx_admin_critical_style();
    $s = zcbx_settings();
    $panel_registry = zcbx_admin_panels();
    $tabs = wp_list_pluck( $panel_registry, 'label' );
    $active_panel = isset( $_GET['zcbx-panel'] ) ? sanitize_key( wp_unslash( $_GET['zcbx-panel'] ) ) : 'dashboard';
    if ( ! isset( $tabs[ $active_panel ] ) ) $active_panel = 'dashboard';
    echo '<div class="wrap z zcbx-panels-ready" data-active-panel="' . esc_attr( $active_panel ) . '"><header><div><h1>ZinCelestial Community Experience Platform</h1><p>Integrated Platform Foundation v' . esc_html(ZCBX_VERSION) . '</p></div><span>Premium · Modern · Fun</span></header><nav class="ztabs">';
    foreach ($tabs as $key => $label) { ?>
        <a class="zcbx-admin-nav-button<?php echo $active_panel === $key ? ' active' : ''; ?>" role="tab" aria-selected="<?php echo $active_panel === $key ? 'true' : 'false'; ?>" tabindex="<?php echo $active_panel === $key ? '0' : '-1'; ?>" data-tab="<?php echo esc_attr($key); ?>" href="<?php echo esc_url( add_query_arg( array( 'page' => 'zcbx-control', 'zcbx-panel' => $key ), admin_url( 'themes.php' ) ) ); ?>" aria-label="<?php echo esc_attr($label); ?>" data-tooltip="<?php echo esc_attr($label); ?>"><?php echo zcbx_admin_icon($key); ?><span class="screen-reader-text"><?php echo esc_html($label); ?></span></a>
    <?php }
    echo '</nav>';
    ob_start();

    zcbx_dashboard_surface();

    $library_summary = \ZinCelestial\BuddyX\DesignSystem\LibraryCatalog::summary();
    echo '<section class="zcbx-admin-panel" data-panel="libraries"><h2>ZinCelestial Libraries</h2><p class="note">One coordinated administration area for reusable interface assets. Existing settings and frontend behavior remain unchanged.</p><nav class="zcbx-library-nav" role="tablist" aria-label="ZinCelestial libraries"><button type="button" class="active" role="tab" aria-selected="true" aria-controls="zcbx-library-elements" id="zcbx-library-tab-elements" data-library-tab="elements">Element Library <span>' . esc_html( (string) $library_summary['elements'] ) . '</span></button><button type="button" role="tab" aria-selected="false" aria-controls="zcbx-library-components" id="zcbx-library-tab-components" data-library-tab="components">Component Library <span>' . esc_html( (string) $library_summary['components'] ) . '</span></button><button type="button" role="tab" aria-selected="false" aria-controls="zcbx-library-icons" id="zcbx-library-tab-icons" data-library-tab="icons">Signature Icon Library <span>' . esc_html( (string) $library_summary['icons'] ) . '</span></button></nav><div class="zcbx-library-grid">';
    echo '<article class="zcbx-library-card zcbx-library-panel active" id="zcbx-library-elements" role="tabpanel" aria-labelledby="zcbx-library-tab-elements" tabindex="0" aria-hidden="false" data-library-panel="elements"><h3>Element Library</h3><p>Read-only catalog of core interface elements and states.</p><div class="zcbx-catalog-grid">';
    foreach ( \ZinCelestial\BuddyX\DesignSystem\LibraryCatalog::elements() as $key => $item ) echo '<div class="zcbx-catalog-item"><strong>' . esc_html( $item['label'] ) . '</strong><span>' . esc_html( $item['category'] ) . '</span><code>' . esc_html( $key ) . '</code><em>' . esc_html( $item['status'] ) . '</em></div>';
    echo '</div></article>';
    echo '<article class="zcbx-library-card zcbx-library-panel" id="zcbx-library-components" role="tabpanel" aria-labelledby="zcbx-library-tab-components" tabindex="0" hidden aria-hidden="true" data-library-panel="components"><h3>Component Library</h3><p>Read-only catalog of reusable coordinated theme components.</p><div class="zcbx-catalog-grid">';
    foreach ( \ZinCelestial\BuddyX\DesignSystem\LibraryCatalog::components() as $key => $item ) echo '<div class="zcbx-catalog-item"><strong>' . esc_html( $item['label'] ) . '</strong><span>' . esc_html( $item['category'] ) . '</span><code>' . esc_html( $key ) . '</code><em>' . esc_html( $item['status'] ) . '</em></div>';
    echo '</div></article>';
    echo '<article class="zcbx-library-card zcbx-library-card--icons zcbx-library-panel" id="zcbx-library-icons" role="tabpanel" aria-labelledby="zcbx-library-tab-icons" tabindex="0" hidden aria-hidden="true" data-library-panel="icons"><h3>Signature Icon Library</h3><p>Accessible ZinCelestial signature icons with stable names, categories, and reusable rendering.</p>';
    $icon_health = \ZinCelestial\BuddyX\DesignSystem\SignatureIconRegistry::diagnostics();
    echo '<div class="zcbx-icon-health zcbx-icon-health--' . esc_attr( $icon_health['status'] ) . '"><strong>Registry health: ' . esc_html( ucfirst( $icon_health['status'] ) ) . '</strong><span>' . esc_html( (string) $icon_health['icons'] ) . ' icons</span><span>' . esc_html( (string) $icon_health['categories'] ) . ' categories</span><span>' . esc_html( (string) $icon_health['aliases'] ) . ' aliases</span><span>' . esc_html( (string) $icon_health['contexts'] ) . ' contexts</span></div>';
    echo '<div class="zcbx-icon-library__tools"><label><span class="screen-reader-text">Search signature icons</span><input type="search" class="zcbx-icon-library__search" placeholder="Search icons"></label><label><span class="screen-reader-text">Filter icon category</span><select class="zcbx-icon-library__filter"><option value="">All categories</option>';
    foreach ( \ZinCelestial\BuddyX\DesignSystem\SignatureIconRegistry::categories() as $category ) echo '<option value="' . esc_attr( strtolower( $category ) ) . '">' . esc_html( $category ) . '</option>';
    echo '</select></label></div><p class="zcbx-icon-library__count" aria-live="polite"></p><div class="zcbx-icon-library" role="list">';
    foreach ( \ZinCelestial\BuddyX\DesignSystem\SignatureIconRegistry::icons() as $icon_key => $icon ) {
        echo '<div class="zcbx-icon-library__item" role="listitem" data-icon-key="' . esc_attr( $icon_key ) . '" data-icon-label="' . esc_attr( strtolower( $icon['label'] ) ) . '" data-icon-category="' . esc_attr( strtolower( $icon['category'] ) ) . '"><span class="zcbx-icon-library__preview">' . \ZinCelestial\BuddyX\DesignSystem\SignatureIconRegistry::render( $icon_key, $icon['label'], false ) . '</span><strong>' . esc_html( $icon['label'] ) . '</strong><span>' . esc_html( $icon['category'] ) . '</span><code>' . esc_html( $icon_key ) . '</code><span class="zcbx-icon-library__actions"><button type="button" class="button button-small zcbx-icon-copy" data-copy-icon="' . esc_attr( $icon_key ) . '">Copy key</button><button type="button" class="button button-small zcbx-icon-copy" data-copy-icon="[zcbx_icon name=&quot;' . esc_attr( $icon_key ) . '&quot; size=&quot;24&quot;]">Copy shortcode</button></span></div>';
    }
    echo '</div>';
    echo '<div class="zcbx-icon-playground"><div><h4>Icon Preview Playground</h4><p>Preview approved presentation variants without changing saved settings.</p></div><div class="zcbx-icon-playground__controls"><label><span>Icon</span><select class="zcbx-icon-playground__icon">';
    foreach ( \ZinCelestial\BuddyX\DesignSystem\SignatureIconRegistry::icons() as $preview_key => $preview_icon ) echo '<option value="' . esc_attr( $preview_key ) . '" data-path="' . esc_attr( $preview_icon['path'] ) . '">' . esc_html( $preview_icon['label'] ) . '</option>';
    echo '</select></label><label><span>Variant</span><select class="zcbx-icon-playground__variant"><option value="plain">Plain</option><option value="badge">Badge</option><option value="glow">Glow</option><option value="button">Button</option></select></label><label><span>Size</span><input type="range" aria-label="Icon preview size" class="zcbx-icon-playground__size" min="12" max="96" value="32"><output>32px</output></label><label><span>Color</span><input type="color" aria-label="Icon preview color" class="zcbx-icon-playground__color" value="#5546d8"></label></div><div class="zcbx-icon-playground__stage" aria-live="polite"><span class="zcbx-signature-icon-wrap zcbx-signature-icon-wrap--plain" style="--zcbx-icon-size:32px;--zcbx-icon-color:#5546d8;width:32px;height:32px;color:#5546d8">' . \ZinCelestial\BuddyX\DesignSystem\SignatureIconRegistry::render( 'command-dashboard' ) . '</span></div><code class="zcbx-icon-playground__shortcode">[zcbx_icon name="command-dashboard" size="32" variant="plain" color="#5546d8"]</code><button type="button" class="button zcbx-icon-playground__copy">Copy preview shortcode</button></div>';
    echo '<div class="zcbx-icon-library__usage"><h4>Runtime usage</h4><code>[zcbx_icon name="activity-pulse" size="24"]</code><p>Use decorative="false" and provide a label when the icon communicates meaning. Developers can also use <code>zcbx_signature_icon()</code> or <code>zcbx_signature_icon_for_context()</code>.</p></div>';

    echo '<div class="zcbx-icon-contexts"><div class="zcbx-icon-contexts__header"><div><h4>Context Assignment Matrix</h4><p>Read-only map of registered interface contexts to stable icon keys.</p></div><a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=zcbx_export_signature_icons' ), 'zcbx_export_signature_icons' ) ) . '">Export registry JSON</a></div><div class="zcbx-icon-contexts__grid" role="list">';
    foreach ( \ZinCelestial\BuddyX\DesignSystem\SignatureIconRegistry::context_map() as $context => $icon_key ) {
        $resolved = \ZinCelestial\BuddyX\DesignSystem\SignatureIconRegistry::resolve( $icon_key );
        echo '<div class="zcbx-icon-context" role="listitem"><span class="zcbx-icon-context__preview">' . \ZinCelestial\BuddyX\DesignSystem\SignatureIconRegistry::render( $resolved ) . '</span><code>' . esc_html( $context ) . '</code><span aria-hidden="true">→</span><strong>' . esc_html( $resolved ) . '</strong><button type="button" class="button button-small zcbx-icon-copy" data-copy-icon="' . esc_attr( $resolved ) . '">Copy key</button></div>';
    }
    echo '</div></div>';
    echo '</div></article></div></section>';


    echo '<section class="zcbx-admin-panel" data-panel="member-directory"><h2>Member Directory Experience</h2><p class="note">Controls the testable Member Command Deck, Grid and Compact views, Signature card accents, and GamiPress achievement presentation. Uses the existing schema-version-1 settings system.</p>';
    zcbx_on($s,'member_directory_pizzazz','Enable Community Pizzazz');
    zcbx_sel($s,'member_directory_default_view','Default directory view',array('grid'=>'Grid','compact'=>'Compact'));
    zcbx_on($s,'member_directory_allow_view_switch','Allow visitors to switch views');
    zcbx_on($s,'member_directory_remember_view','Remember each visitor view in the browser');
    zcbx_on($s,'member_directory_tablet_compact','Use Compact view on tablets by default');
    echo '<h3>Command Surfaces</h3>';
    zcbx_on($s,'member_directory_command_deck','Enable Member Command Deck');
    zcbx_on($s,'member_directory_status_ribbon','Enable community status ribbon');
    zcbx_sel($s,'member_directory_glass','Glass treatment',array('off'=>'Off','subtle'=>'Subtle','enhanced'=>'Enhanced'));
    echo '<h3>Signature Member Cards</h3>';
    zcbx_on($s,'member_directory_card_accents','Enable Signature card accents');
    zcbx_on($s,'member_directory_avatar_rings','Enable Signature avatar rings');
    zcbx_sel($s,'member_directory_accent_intensity','Accent intensity',array('off'=>'Off','subtle'=>'Subtle','enhanced'=>'Enhanced'));
    zcbx_sel($s,'member_directory_hover_motion','Hover movement',array('off'=>'Off','subtle'=>'Subtle','enhanced'=>'Enhanced'));
    echo '<h3>Achievements</h3>';
    zcbx_on($s,'member_directory_achievement_constellation','Enable achievement constellation');
    zcbx_range($s,'member_directory_max_achievements','Maximum visible achievement groups',1,12,1);
    echo '</section>';

    echo '<section class="zcbx-admin-panel" data-panel="header"><h2>Header & Cover</h2>';
    zcbx_on($s,'profile_header_enabled','Enable custom profile header');
    echo '<div class="layout-grid">'; foreach (zcbx_profile_layouts() as $key=>$label) echo '<label class="layout-card"><input type="radio" name="zcbx_settings[profile_header_layout]" value="'.esc_attr($key).'" '.checked($s['profile_header_layout'],$key,false).'><span class="layout-preview layout-preview-' . esc_attr($key) . '"><i></i><b></b><em></em></span><strong>'.esc_html($label).'</strong></label>'; echo '</div>';
    zcbx_sel($s,'profile_cover_width','Cover width',array('contained'=>'Contained','content'=>'Content width','full'=>'Full browser width'));
    zcbx_range($s,'profile_cover_height_px','Cover height',120,800,1,'px');
    zcbx_sel($s,'profile_cover_effect','Cover treatment',array('theme'=>'Theme','none'=>'None','soft'=>'Soft gradient','strong'=>'Strong gradient','accent'=>'Accent','frosted'=>'Frosted','glass'=>'Glass','colored-glass'=>'Colored glass','christmas'=>'Christmas','halloween'=>'Halloween','frosted-crystal'=>'Frosted crystal','aurora'=>'Aurora','neon'=>'Neon glow'));
    zcbx_color($s,'profile_cover_effect_color','Effect color','profile_cover_effect_opacity'); zcbx_range($s,'profile_cover_effect_blur','Effect blur',0,30,1,'px');
    echo '</section>';

    echo '<section class="zcbx-admin-panel" data-panel="backgrounds"><h2>Background Manager</h2><p class="note">Member and group backgrounds share one manager while retaining separate saved settings.</p><div class="zcbx-background-manager">';
    zcbx_background_controls($s,'profile','Member Background'); zcbx_background_controls($s,'group','Group Background');
    echo '</div></section>';

    echo '<section class="zcbx-admin-panel" data-panel="cover-images"><h2>Header Cover Images</h2><p class="note">Position and preview member and group hero-cover images.</p><div class="zcbx-background-manager">';
    zcbx_cover_controls($s,'profile','Member Header Cover'); zcbx_cover_controls($s,'group','Group Header Cover');
    echo '</div></section>';

    echo '<section class="zcbx-admin-panel" data-panel="card"><h2>Identity Card</h2>'; zcbx_range($s,'profile_card_overlap','Card overlap',80,400,1,'px'); zcbx_color($s,'profile_card_bg','Card background','profile_card_bg_opacity'); zcbx_color($s,'profile_card_border','Card border','profile_card_border_opacity'); zcbx_range($s,'profile_card_radius','Card radius',0,40,1,'px'); zcbx_range($s,'profile_card_padding','Card padding',0,80,1,'px'); zcbx_sel($s,'profile_card_shadow','Card shadow',array('none'=>'None','soft'=>'Soft','elevated'=>'Elevated')); zcbx_on($s,'profile_card_transparent','Transparent card'); zcbx_on($s,'profile_card_remove_border','Remove card border'); zcbx_identity_card_controls($s); echo '</section>';
    echo '<section class="zcbx-admin-panel" data-panel="avatar"><h2>Avatar</h2>'; zcbx_range($s,'profile_avatar_size_px','Avatar size',64,220,1,'px'); zcbx_sel($s,'profile_avatar_shape','Avatar shape',array('circle'=>'Circle','soft-square'=>'Soft square','rounded-square'=>'Rounded square','square'=>'Square','squircle'=>'Squircle','hexagon'=>'Hexagon','diamond'=>'Diamond','shield'=>'Shield','arch'=>'Arch')); zcbx_sel($s,'profile_avatar_ring','Avatar ring',array('none'=>'None','surface'=>'Surface','accent'=>'Accent','double'=>'Double','glow'=>'Glow','glass'=>'Glass','pulse'=>'Pulse','neon'=>'Neon','crystal'=>'Crystal','celestial'=>'Celestial')); zcbx_range($s,'profile_avatar_opacity','Avatar opacity',0,1,.05); echo '</section>';

    echo '<section class="zcbx-admin-panel" data-panel="profile-menu"><h2>Profile Menu</h2>'; zcbx_sel($s,'profile_nav_position','Position',array('below-card'=>'Below identity card','inside-card-bottom'=>'Inside identity-card bottom','above-card'=>'Above identity card','cover-bottom'=>'Lower cover area')); zcbx_sel($s,'profile_menu_style','Style',array('tabs'=>'Tabs','icons'=>'Signature icons','icons-tooltip'=>'Icons + tooltips','scroll'=>'Horizontal scroll','swipe'=>'Swipe','swipe-arrows'=>'Swipe + arrows','premium-pills'=>'Premium pills','glass-icons'=>'Glass icons','floating-nav'=>'Floating navigation')); zcbx_sel($s,'profile_menu_alignment','Alignment',array('left'=>'Left','center'=>'Center','right'=>'Right')); zcbx_range($s,'profile_menu_font_size','Text size',12,40,1,'px'); zcbx_sel($s,'profile_menu_width','Width',array('auto'=>'Auto','identity'=>'Identity','contained'=>'Contained','cover'=>'Cover','full'=>'Full')); zcbx_range($s,'profile_menu_height','Height',52,160,1,'px'); zcbx_range($s,'profile_menu_offset_y','Vertical offset',-150,150,1,'px'); zcbx_range($s,'profile_menu_space_above','Space above',0,80,1,'px'); zcbx_range($s,'profile_menu_space_below','Space below',0,80,1,'px'); zcbx_color($s,'profile_menu_bg_color','Background','profile_menu_bg_opacity'); zcbx_on($s,'profile_menu_transparent','Transparent background'); zcbx_on($s,'profile_menu_remove_border','Remove border'); zcbx_color($s,'profile_menu_border_color','Border','profile_menu_border_opacity'); zcbx_range($s,'profile_menu_border_width','Border width',0,8,1,'px'); zcbx_range($s,'profile_menu_radius','Radius',0,40,1,'px'); zcbx_range($s,'profile_menu_blur','Blur',0,30,1,'px'); echo '</section>';
    echo '<section class="zcbx-admin-panel" data-panel="icons"><h2>Signature Icons</h2>'; zcbx_sel($s,'profile_icon_style','Icon style',array('classic'=>'Classic','outline'=>'Outline','duotone'=>'Duotone','filled'=>'Filled')); zcbx_range($s,'profile_menu_icon_size','Icon size',14,48,1,'px'); zcbx_color($s,'profile_menu_icon_color','Icon color','profile_menu_icon_opacity'); zcbx_color($s,'profile_menu_hover_color','Hover color'); zcbx_color($s,'profile_menu_active_color','Active color'); echo '</section>';
    echo '<section class="zcbx-admin-panel" data-panel="items"><h2>Menu Items</h2><label class="f zcbx-field-row"><span><strong>Order</strong></span><input type="text" name="zcbx_settings[profile_menu_order]" value="'.esc_attr($s['profile_menu_order']).'"></label><label class="f zcbx-field-row"><span><strong>Hidden items</strong></span><input type="text" name="zcbx_settings[profile_menu_hidden]" value="'.esc_attr($s['profile_menu_hidden']).'"></label></section>';
    echo '<section class="zcbx-admin-panel" data-panel="visibility"><h2>Profile Content</h2>'; zcbx_on($s,'profile_show_status','Show status'); zcbx_on($s,'profile_show_last_active','Show last active'); zcbx_on($s,'profile_show_member_type','Show member type'); zcbx_on($s,'profile_show_social','Show social links'); zcbx_on($s,'profile_show_stats','Show stats'); echo '</section>';
    echo '<section class="zcbx-admin-panel" data-panel="effects"><h2>Effects</h2>'; zcbx_sel($s,'profile_cover_effect','Cover effect',array('theme'=>'Theme','none'=>'None','glass'=>'Glass','colored-glass'=>'Colored glass','christmas'=>'Christmas','halloween'=>'Halloween','frosted-crystal'=>'Frosted crystal','aurora'=>'Aurora','neon'=>'Neon glow')); zcbx_color($s,'profile_cover_effect_color','Effect color','profile_cover_effect_opacity'); zcbx_range($s,'profile_cover_effect_blur','Effect blur',0,30,1,'px'); echo '</section>';
    echo '<section class="zcbx-admin-panel" data-panel="widgets"><h2>Widget Titles</h2><div class="zcbx-control-preview-grid"><div class="zcbx-control-column">'; zcbx_color($s,'widget_title_bg','Background','widget_title_bg_opacity'); zcbx_color($s,'widget_title_color','Text color','widget_title_color_opacity'); zcbx_range($s,'widget_title_font_size','Font size',10,48,1,'px'); zcbx_range($s,'widget_title_font_weight','Font weight',100,900,100); zcbx_range($s,'widget_title_radius','Radius',0,40,1,'px'); zcbx_media($s,'widget_title_image','Background image'); echo '</div><aside class="zcbx-preview-column"><div class="zcbx-widget-preview"><strong>Widget Title Preview</strong><div class="zcbx-widget-title-sample">Recent Topics</div><div class="zcbx-widget-body-sample"></div></div></aside></div></section>';
    echo '<section class="zcbx-admin-panel" data-panel="subheader"><h2>Site Sub Header</h2>'; zcbx_on($s,'subheader_enabled','Enable styling'); zcbx_sel($s,'subheader_style','Breadcrumb style',array('classic'=>'Classic','minimal'=>'Minimal','icons'=>'Icons','pills'=>'Pills','zincelestial'=>'ZinCelestial')); zcbx_sel($s,'subheader_width','Width',array('contained'=>'Contained','content'=>'Content','full'=>'Full')); zcbx_range($s,'subheader_height','Height',32,240,1,'px'); zcbx_color($s,'subheader_bg','Background','subheader_bg_opacity'); zcbx_color($s,'subheader_text','Text color','subheader_text_opacity'); zcbx_color($s,'subheader_icon_color','Icon color'); zcbx_media($s,'subheader_image','Background image'); zcbx_range($s,'subheader_image_x','Image horizontal position',0,100,1,'%'); zcbx_range($s,'subheader_image_y','Image vertical position',0,100,1,'%'); zcbx_range($s,'subheader_image_opacity','Image opacity',0,1,.05); zcbx_range($s,'subheader_image_blur','Image blur',0,30,1,'px'); zcbx_sel($s,'subheader_image_fit','Image fit',array('cover'=>'Cover','contain'=>'Contain','fill'=>'Fill','original'=>'Original')); zcbx_range($s,'subheader_radius','Radius',0,40,1,'px'); zcbx_sel($s,'subheader_position','Position',array('normal'=>'Normal','sticky'=>'Sticky')); echo '</section>';
    echo '<section class="zcbx-admin-panel" data-panel="surfaces"><h2>Content Surfaces</h2><p class="note">Independent surface controls for Boxed and Full layouts, plus shared content panels.</p><h3>Boxed Layout</h3>'; zcbx_color($s,'boxed_surface_bg','Background color','boxed_surface_opacity'); zcbx_media($s,'boxed_surface_image','Background image'); zcbx_range($s,'boxed_surface_radius','Radius',0,60,1,'px'); echo '<h3>Full Layout</h3>'; zcbx_color($s,'full_surface_bg','Background color','full_surface_opacity'); zcbx_media($s,'full_surface_image','Background image'); zcbx_range($s,'full_surface_radius','Radius',0,60,1,'px'); echo '<h3>Shared Content Surfaces</h3>'; zcbx_on($s,'content_surface_transparent','Transparent content surfaces'); zcbx_color($s,'content_surface_bg','Surface color','content_surface_opacity'); zcbx_media($s,'content_surface_image','Surface image'); zcbx_range($s,'content_surface_image_x','Image horizontal position',0,100,1,'%'); zcbx_range($s,'content_surface_image_y','Image vertical position',0,100,1,'%'); zcbx_range($s,'content_surface_image_opacity','Image opacity',0,1,.05); zcbx_range($s,'content_surface_image_blur','Image blur',0,30,1,'px'); zcbx_sel($s,'content_surface_image_fit','Image fit',array('cover'=>'Cover','contain'=>'Contain','fill'=>'Fill','original'=>'Original')); zcbx_color($s,'content_surface_overlay','Overlay color','content_surface_overlay_opacity'); zcbx_range($s,'content_surface_radius','Surface radius',0,60,1,'px'); echo '</section>';
    zcbx_diagnostics_panel();echo '<section class="zcbx-admin-panel" data-panel="tools"><h2>System Tools</h2><p>Export settings before experimentation or restore defaults.</p><a class="button" href="'.esc_url(wp_nonce_url(admin_url('admin-post.php?action=zcbx_export'),'zcbx_export')).'">Export Settings</a> <a class="button" href="'.esc_url(wp_nonce_url(admin_url('admin-post.php?action=zcbx_reset_all'),'zcbx_reset_all')).'">Reset All</a></section>';

    $panel_buffer = ob_get_clean();
    $panel_html = zcbx_extract_admin_panel( $panel_buffer, $active_panel );
    if ( '' === $panel_html ) {
        $active_panel = 'dashboard';
        $panel_html = zcbx_extract_admin_panel( $panel_buffer, $active_panel );
    }
    $is_readonly = ! empty( $panel_registry[ $active_panel ]['readonly'] );
    if ( $is_readonly ) {
        echo $panel_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- trusted renderer output.
    } else {
        echo '<form class="zcbx-active-panel-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="zcbx_save_settings"><input type="hidden" name="zcbx_active_panel" value="' . esc_attr( $active_panel ) . '">';
        wp_nonce_field( 'zcbx_save_direct' );
        echo '<div class="zcbx-save-bar"><button type="submit" class="button button-primary">Save ZinCelestial Settings</button></div>';
        echo $panel_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- trusted renderer output.
        submit_button( 'Save ZinCelestial Settings' );
        echo '</form>';
    }
    echo '</div>';
}


function zcbx_export_signature_icons() {
    if ( ! current_user_can( 'manage_options' ) ) wp_die( esc_html__( 'You do not have permission to export the icon registry.', 'zincelestial-buddyx' ) );
    check_admin_referer( 'zcbx_export_signature_icons' );
    $payload = array(
        'schema_version' => 1,
        'theme' => 'ZinCelestial-BuddyX',
        'version' => ZCBX_VERSION,
        'icons' => \ZinCelestial\BuddyX\DesignSystem\SignatureIconRegistry::icons(),
        'aliases' => \ZinCelestial\BuddyX\DesignSystem\SignatureIconRegistry::aliases(),
        'contexts' => \ZinCelestial\BuddyX\DesignSystem\SignatureIconRegistry::context_map(),
    );
    nocache_headers();
    header( 'Content-Type: application/json; charset=utf-8' );
    header( 'Content-Disposition: attachment; filename="zincelestial-signature-icon-registry-' . sanitize_file_name( ZCBX_VERSION ) . '.json"' );
    echo wp_json_encode( $payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
    exit;
}
add_action( 'admin_post_zcbx_export_signature_icons', 'zcbx_export_signature_icons' );
