<?php
/** Build 29R.20 retired Community Layout boundary. @package ZinCelestial_BuddyX */
defined( 'ABSPATH' ) || exit;
function zcbx_29r20_unregister_community_sidebars() {
    foreach ( array( 'member', 'group' ) as $context ) {
        foreach ( array( 'left', 'right' ) as $side ) {
            foreach ( array( 'header', 'content', 'footer' ) as $region ) {
                unregister_sidebar( 'zcbx-' . $context . '-' . $side . '-' . $region );
            }
        }
    }
}
add_action( 'widgets_init', 'zcbx_29r20_unregister_community_sidebars', PHP_INT_MAX );
add_action( 'wp_loaded', 'zcbx_29r20_unregister_community_sidebars', PHP_INT_MAX );
function zcbx_29r20_remove_retired_layout_classes( array $classes ): array {
    return array_values( array_filter( $classes, static function ( $class ) {
        return 0 !== strpos( (string) $class, 'zcbx-community-layout-' );
    } ) );
}
add_filter( 'body_class', 'zcbx_29r20_remove_retired_layout_classes', 999 );
