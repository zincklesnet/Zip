<?php
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'zcbx_signature_icon' ) ) {
    function zcbx_signature_icon( string $key, string $label = '', bool $decorative = true ): string {
        return \ZinCelestial\BuddyX\DesignSystem\SignatureIconRegistry::render( $key, $label, $decorative );
    }
}

if ( ! function_exists( 'zcbx_signature_icon_for_context' ) ) {
    function zcbx_signature_icon_for_context( string $context, string $label = '', bool $decorative = true ): string {
        $key = \ZinCelestial\BuddyX\DesignSystem\SignatureIconRegistry::for_context( $context );
        return \ZinCelestial\BuddyX\DesignSystem\SignatureIconRegistry::render( $key, $label, $decorative );
    }
}
