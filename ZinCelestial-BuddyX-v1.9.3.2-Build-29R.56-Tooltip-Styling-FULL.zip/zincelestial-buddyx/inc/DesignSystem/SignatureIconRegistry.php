<?php
namespace ZinCelestial\BuddyX\DesignSystem;
defined( 'ABSPATH' ) || exit;

final class SignatureIconRegistry {
    public static function icons(): array {
        $icons = array(
            'command-dashboard' => array('label'=>'Command Dashboard','category'=>'Command','path'=>'M4 4h7v7H4z M13 4h7v4h-7z M13 10h7v10h-7z M4 13h7v7H4z'),
            'community-members' => array('label'=>'Community Members','category'=>'Community','path'=>'M16 20v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2 M9 10a4 4 0 1 0 0-8 4 4 0 0 0 0 8 M22 20v-2a4 4 0 0 0-3-3.87 M16 2.13a4 4 0 0 1 0 7.75'),
            'community-groups' => array('label'=>'Community Groups','category'=>'Community','path'=>'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8 M4 21v-2a6 6 0 0 1 6-6h4a6 6 0 0 1 6 6v2 M5 8H2 M22 8h-3'),
            'activity-pulse' => array('label'=>'Activity Pulse','category'=>'Community','path'=>'M3 12h4l2-7 4 14 2-7h6'),
            'profile-orbit' => array('label'=>'Profile Orbit','category'=>'Identity','path'=>'M12 13a4 4 0 1 0 0-8 4 4 0 0 0 0 8 M4 21a8 8 0 0 1 16 0 M2 12a10 10 0 0 0 20 0'),
            'identity-badge' => array('label'=>'Identity Badge','category'=>'Identity','path'=>'M12 2l3 3 4-.5.5 4 3 3-3 3-.5 4-4-.5-3 3-3-3-4 .5-.5-4-3-3 3-3 .5-4 4 .5z M9 12l2 2 4-4'),
            'settings-core' => array('label'=>'Core Settings','category'=>'System','path'=>'M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7 M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-2.83 2.83-.06-.06A1.7 1.7 0 0 0 15 19.4a1.7 1.7 0 0 0-1 .6v.1h-4v-.1a1.7 1.7 0 0 0-1-.6 1.7 1.7 0 0 0-1.88.34l-.06.06-2.83-2.83.06-.06A1.7 1.7 0 0 0 4.6 15a1.7 1.7 0 0 0-.6-1H4v-4h.1a1.7 1.7 0 0 0 .6-1 1.7 1.7 0 0 0-.34-1.88l-.06-.06 2.83-2.83.06.06A1.7 1.7 0 0 0 9 4.6a1.7 1.7 0 0 0 1-.6V4h4v.1a1.7 1.7 0 0 0 1 .6 1.7 1.7 0 0 0 1.88-.34l.06-.06 2.83 2.83-.06.06A1.7 1.7 0 0 0 19.4 9c.12.38.33.72.6 1h.1v4H20c-.27.28-.48.62-.6 1z'),
            'directory-grid-view' => array('label'=>'Grid View','category'=>'Command','path'=>'M4 4h6v6H4z M14 4h6v6h-6z M4 14h6v6H4z M14 14h6v6h-6z'),
            'directory-compact-view' => array('label'=>'Compact View','category'=>'Command','path'=>'M4 5h16v3H4z M4 10.5h16v3H4z M4 16h16v3H4z'),
            'directory-filter-active' => array('label'=>'Recently Active','category'=>'Command','path'=>'M12 3a9 9 0 1 0 9 9 M12 7v5l3 2 M17 3h4v4'),
            'directory-filter-newest' => array('label'=>'Newest Members','category'=>'Command','path'=>'M12 3v18 M3 12h18 M17 5h4v4'),
            'directory-filter-alphabetical' => array('label'=>'Alphabetical','category'=>'Command','path'=>'M4 19L9 5l5 14 M6 14h6 M16 6h5l-5 12h5'),
            'directory-filter-reset' => array('label'=>'Reset Filters','category'=>'Command','path'=>'M4 4v6h6 M5.5 9a8 8 0 1 1-1 6'),
            'friendship-add' => array('label'=>'Add Friend','category'=>'Community','path'=>'M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8 M2 21v-2a7 7 0 0 1 7-7h2 M18 8v8 M14 12h8'),
            'friendship-cancel' => array('label'=>'Cancel Friendship','category'=>'Community','path'=>'M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8 M2 21v-2a7 7 0 0 1 7-7h2 M15 9l6 6 M21 9l-6 6'),
            'library-elements' => array('label'=>'Element Library','category'=>'Library','path'=>'M4 4h6v6H4z M14 4h6v6h-6z M4 14h6v6H4z M14 14h6v6h-6z'),
            'library-components' => array('label'=>'Component Library','category'=>'Library','path'=>'M12 2l4 4-4 4-4-4z M6 12l4 4-4 4-4-4z M18 12l4 4-4 4-4-4z'),
            'library-signature' => array('label'=>'Signature Icon Library','category'=>'Library','path'=>'M12 2l2.2 6.8H21l-5.5 4 2.1 6.7-5.6-4.1-5.6 4.1 2.1-6.7-5.5-4h6.8z'),
            'status-success' => array('label'=>'Success Status','category'=>'Status','path'=>'M20 6L9 17l-5-5'),
            'status-warning' => array('label'=>'Warning Status','category'=>'Status','path'=>'M12 3L2 21h20z M12 9v5 M12 18h.01'),
            'status-info' => array('label'=>'Information Status','category'=>'Status','path'=>'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20 M12 10v7 M12 7h.01'),
            'action-add' => array('label'=>'Add Action','category'=>'Action','path'=>'M12 5v14 M5 12h14'),
            'action-edit' => array('label'=>'Edit Action','category'=>'Action','path'=>'M12 20h9 M16.5 3.5a2.12 2.12 0 0 1 3 3L8 18l-4 1 1-4z'),
            'action-search' => array('label'=>'Search Action','category'=>'Action','path'=>'M11 19a8 8 0 1 1 0-16 8 8 0 0 1 0 16 M21 21l-4.35-4.35'),
            'profile-activity' => array('label'=>'Profile Activity','category'=>'Profile Menu','path'=>'M3 12h4l2-7 4 14 2-7h6'),
            'profile-details' => array('label'=>'Profile Details','category'=>'Profile Menu','path'=>'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8 M4 21a8 8 0 0 1 16 0'),
            'profile-sites' => array('label'=>'Member Sites','category'=>'Profile Menu','path'=>'M4 5h16v14H4z M4 9h16 M8 5v14'),
            'profile-notifications' => array('label'=>'Notifications','category'=>'Profile Menu','path'=>'M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9 M10 21h4'),
            'profile-messages' => array('label'=>'Messages','category'=>'Profile Menu','path'=>'M3 5h18v14H3z M3 7l9 6 9-6'),
            'profile-friends' => array('label'=>'Friends','category'=>'Profile Menu','path'=>'M16 20v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2 M9 10a4 4 0 1 0 0-8 4 4 0 0 0 0 8 M21 20v-2a4 4 0 0 0-3-3.87'),
            'profile-groups' => array('label'=>'Groups','category'=>'Profile Menu','path'=>'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8 M4 21v-2a6 6 0 0 1 6-6h4a6 6 0 0 1 6 6v2'),
            'profile-forums' => array('label'=>'Forums','category'=>'Profile Menu','path'=>'M4 4h16v12H8l-4 4z M8 8h8 M8 12h5'),
            'profile-settings' => array('label'=>'Profile Settings','category'=>'Profile Menu','path'=>'M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7 M12 2v3 M12 19v3 M4.9 4.9L7 7 M17 17l2.1 2.1 M2 12h3 M19 12h3 M4.9 19.1L7 17 M17 7l2.1-2.1'),
            'profile-points' => array('label'=>'Points','category'=>'Profile Menu','path'=>'M12 2l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z'),
            'profile-ranks' => array('label'=>'Ranks','category'=>'Profile Menu','path'=>'M8 3h8v5a4 4 0 0 1-8 0z M6 5H3v2a4 4 0 0 0 4 4 M18 5h3v2a4 4 0 0 1-4 4 M12 12v5 M8 21h8 M9 17h6'),
            'group-home' => array('label'=>'Group Home','category'=>'Group Menu','path'=>'M3 11l9-8 9 8 M5 10v10h14V10 M9 20v-6h6v6'),
            'group-activity' => array('label'=>'Group Activity','category'=>'Group Menu','path'=>'M3 12h4l2-7 4 14 2-7h6'),
            'group-members' => array('label'=>'Group Members','category'=>'Group Menu','path'=>'M16 20v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2 M9 10a4 4 0 1 0 0-8 4 4 0 0 0 0 8 M21 20v-2a4 4 0 0 0-3-3.87'),
            'group-invite' => array('label'=>'Invite Members','category'=>'Group Menu','path'=>'M15 19v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2 M8 9a4 4 0 1 0 0-8 4 4 0 0 0 0 8 M19 8v6 M16 11h6'),
            'group-media' => array('label'=>'Group Media','category'=>'Group Menu','path'=>'M3 5h18v14H3z M3 15l5-5 4 4 3-3 6 6 M16 9h.01'),
            'group-forum' => array('label'=>'Group Forum','category'=>'Group Menu','path'=>'M4 4h16v12H8l-4 4z M8 8h8 M8 12h5'),
            'group-manage' => array('label'=>'Manage Group','category'=>'Group Menu','path'=>'M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7 M12 2v3 M12 19v3 M4.9 4.9L7 7 M17 17l2.1 2.1 M2 12h3 M19 12h3'),
        );
        return apply_filters( 'zcbx_signature_icon_registry', $icons );
    }

    public static function aliases(): array {
        return apply_filters( 'zcbx_signature_icon_aliases', array(
            'dashboard' => 'command-dashboard',
            'members' => 'community-members',
            'groups' => 'community-groups',
            'activity' => 'activity-pulse',
            'profile' => 'profile-orbit',
            'settings' => 'settings-core',
            'elements' => 'library-elements',
            'components' => 'library-components',
            'icons' => 'library-signature',
            'success' => 'status-success',
            'warning' => 'status-warning',
            'info' => 'status-info',
            'add' => 'action-add',
            'edit' => 'action-edit',
            'search' => 'action-search',
        ) );
    }

    public static function resolve( string $key ): string {
        $key = sanitize_key( $key );
        $icons = self::icons();
        if ( isset( $icons[ $key ] ) ) return $key;
        $aliases = self::aliases();
        return isset( $aliases[ $key ], $icons[ $aliases[ $key ] ] ) ? $aliases[ $key ] : 'library-signature';
    }

    public static function by_category( string $category ): array {
        $category = strtolower( sanitize_text_field( $category ) );
        return array_filter( self::icons(), static function( array $icon ) use ( $category ): bool {
            return strtolower( $icon['category'] ) === $category;
        } );
    }

    public static function context_map(): array {
        return apply_filters( 'zcbx_signature_icon_context_map', array(
            'admin.dashboard' => 'command-dashboard',
            'admin.libraries' => 'library-signature',
            'community.members' => 'community-members',
            'community.groups' => 'community-groups',
            'community.activity' => 'activity-pulse',
            'profile.activity' => 'profile-activity',
            'profile.details' => 'profile-details',
            'profile.sites' => 'profile-sites',
            'profile.notifications' => 'profile-notifications',
            'profile.messages' => 'profile-messages',
            'profile.friends' => 'profile-friends',
            'profile.groups' => 'profile-groups',
            'profile.forums' => 'profile-forums',
            'profile.settings' => 'profile-settings',
            'profile.points' => 'profile-points',
            'profile.ranks' => 'profile-ranks',
            'group.home' => 'group-home',
            'group.activity' => 'group-activity',
            'group.members' => 'group-members',
            'group.invite' => 'group-invite',
            'group.media' => 'group-media',
            'group.forum' => 'group-forum',
            'group.manage' => 'group-manage',
            'library.elements' => 'library-elements',
            'library.components' => 'library-components',
            'library.icons' => 'library-signature',
        ) );
    }

    public static function for_context( string $context ): string {
        $map = self::context_map();
        return self::resolve( $map[ $context ] ?? $context );
    }

    public static function frontend_payload(): array {
        $payload = array();
        foreach ( self::icons() as $key => $icon ) {
            $payload[ $key ] = array( 'label' => $icon['label'], 'category' => $icon['category'], 'path' => $icon['path'] );
        }
        return $payload;
    }

    public static function categories(): array {
        $categories = array();
        foreach ( self::icons() as $icon ) $categories[] = $icon['category'];
        return array_values( array_unique( $categories ) );
    }

    public static function diagnostics(): array {
        $icons = self::icons();
        $aliases = self::aliases();
        $contexts = self::context_map();
        $missing_alias_targets = array();
        $missing_context_targets = array();
        $invalid_icons = array();
        foreach ( $aliases as $alias => $target ) if ( ! isset( $icons[ $target ] ) ) $missing_alias_targets[ $alias ] = $target;
        foreach ( $contexts as $context => $target ) if ( ! isset( $icons[ $target ] ) && ! isset( $aliases[ $target ] ) ) $missing_context_targets[ $context ] = $target;
        foreach ( $icons as $key => $icon ) {
            if ( empty( $icon['label'] ) || empty( $icon['category'] ) || empty( $icon['path'] ) ) $invalid_icons[] = $key;
        }
        return array(
            'icons' => count( $icons ),
            'categories' => count( self::categories() ),
            'aliases' => count( $aliases ),
            'contexts' => count( $contexts ),
            'missing_alias_targets' => $missing_alias_targets,
            'missing_context_targets' => $missing_context_targets,
            'invalid_icons' => $invalid_icons,
            'status' => empty( $missing_alias_targets ) && empty( $missing_context_targets ) && empty( $invalid_icons ) ? 'healthy' : 'attention',
        );
    }

    public static function render( string $key, string $label = '', bool $decorative = true ): string {
        $icons = self::icons();
        $key = self::resolve( $key );
        $icon = $icons[ $key ];
        $aria = $decorative ? ' aria-hidden="true" focusable="false"' : ' role="img" aria-label="' . esc_attr( $label ?: $icon['label'] ) . '"';
        return '<svg class="zcbx-signature-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"' . $aria . '><path d="' . esc_attr( $icon['path'] ) . '"></path></svg>';
    }
}
