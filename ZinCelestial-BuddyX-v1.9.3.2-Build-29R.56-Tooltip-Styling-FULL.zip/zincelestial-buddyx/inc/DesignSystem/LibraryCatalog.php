<?php
namespace ZinCelestial\BuddyX\DesignSystem;
defined( 'ABSPATH' ) || exit;

final class LibraryCatalog {
    public static function elements(): array {
        return apply_filters( 'zcbx_element_library_catalog', array(
            'buttons' => array( 'label' => 'Buttons', 'category' => 'Actions', 'status' => 'available' ),
            'links' => array( 'label' => 'Links', 'category' => 'Actions', 'status' => 'available' ),
            'inputs' => array( 'label' => 'Inputs', 'category' => 'Forms', 'status' => 'available' ),
            'selects' => array( 'label' => 'Select menus', 'category' => 'Forms', 'status' => 'available' ),
            'toggles' => array( 'label' => 'Toggles', 'category' => 'Forms', 'status' => 'available' ),
            'avatars' => array( 'label' => 'Avatars', 'category' => 'Identity', 'status' => 'available' ),
            'badges' => array( 'label' => 'Badges', 'category' => 'Status', 'status' => 'available' ),
            'labels' => array( 'label' => 'Labels', 'category' => 'Typography', 'status' => 'available' ),
            'dividers' => array( 'label' => 'Dividers', 'category' => 'Structure', 'status' => 'available' ),
            'focus-rings' => array( 'label' => 'Focus rings', 'category' => 'Accessibility', 'status' => 'available' ),
        ) );
    }

    public static function components(): array {
        return apply_filters( 'zcbx_component_library_catalog', array(
            'member-card' => array( 'label' => 'Member Card', 'category' => 'Community', 'status' => 'active' ),
            'group-card' => array( 'label' => 'Group Card', 'category' => 'Community', 'status' => 'active' ),
            'activity-card' => array( 'label' => 'Activity Card', 'category' => 'Community', 'status' => 'active' ),
            'identity-card' => array( 'label' => 'Identity Card', 'category' => 'Profile', 'status' => 'active' ),
            'profile-navigation' => array( 'label' => 'Profile Navigation', 'category' => 'Navigation', 'status' => 'active' ),
            'widget-title' => array( 'label' => 'Widget Title', 'category' => 'Widgets', 'status' => 'active' ),
            'content-surface' => array( 'label' => 'Content Surface', 'category' => 'Structure', 'status' => 'active' ),
            'feedback-notice' => array( 'label' => 'Feedback Notice', 'category' => 'Feedback', 'status' => 'available' ),
        ) );
    }

    public static function summary(): array {
        return array(
            'elements' => count( self::elements() ),
            'components' => count( self::components() ),
            'icons' => count( SignatureIconRegistry::icons() ),
        );
    }
}
