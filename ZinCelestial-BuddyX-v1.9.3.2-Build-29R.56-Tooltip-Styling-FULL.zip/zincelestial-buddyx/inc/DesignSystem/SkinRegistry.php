<?php
namespace ZinCelestial\BuddyX\DesignSystem;
defined( 'ABSPATH' ) || exit;
final class SkinRegistry { public static function all():array { return array('default'=>'ZinCelestial Default','celestial-midnight'=>'Celestial Midnight','nebula-violet'=>'Nebula Violet','quantum-carbon'=>'Quantum Carbon','aurora-mist'=>'Aurora Mist','solar-pearl'=>'Solar Pearl'); } }
