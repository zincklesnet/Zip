<?php
namespace ZinCelestial\BuddyX\DesignSystem;
defined( 'ABSPATH' ) || exit;
final class TokenRegistry { public static function defaults():array { return array('page'=>'#070b18','surface'=>'#10172a','elevated'=>'#17213a','text'=>'#f5f7ff','muted'=>'#a9b4cc','cyan'=>'#00ddf5','violet'=>'#7047ff','magenta'=>'#ef2fff','success'=>'#00c994','warning'=>'#ffb000','danger'=>'#ff3158'); } }
