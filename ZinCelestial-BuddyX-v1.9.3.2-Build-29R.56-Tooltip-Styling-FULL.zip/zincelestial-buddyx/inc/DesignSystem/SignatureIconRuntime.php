<?php
namespace ZinCelestial\BuddyX\DesignSystem;
defined( 'ABSPATH' ) || exit;

final class SignatureIconRuntime {
    public static function register(): void {
        add_shortcode( 'zcbx_icon', array( self::class, 'shortcode' ) );
    }

    public static function shortcode( array $atts = array() ): string {
        $atts = shortcode_atts(
            array(
                'name'       => 'library-signature',
                'label'      => '',
                'decorative' => 'true',
                'size'       => '24',
                'class'      => '',
                'variant'    => 'plain',
                'color'      => '',
            ),
            $atts,
            'zcbx_icon'
        );
        $size = max( 12, min( 96, absint( $atts['size'] ) ) );
        $decorative = ! in_array( strtolower( (string) $atts['decorative'] ), array( 'false', '0', 'no' ), true );
        $class = sanitize_html_class( (string) $atts['class'] );
        $variant = in_array( (string) $atts['variant'], array( 'plain', 'badge', 'glow', 'button' ), true ) ? (string) $atts['variant'] : 'plain';
        $color = sanitize_hex_color( (string) $atts['color'] );
        $style = '--zcbx-icon-size:' . $size . 'px' . ( $color ? ';--zcbx-icon-color:' . $color : '' );
        return '<span class="zcbx-signature-icon-wrap zcbx-signature-icon-wrap--' . esc_attr( $variant ) . ' ' . esc_attr( $class ) . '" style="' . esc_attr( $style ) . '">' . SignatureIconRegistry::render( sanitize_key( (string) $atts['name'] ), sanitize_text_field( (string) $atts['label'] ), $decorative ) . '</span>';
    }
}
