<?php
namespace ZinCelestial\BuddyX\DesignSystem;
defined( 'ABSPATH' ) || exit;
final class CssPropertyMap { public static function all():array { return array('page'=>'--zcbx-page-bg','surface'=>'--zcbx-surface','elevated'=>'--zcbx-surface-elevated','text'=>'--zcbx-text','muted'=>'--zcbx-text-muted','cyan'=>'--zcbx-cyan','violet'=>'--zcbx-violet','magenta'=>'--zcbx-magenta'); } }
