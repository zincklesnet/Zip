<?php
namespace ZinCelestial\BuddyX\Admin;
defined( 'ABSPATH' ) || exit;
final class CommunityExperiencePage {
 public static function register():void {do_action('zcbx_community_experience_admin_scaffold_registered',self::sections());}
 public static function sections():array{return array('overview'=>'Overview','site-experience'=>'Site Experience','member-experience'=>'Member Experience','group-experience'=>'Group Experience','migration-ownership'=>'Migration & Ownership','diagnostics'=>'Diagnostics');}
}
