<?php
namespace ZinCelestial\BuddyX\Admin;
defined( 'ABSPATH' ) || exit;
final class Controller {public static function register():void{if(is_admin()&&is_callable('zcbx_register_admin'))zcbx_register_admin();do_action('zcbx_admin_service_registered');}}
