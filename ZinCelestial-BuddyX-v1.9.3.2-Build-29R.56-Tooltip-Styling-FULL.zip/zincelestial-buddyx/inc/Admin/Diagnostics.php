<?php
namespace ZinCelestial\BuddyX\Admin;
defined( 'ABSPATH' ) || exit;
final class Diagnostics {
 public static function snapshot():array {
  $last_good=get_option('zcbx_settings_last_good',array());
  return array(
   'theme_version'=>ZCBX_VERSION,'php'=>PHP_VERSION,'wordpress'=>get_bloginfo('version'),'schema_version'=>(int)get_option('zcbx_schema_version',0),
   'plugins'=>\ZinCelestial\BuddyX\Compatibility\PluginAdapters::statuses(),
   'integrations'=>\ZinCelestial\BuddyX\Compatibility\IntegrationRegistry::all(),
   'modules'=>\ZinCelestial\BuddyX\Core\ModuleRegistry::statuses(),
   'dashboard_widgets'=>\ZinCelestial\BuddyX\Core\DashboardWidgetRegistry::all(),
   'services'=>array('bootstrap'=>class_exists('\\ZinCelestial\\BuddyX\\Core\\Bootstrap'),'settings'=>class_exists('\\ZinCelestial\\BuddyX\\Settings\\Repository'),'runtime'=>class_exists('\\ZinCelestial\\BuddyX\\Platform\\Runtime'),'compatibility'=>class_exists('\\ZinCelestial\\BuddyX\\Compatibility\\PluginAdapters'),'admin'=>class_exists('\\ZinCelestial\\BuddyX\\Admin\\Controller'),'buddypress_services'=>class_exists('\\ZinCelestial\\BuddyX\\Community\\BuddyPressServices')&&\ZinCelestial\BuddyX\Community\BuddyPressServices::available(),'woocommerce_services'=>class_exists('\\ZinCelestial\\BuddyX\\Compatibility\\WooCommerceServices')&&\ZinCelestial\BuddyX\Compatibility\WooCommerceServices::available()),
   'buddypress'=>class_exists('\\ZinCelestial\\BuddyX\\Community\\BuddyPressServices')?\ZinCelestial\BuddyX\Community\BuddyPressServices::capabilities():array(),
   'community_experience'=>class_exists('\\ZinCelestial\\BuddyX\\Community\\ExperiencePlatform')?\ZinCelestial\BuddyX\Community\ExperiencePlatform::status():array(),
   'signature_icons'=>class_exists('\\ZinCelestial\\BuddyX\\DesignSystem\\SignatureIconRegistry')?\ZinCelestial\BuddyX\DesignSystem\SignatureIconRegistry::diagnostics():array(),
   'woocommerce'=>class_exists('\\ZinCelestial\\BuddyX\\Compatibility\\WooCommerceServices')?\ZinCelestial\BuddyX\Compatibility\WooCommerceServices::capabilities():array(),
   'save_engine'=>array('protected'=>true,'handler_registered'=>(bool)has_action('admin_post_zcbx_save_settings'),'last_good_available'=>is_array($last_good)&&!empty($last_good),'last_good_timestamp'=>(int)get_option('zcbx_settings_last_good_time',0))
  );
 }
}
