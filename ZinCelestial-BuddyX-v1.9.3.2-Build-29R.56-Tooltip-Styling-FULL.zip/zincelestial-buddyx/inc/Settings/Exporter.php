<?php
namespace ZinCelestial\BuddyX\Settings;
defined( 'ABSPATH' ) || exit;
final class Exporter {
 public static function payload():array {return array('schema'=>1,'theme_version'=>ZCBX_VERSION,'settings'=>Repository::all());}
 public static function json():string {return (string)wp_json_encode(self::payload(),JSON_PRETTY_PRINT);}
}
