<?php
namespace ZinCelestial\BuddyX\Settings;
defined( 'ABSPATH' ) || exit;
final class Repository {
 public const OPTION='zcbx_settings';
 public static function all():array {$v=get_option(self::OPTION,array());return is_array($v)?$v:array();}
 public static function get(string $key,$default=null){$s=self::all();return array_key_exists($key,$s)?$s[$key]:$default;}
 public static function update(array $settings):bool{return update_option(self::OPTION,$settings,false);}
}
