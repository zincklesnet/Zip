<?php
namespace ZinCelestial\BuddyX\Settings;
defined( 'ABSPATH' ) || exit;
final class Sanitizer {
 public static function map(array $input):array {$clean=array();foreach($input as $key=>$value)$clean[sanitize_key((string)$key)]=self::value($value);return $clean;}
 private static function value($value){if(is_array($value))return self::map($value);if(is_bool($value)||is_int($value)||is_float($value))return $value;return sanitize_text_field(wp_unslash((string)$value));}
}
