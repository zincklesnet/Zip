<?php
namespace ZinCelestial\BuddyX\Settings;
defined( 'ABSPATH' ) || exit;
final class MigrationRunner {
 private const VERSION_OPTION='zcbx_schema_version';
 public static function run():void {$current=(int)get_option(self::VERSION_OPTION,0);if($current<1)update_option(self::VERSION_OPTION,1,false);do_action('zcbx_settings_migrated',$current,1);}
}
