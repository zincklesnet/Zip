<?php
namespace ZinCelestial\BuddyX\Settings;
defined( 'ABSPATH' ) || exit;
final class Controller { public static function register():void { do_action('zcbx_settings_services_registered',Repository::class,Sanitizer::class); } }
