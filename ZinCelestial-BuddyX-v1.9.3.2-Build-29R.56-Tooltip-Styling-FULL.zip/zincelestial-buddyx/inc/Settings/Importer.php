<?php
namespace ZinCelestial\BuddyX\Settings;
defined( 'ABSPATH' ) || exit;
final class Importer {
 public static function decode(string $json):array {$data=json_decode($json,true);if(!is_array($data)||!isset($data['settings'])||!is_array($data['settings']))return array();return Sanitizer::map($data['settings']);}
}
