<?php
namespace ZinCelestial\BuddyX\Compatibility\WooCommerce\Marketplaces;

final class MultiVendorXAdapter extends AbstractMarketplaceAdapter {
    public static function slug(): string {
        return 'multivendorx';
    }
}
