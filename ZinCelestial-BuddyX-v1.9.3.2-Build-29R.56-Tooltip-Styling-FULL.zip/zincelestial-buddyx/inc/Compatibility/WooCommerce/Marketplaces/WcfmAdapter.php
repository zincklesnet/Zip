<?php
namespace ZinCelestial\BuddyX\Compatibility\WooCommerce\Marketplaces;

final class WcfmAdapter extends AbstractMarketplaceAdapter {
    public static function slug(): string {
        return 'wcfm';
    }
}
