<?php
namespace ZinCelestial\BuddyX\Compatibility\WooCommerce\Marketplaces;

use ZinCelestial\BuddyX\Compatibility\WooCommerce\StateResolver;

defined( 'ABSPATH' ) || exit;

final class MarketplaceAdapterRegistry {
    public static function adapters(): array {
        return array(
            DokanAdapter::class,
            WcfmAdapter::class,
            WcVendorsAdapter::class,
            MultiVendorXAdapter::class,
            YithMultiVendorAdapter::class,
        );
    }

    public static function results(): array {
        $results = array();
        foreach ( self::adapters() as $adapter ) {
            $results[ $adapter::slug() ] = $adapter::result();
        }
        return $results;
    }

    public static function register(): void {
        $states = StateResolver::resolve_all();
        do_action( 'zcbx_woocommerce_compatibility_registered', $states );
        do_action( 'zcbx_marketplace_adapters_registered', self::results() );
    }
}
