<?php
namespace ZinCelestial\BuddyX\Compatibility\WooCommerce\Marketplaces;

final class DokanAdapter extends AbstractMarketplaceAdapter {
    public static function slug(): string {
        return 'dokan';
    }
}
