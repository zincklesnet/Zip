<?php
namespace ZinCelestial\BuddyX\Compatibility\WooCommerce\Marketplaces;

use ZinCelestial\BuddyX\Compatibility\WooCommerce\CompatibilityMatrix;
use ZinCelestial\BuddyX\Compatibility\WooCommerce\StateResolver;

abstract class AbstractMarketplaceAdapter implements MarketplaceAdapterInterface {
    public static function result(): array {
        $definitions = CompatibilityMatrix::definitions();
        $slug = static::slug();
        return isset( $definitions[ $slug ] )
            ? StateResolver::resolve( $slug, $definitions[ $slug ] )
            : array( 'slug' => $slug, 'active' => false, 'mode' => 'read-only' );
    }
}
