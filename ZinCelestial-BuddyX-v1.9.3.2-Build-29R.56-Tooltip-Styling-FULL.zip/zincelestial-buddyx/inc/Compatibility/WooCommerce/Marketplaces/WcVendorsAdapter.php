<?php
namespace ZinCelestial\BuddyX\Compatibility\WooCommerce\Marketplaces;

final class WcVendorsAdapter extends AbstractMarketplaceAdapter {
    public static function slug(): string {
        return 'wc_vendors';
    }
}
