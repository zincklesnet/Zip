<?php
namespace ZinCelestial\BuddyX\Compatibility\WooCommerce\Marketplaces;

final class YithMultiVendorAdapter extends AbstractMarketplaceAdapter {
    public static function slug(): string {
        return 'yith';
    }
}
