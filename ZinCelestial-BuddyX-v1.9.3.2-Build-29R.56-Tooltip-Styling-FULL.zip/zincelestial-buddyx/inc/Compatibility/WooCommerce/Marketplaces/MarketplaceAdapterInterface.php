<?php
namespace ZinCelestial\BuddyX\Compatibility\WooCommerce\Marketplaces;

interface MarketplaceAdapterInterface {
    public static function slug(): string;
    public static function result(): array;
}
