<?php
namespace ZinCelestial\BuddyX\Compatibility\WooCommerce;

defined( 'ABSPATH' ) || exit;

final class StateResolver {
    public static function resolve( string $slug, array $definition ): array {
        $active = false;
        if ( ! empty( $definition['class'] ) && class_exists( $definition['class'] ) ) {
            $active = true;
        }
        if ( ! $active && ! empty( $definition['function'] ) && function_exists( $definition['function'] ) ) {
            $active = true;
        }
        if ( ! $active && ! empty( $definition['constant'] ) && defined( $definition['constant'] ) ) {
            $active = true;
        }
        return array(
            'slug' => $slug,
            'label' => isset( $definition['label'] ) ? (string) $definition['label'] : $slug,
            'active' => $active,
            'version' => self::version( $definition ),
            'mode' => 'read-only',
        );
    }

    public static function resolve_all(): array {
        $results = array();
        foreach ( CompatibilityMatrix::definitions() as $slug => $definition ) {
            $results[ $slug ] = self::resolve( $slug, $definition );
        }
        $marketplaces = array_filter(
            $results,
            static function ( array $result ): bool {
                return 'woocommerce' !== $result['slug'] && ! empty( $result['active'] );
            }
        );
        $results['_conflict'] = array(
            'active_marketplaces' => array_keys( $marketplaces ),
            'multiple_active' => count( $marketplaces ) > 1,
            'action' => 'report-only',
        );
        return $results;
    }

    private static function version( array $definition ): string {
        if ( ! empty( $definition['constant'] ) && defined( $definition['constant'] ) ) {
            return (string) constant( $definition['constant'] );
        }
        return '';
    }
}
