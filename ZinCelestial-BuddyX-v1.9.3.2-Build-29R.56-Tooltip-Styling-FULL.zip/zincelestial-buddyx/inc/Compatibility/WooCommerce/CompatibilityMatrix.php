<?php
namespace ZinCelestial\BuddyX\Compatibility\WooCommerce;

defined( 'ABSPATH' ) || exit;

final class CompatibilityMatrix {
    public static function definitions(): array {
        return array(
            'woocommerce' => array( 'label' => 'WooCommerce', 'class' => 'WooCommerce', 'constant' => 'WC_VERSION' ),
            'dokan' => array( 'label' => 'Dokan', 'class' => 'WeDevs_Dokan', 'function' => 'dokan' ),
            'wcfm' => array( 'label' => 'WCFM Marketplace', 'class' => 'WCFMmp', 'constant' => 'WCFMMP_VERSION' ),
            'wc_vendors' => array( 'label' => 'WC Vendors', 'class' => 'WC_Vendors', 'constant' => 'WCV_VERSION' ),
            'multivendorx' => array( 'label' => 'MultiVendorX', 'class' => 'MVX', 'constant' => 'MVX_PLUGIN_VERSION' ),
            'yith' => array( 'label' => 'YITH WooCommerce Multi Vendor', 'class' => 'YITH_Vendors', 'constant' => 'YITH_WPV_VERSION' ),
        );
    }
}
