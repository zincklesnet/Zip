<?php
namespace ZinCelestial\BuddyX\Compatibility;
defined( 'ABSPATH' ) || exit;
final class PluginAdapters {
 public static function register():void{do_action('zcbx_compatibility_adapters_registered',self::statuses());}
 public static function statuses():array{return array('buddypress'=>function_exists('buddypress'),'bbpress'=>class_exists('bbPress'),'woocommerce'=>class_exists('WooCommerce'),'mycred'=>function_exists('mycred')||class_exists('myCRED_Core'),'gamipress'=>defined('GAMIPRESS_VER'),'aam'=>defined('AAM_VERSION')||class_exists('AAM_Core'),'learndash'=>class_exists('SFWD_LMS'),'tutorlms'=>function_exists('tutor')||class_exists('TUTOR\\Tutor'),'memberpress'=>class_exists('MeprAppCtrl'));}
}
