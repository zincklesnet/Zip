<?php
namespace ZinCelestial\BuddyX\Compatibility;
defined( 'ABSPATH' ) || exit;

final class IntegrationRegistry {
    private static array $integrations = array();

    public static function register_defaults(): void {
        foreach ( PluginAdapters::statuses() as $slug => $active ) {
            self::register(
                $slug,
                array(
                    'active' => (bool) $active,
                    'health' => $active ? 'ready' : 'not-detected',
                )
            );
        }
        do_action( 'zcbx_integrations_registered', self::all() );
    }

    public static function register( string $slug, array $details ): bool {
        $slug = sanitize_key( $slug );
        if ( '' === $slug ) {
            return false;
        }
        self::$integrations[ $slug ] = array(
            'active' => ! empty( $details['active'] ),
            'health' => isset( $details['health'] ) ? sanitize_key( (string) $details['health'] ) : 'unknown',
        );
        return true;
    }

    public static function all(): array {
        return self::$integrations;
    }

    public static function get( string $slug ): array {
        $slug = sanitize_key( $slug );
        return self::$integrations[ $slug ] ?? array(
            'active' => false,
            'health' => 'not-registered',
        );
    }

    public static function active( string $slug ): bool {
        $integration = self::get( $slug );
        return ! empty( $integration['active'] );
    }
}
