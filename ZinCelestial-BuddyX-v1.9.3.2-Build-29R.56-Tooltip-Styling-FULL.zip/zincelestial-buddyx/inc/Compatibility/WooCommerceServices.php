<?php
namespace ZinCelestial\BuddyX\Compatibility;
defined( 'ABSPATH' ) || exit;

final class WooCommerceServices {
    public static function register(): void {
        if ( ! self::available() ) {
            do_action( 'zcbx_woocommerce_services_unavailable' );
            return;
        }

        do_action( 'zcbx_woocommerce_services_registered', self::capabilities() );
    }

    public static function available(): bool {
        return class_exists( 'WooCommerce' );
    }

    public static function capabilities(): array {
        return array(
            'products'  => function_exists( 'wc_get_product' ),
            'orders'    => function_exists( 'wc_get_orders' ),
            'customers' => function_exists( 'wc_get_customer_order_count' ),
            'coupons'   => function_exists( 'wc_get_coupon_id_by_code' ),
            'accounts'  => function_exists( 'wc_get_account_menu_items' ),
        );
    }
}
