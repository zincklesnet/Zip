<?php
/**
 * Conditional front-end asset service. Retained for compatibility; active bootstrap ownership remains inc/assets.php.
 *
 * @package ZinCelestial_BuddyX
 */
namespace ZinCelestial\BuddyX\Services;

defined( 'ABSPATH' ) || exit;

final class AssetManager {
    public static function register(): void {
        add_action( 'wp_enqueue_scripts', array( self::class, 'enqueue' ), 30 );
    }

    public static function enqueue(): void {
        $parent   = wp_get_theme( get_template() );
        $settings = function_exists( 'zcbx_settings' ) ? zcbx_settings() : array();

        wp_enqueue_style( 'buddyx-parent', get_template_directory_uri() . '/style.css', array(), $parent->get( 'Version' ) );
        wp_enqueue_style( 'zcbx-header', ZCBX_URL . 'assets/header.css', array( 'buddyx-parent' ), ZCBX_VERSION );

        if ( ! empty( $settings['light_foundation'] ) ) {
            wp_enqueue_style( 'zcbx-light', ZCBX_URL . 'assets/light.css', array( 'zcbx-header' ), ZCBX_VERSION );
        }

        $is_buddypress = function_exists( 'is_buddypress' ) && is_buddypress();
        $custom_header = ! empty( $settings['profile_header_enabled'] )
            && 'native' !== ( $settings['profile_header_layout'] ?? 'native' );

        if ( $is_buddypress && $custom_header ) {
            wp_enqueue_style( 'zcbx-profile-header', ZCBX_URL . 'assets/profile-header.css', array( 'zcbx-header' ), ZCBX_VERSION );
            wp_enqueue_style( 'zcbx-profile-experience', ZCBX_URL . 'assets/profile-experience.css', array( 'zcbx-profile-header' ), ZCBX_VERSION );
            wp_enqueue_script( 'zcbx-profile-experience', ZCBX_URL . 'assets/profile-experience.js', array(), ZCBX_VERSION, true );
            wp_localize_script( 'zcbx-profile-experience', 'ZCBX_PLATFORM', $settings );
        }
    }
}
