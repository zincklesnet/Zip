# Build 16 Staging Validation Checklist

- [ ] Test support and help pages.
- [ ] Test legal, privacy and policy pages.
- [ ] Test recipe indexes and individual recipes.
- [ ] Test alias and business profiles.
- [ ] Test galleries, media collections, polls and results.
- [ ] Test Community Experience pages and shared states.
- [ ] Verify keyboard access, responsive behavior, reduced motion and light/dark parity.
- [ ] Approve stable promotion.
