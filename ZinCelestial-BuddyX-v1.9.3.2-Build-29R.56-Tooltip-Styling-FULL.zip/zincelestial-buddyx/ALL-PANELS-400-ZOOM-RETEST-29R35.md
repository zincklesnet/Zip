# All Panels 400% Zoom Retest — Build 29R.35

All generated settings helpers now emit the explicit `zcbx-field-row` class. Source checks passed for global matching, tablet/mobile stacking, 320 CSS pixel containment, range output stacking, media action stacking, and long-label wrapping.

This is a source-level 320 CSS pixel retest. A browser-rendered authenticated WordPress 400% run remains pending and is not represented as completed.
