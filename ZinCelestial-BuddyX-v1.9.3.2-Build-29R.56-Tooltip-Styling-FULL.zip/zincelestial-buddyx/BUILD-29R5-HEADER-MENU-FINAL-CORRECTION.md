# Build 29R.5 Header Menu Final Correction

- Removed duplicate desktop dropdown arrows.
- Replaced multiple inherited indicators with one controlled chevron per parent menu item.
- Removed link underline and underline-color treatments from header navigation states.
- Hid mobile hamburger controls at desktop widths.
- Preserved hamburger controls at widths of 782 pixels and below.
- No Customizer, schema, Community Layout, or component-library changes.
