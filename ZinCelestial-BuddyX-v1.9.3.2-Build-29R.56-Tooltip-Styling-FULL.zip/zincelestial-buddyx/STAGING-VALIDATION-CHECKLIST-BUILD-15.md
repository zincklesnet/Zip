# Build 15 Staging Validation Checklist

- [ ] Test product archives, product pages, galleries, variations, stock and ratings.
- [ ] Test cart, coupons, taxes, shipping, checkout and each enabled payment method.
- [ ] Test account, orders, refunds, downloads and addresses.
- [ ] Test notices, validation and failure states.
- [ ] Test vendor shops, policies, ratings, support and WCFM-compatible surfaces.
- [ ] Test currency and points presentation without changing transaction ownership.
- [ ] Test responsive, keyboard, accessibility and light/dark parity.
- [ ] Approve stable promotion.
