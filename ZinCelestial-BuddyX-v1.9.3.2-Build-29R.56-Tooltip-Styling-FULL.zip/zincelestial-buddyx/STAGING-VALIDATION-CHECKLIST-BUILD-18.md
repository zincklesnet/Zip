# Build 18 Staging Validation Checklist

## Baseline

- [x] Complete Build 17 staging-candidate workspace used as baseline.
- [x] Build 17 manifest and protected checksums preserved before Build 18 work.
- [x] VS-2 through VS-9 records retained.
- [x] Settings schema version 1 retained.
- [x] Customizer authority and platform asset separation retained.

## VS-10 governance

- [x] Mandatory design-token policy created.
- [x] Component-family token mapping created.
- [x] Integration alias rules created.
- [x] Token exception register created.
- [x] Visual QA lock criteria created.
- [x] Component inventory designated as the status source of truth.

## Required certification

- [x] Automated hard-coded-value audit generated.
- [ ] Audit findings reviewed and reconciled.
- [ ] All approved exceptions documented.
- [ ] Light and dark visual evidence completed.
- [ ] Desktop, tablet, and mobile evidence completed.
- [ ] Accessibility and reduced-motion certification completed.
- [ ] Integration regression testing completed.
- [ ] PHP syntax validation completed in a PHP CLI environment.
- [x] Explicit packaging approval received.

Current packaging decision: **APPROVED_FOR_PACKAGING**. Promotion decision: **HOLD**.
