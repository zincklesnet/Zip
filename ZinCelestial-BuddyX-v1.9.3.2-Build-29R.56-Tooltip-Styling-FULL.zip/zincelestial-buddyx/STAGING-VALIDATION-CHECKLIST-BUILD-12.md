# Build 12 Staging Validation Checklist

- [x] Complete Build 11 baseline extracted.
- [x] Protected checksums preserved.
- [x] VS-4 component and shell files loaded through the existing Visual Foundation entry point.
- [ ] Verify WordPress native menu markup and current-menu states.
- [ ] Verify keyboard traversal and focus order for nested menus.
- [ ] Verify account, utility and dropdown menus.
- [ ] Verify desktop, tablet and mobile shell behavior.
- [ ] Verify left and right menu overflow, collapsed and pinned states.
- [ ] Verify tabs, breadcrumbs, pagination and search.
- [ ] Verify light/dark parity and reduced-motion behavior.
- [ ] Approve promotion to stable baseline.
