# Build 29R.34 Administration Control Structure and Reflow

## Corrected
- Separated setting labels, default-value notes, and controls into consistent two-column rows on wide screens.
- Stacked each field into one column on tablet, mobile, and 400% zoom widths.
- Added consistent spacing around checkboxes, selects, sliders, outputs, media controls, and preview columns.
- Added explicit accessible labels and polite output updates to generated range controls.
- Kept layout cards contained and responsive.

## Preserved
- Existing setting names, values, defaults, sanitizers, save engine, and schema version 1.
- Unified Libraries, Signature Icon runtime, group/profile navigation icons, and accessibility records.
- News Feed activity parity and native BuddyX sidebar ownership.
