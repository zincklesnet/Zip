# Build 7 Staging Validation

- [ ] Theme installs with a single `zincelestial-buddyx/` root.
- [ ] Theme activates without fatal errors or recovery mode.
- [ ] Community Experience and Customizer systems remain available.
- [ ] Existing `zcbx_settings` values persist.
- [ ] WooCommerce core state is reported without writes.
- [ ] Dokan, WCFM Marketplace, WC Vendors, MultiVendorX, and YITH adapters report state.
- [ ] Multiple active marketplace engines produce a report-only conflict.
- [ ] Shop, product, cart, checkout, account, and order-history screens load.
- [ ] No products, orders, vendors, commissions, payouts, refunds, or plugin settings are modified.
