# Build 29R.35 Global Field Rows and 400% Zoom

## Implemented
- Applied `zcbx-field-row` directly to every generated select, checkbox, range, color, and media settings row.
- Removed reliance on parent-section and direct-child selector matching.
- Corrected top-level Member Directory, Command Surfaces, Signature Member Cards, Achievements, Header and Cover, Background, Cover Image, Widget, Sub Header, Surface, and related generated control rows.
- Added a single global responsive field contract for desktop, tablet, mobile, and 320 CSS pixel widths.

## 400% zoom source retest
- Verified every generated helper emits the global field-row class.
- Verified all settings panels use generated helpers or responsive layout-card structures.
- Verified 320 CSS pixel stacking, control containment, range wrapping, media-button stacking, and long-label wrapping.
- Browser-rendered 400% testing still requires an authenticated WordPress browser session and is not claimed as executed in the build container.

## Preserved
- Existing setting IDs, values, defaults, sanitizers, save engine, and schema version 1.
- Unified Libraries, profile/group navigation icons, News Feed activity parity, and native BuddyX sidebars.
