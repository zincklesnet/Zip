# Build 29R.4 Header Menu Dropdown Correction

## Visual defect
Desktop parent-menu dropdown controls extended below the header as oversized V-shaped marks.

## Correction
- Constrained top-level dropdown-toggle controls to a 20 by 20 pixel inline box.
- Aligned parent menu links and dropdown controls vertically within the 44 pixel header row.
- Constrained SVG, icon-font, and pseudo-element output inside the toggle.
- Kept submenu behavior and mobile menu layout intact.

## Scope
Header navigation CSS only. No Customizer, settings, schema, component-library, or Community Layout changes.
