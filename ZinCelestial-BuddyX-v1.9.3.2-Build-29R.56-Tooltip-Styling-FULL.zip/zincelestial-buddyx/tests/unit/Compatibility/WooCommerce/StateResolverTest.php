<?php
use PHPUnit\Framework\TestCase;
use ZinCelestial\BuddyX\Compatibility\WooCommerce\CompatibilityMatrix;
use ZinCelestial\BuddyX\Compatibility\WooCommerce\StateResolver;

final class StateResolverTest extends TestCase {
    public function test_matrix_contains_supported_marketplaces(): void {
        $matrix = CompatibilityMatrix::definitions();
        $this->assertArrayHasKey( 'dokan', $matrix );
        $this->assertArrayHasKey( 'wcfm', $matrix );
        $this->assertArrayHasKey( 'wc_vendors', $matrix );
        $this->assertArrayHasKey( 'multivendorx', $matrix );
        $this->assertArrayHasKey( 'yith', $matrix );
    }

    public function test_unknown_runtime_defaults_inactive(): void {
        $result = StateResolver::resolve( 'unknown', array( 'label' => 'Unknown' ) );
        $this->assertFalse( $result['active'] );
        $this->assertSame( 'read-only', $result['mode'] );
    }
}
