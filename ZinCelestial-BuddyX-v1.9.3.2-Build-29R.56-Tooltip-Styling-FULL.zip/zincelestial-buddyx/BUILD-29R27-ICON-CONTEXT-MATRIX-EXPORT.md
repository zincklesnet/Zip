# Build 29R.27 Icon Context Matrix and Export

## Implemented
- Added a read-only Context Assignment Matrix inside the shared Signature Icon Library.
- Displays each registered interface context, resolved icon key, icon preview, and copy-key control.
- Added an administrator-only, nonce-protected JSON export containing registry schema, icons, aliases, and context mappings.
- Export does not modify settings, registry data, or frontend behavior.

## Preserved
- Element Library, Component Library, and Signature Icon Library remain together in ZinCelestial Administration.
- Profile menu signature icon integration and custom image priority remain unchanged.
- News Feed activity parity, native BuddyX sidebars, saved settings, and schema version 1 remain unchanged.
