# Build 19 Staging Validation Checklist

## Static package gates

- [x] Complete Build 18 package used as source.
- [x] Build 18 package structure retained.
- [x] Protected checksums retained.
- [x] Settings schema version 1 retained.
- [x] Customizer authority retained.
- [x] Main theme remains free of platform.css and platform.js references.
- [x] Manifest regenerated from package contents.
- [x] ZIP structure and CRC test passed.

## Live staging gates

- [ ] Install and activate without errors.
- [ ] PHP syntax validation passes.
- [ ] Light and dark visual evidence passes.
- [ ] Desktop, tablet, and mobile checks pass.
- [ ] Keyboard, contrast, accessibility, and reduced-motion checks pass.
- [ ] WordPress and community integration regression checks pass.
- [ ] WooCommerce and marketplace regression checks pass.
- [ ] Extended page-system regression checks pass.
- [ ] User approves stable-baseline promotion.

Current decision: packaging ready; promotion remains on hold.
