# Build 29R.18 Sidebar-System Removal

## Baseline
- ZinCelestial-BuddyX v1.8.9.4 Build 29R.17 Community Layout Stability
- Settings schema remains version 1

## Removed
- ZinCelestial Community Layout shell runtime.
- Member and group left/right header, content, and footer widget regions.
- Shell renderer, sidebar registry, visibility/layout settings runtime, and related adapters.
- Community shell stylesheet and sticky/internal-scroll behavior.
- Build 29R.17 correction layer and loader.
- Build 29R.16 JavaScript title/sidebar relocation behavior.
- Current BuddyX Site Sidebar Customizer section and context controls.

## Temporary Runtime Boundary
- Retired BuddyX sidebar layout values resolve to `none`.
- ZinCelestial no longer injects member/group sidebar columns or moves directory headings relative to sidebars.

## Preserved
- Member Command above Community signal.
- Grid and Compact member-directory modes.
- Member/group cards, rewards, profiles, light/dark modes, administration settings, saved zcbx_settings, and schema version 1.

## Deferred
A replacement unified full-width/boxed system with no, left, right, or both sidebars will be designed later.
