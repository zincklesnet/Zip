# Build 29R Visual Foundation Externalization

## Baseline
- Protected baseline: ZinCelestial-BuddyX-v1.8.7.6-Build-28-Stage-2-Certification-FULL.
- Build 28 remains unchanged and protected.

## Changed
- Removed the uploaded-board visual-foundation component layer from the active theme package.
- Removed global loading of `zcbx-visual-foundation`.
- Removed the theme-owned board-derived ComponentRegistry.
- Removed the light and dark component-board images from the installable theme.
- Rebased `zcbx-zincelestial-foundation` on the retained header navigation stylesheet.

## Externalized
- Component, integration, foundation, utility, and reference-board assets are preserved in ZinCelestial Skin Component Library v1.0.0.
- The library is opt-in for future skins and templates and is not globally loaded by the theme.

## Preserved
- Settings schema version 1.
- Customizer and administration settings systems.
- Header, navigation, profile, Community Layout, BuddyPress, bbPress, and WooCommerce ownership outside the removed visual-foundation layer.
- Existing roadmap history.

## Dependency reconciliation
- Added a small theme-owned core token file for retained header, shell, profile, and base-theme styles.
- The core token file is not the externalized component system and contains no component selectors or integration mappings.
