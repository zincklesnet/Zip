# Build 17 Staging Validation Checklist

## Static baseline

- [x] Build 16 reconstructed from the authoritative 179-file manifest.
- [x] All Build 16 file sizes and SHA-256 checksums verified.
- [x] Protected systems preserved.
- [x] Settings schema version 1 preserved.
- [x] Platform asset separation preserved.
- [ ] PHP syntax validation pending in an environment with PHP CLI.
- [x] JSON validation passed.

## Visual evidence

- [ ] VS-2 light and dark evidence at desktop, tablet, and mobile.
- [ ] VS-3 light and dark evidence at desktop, tablet, and mobile.
- [ ] VS-4 light and dark evidence at desktop, tablet, and mobile.
- [ ] VS-5 light and dark evidence at desktop, tablet, and mobile.
- [ ] VS-6 light and dark evidence at desktop, tablet, and mobile.
- [ ] VS-7 light and dark evidence at desktop, tablet, and mobile.
- [ ] VS-8 light and dark evidence at desktop, tablet, and mobile.

## Accessibility and behavior

- [ ] Keyboard navigation and visible focus certified.
- [ ] Contrast certified in light and dark modes.
- [ ] Responsive overflow and touch-target behavior certified.
- [ ] Reduced-motion behavior certified.
- [ ] WordPress and community integration regression checks passed.
- [ ] Commerce and marketplace regression checks passed.
- [ ] Extended page-system regression checks passed.

## Release governance

- [x] Certification matrix created.
- [x] Visual QA criteria created.
- [x] Release promotion rules created.
- [ ] Every required family marked certified.
- [x] Explicit packaging approval received.
- [ ] Complete installable ZIP created and validated.

Current packaging decision: **APPROVED_FOR_PACKAGING**. Promotion decision: **HOLD**.
