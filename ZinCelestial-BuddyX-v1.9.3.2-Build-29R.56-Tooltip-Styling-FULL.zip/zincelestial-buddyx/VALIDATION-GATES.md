# Build 17 Validation Gates

1. Baseline integrity: every Build 16 tracked file matches its approved size and SHA-256 checksum.
2. Protected systems: protected checksums must pass.
3. Syntax: PHP, JavaScript, and JSON validation must pass.
4. Structure: installable child-theme root and manifest tree must pass.
5. Separation: main theme must not contain or enqueue platform.css or platform.js.
6. Visual modes: light and dark certification must pass for VS-2 through VS-8.
7. Responsive evidence: desktop, tablet, and mobile certification must pass.
8. Accessibility: keyboard focus and contrast certification must pass.
9. Motion: reduced-motion certification must pass.
10. Regression: WordPress, BuddyPress, bbPress, WooCommerce, marketplace, and extended page systems must pass.
11. Governance: roadmap, changelog, manifest, inventory, evidence, and release decision must agree.
12. Approval: explicit approval is required before packaging.

Any failed, blocked, not-run, or undocumented gate keeps the release on HOLD.
