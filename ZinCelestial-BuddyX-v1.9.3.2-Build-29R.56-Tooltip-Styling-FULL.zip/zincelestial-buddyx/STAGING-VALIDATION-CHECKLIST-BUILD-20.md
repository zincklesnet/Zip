# Build 20 Staging Validation Checklist

## Static package gates
- [x] Complete Build 19 package used as source.
- [x] Protected checksums retained.
- [x] Settings schema version 1 retained.
- [x] Customizer authority retained.
- [x] Platform asset separation retained.
- [x] Manifest regenerated.
- [x] ZIP CRC and single-root checks passed.

## Staging execution gates
- [ ] Install and activate without errors.
- [ ] PHP syntax checks pass.
- [ ] Light-mode evidence completed.
- [ ] Dark-mode evidence completed.
- [ ] Desktop, tablet, and mobile evidence completed.
- [ ] Accessibility and reduced-motion checks pass.
- [ ] WordPress and community regressions pass.
- [ ] Commerce and marketplace regressions pass.
- [ ] Extended-page regressions pass.
- [ ] Explicit stable-promotion approval recorded.

Decision: package ready for staging execution; stable promotion remains on hold.
