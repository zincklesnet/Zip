# Build 29R.38 Server-Rendered Panel Shell

## Architecture recovery
- Added an authoritative panel registry with labels and read-only status.
- The full legacy panel renderer now runs only into a private server buffer.
- Exactly one validated top-level panel is extracted and sent to the browser.
- Dashboard, Libraries, Diagnostics, and Tools render outside a settings form and show no Save controls.
- Editable panels receive one form containing only the active panel markup.
- Navigation uses normal server links and does not depend on JavaScript.
- JavaScript is limited to optional arrow-key focus movement and controls inside the active panel.

## Protected
- Existing `zcbx_settings`, setting IDs, defaults, sanitizers, save engine, fallbacks, and schema version 1.
- Global field-row presentation, unified Libraries, Signature Icons, group/profile icons, activity parity, native BuddyX sidebars, and Customizer authority.
