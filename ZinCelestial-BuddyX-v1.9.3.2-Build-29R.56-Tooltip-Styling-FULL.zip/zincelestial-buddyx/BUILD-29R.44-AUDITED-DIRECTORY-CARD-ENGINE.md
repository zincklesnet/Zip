# Build 29R.44 Audited Directory Card Engine

- Version: 1.9.2.1
- Baseline: ZinCelestial-BuddyX-v1.9.2.0-Build-29R.43-Directory-Card-Final-Restoration-FULL.zip
- Implements the findings in MEMBER-GROUP-DIRECTORY-CARD-AUDIT-29R43.md.
- Settings schema: version 1.
- Package: ZinCelestial-BuddyX-v1.9.2.1-Build-29R.44-Audited-Directory-Card-Engine-FULL.zip
