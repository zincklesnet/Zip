# Build 13 Staging Validation Checklist

- [ ] Activate with BuddyX parent and verify no PHP or console errors.
- [ ] Verify every card variant across light and dark modes.
- [ ] Verify activity, metadata, inbox, selected, unread and empty list states.
- [ ] Verify table sorting, filtering, row actions, status, loading, empty, error and responsive overflow.
- [ ] Verify stat cards, linear and circular progress, charts and legends.
- [ ] Verify calendars, date pickers, avatar groups and steppers.
- [ ] Verify keyboard focus, readable hierarchy, reduced motion and mobile density.
- [ ] Approve promotion to stable baseline.
