# Build 29R.45 Member Identity and GamiPress Order

- Version: 1.9.2.2
- Baseline: ZinCelestial-BuddyX-v1.9.2.1-Build-29R.44-Audited-Directory-Card-Engine-FULL.zip
- Scope: member identity and username ordering above GamiPress output only.
- Settings schema: version 1.
- Package: ZinCelestial-BuddyX-v1.9.2.2-Build-29R.45-Member-Identity-GamiPress-Order-FULL.zip
