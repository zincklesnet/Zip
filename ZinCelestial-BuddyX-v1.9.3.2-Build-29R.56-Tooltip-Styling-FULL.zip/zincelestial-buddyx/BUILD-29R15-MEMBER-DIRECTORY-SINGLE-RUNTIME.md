# Build 29R.15 Member Directory Single Runtime

- Keeps only server-rendered Command Deck and status ribbon.
- Removes JavaScript insertion of duplicate controls.
- Applies Grid and Compact to complete member-list items.
- Makes Compact a stable horizontal desktop card and stacked mobile card.
- Versions remembered browser view to prevent stale selections.
- Preserves schema version 1 and existing administration controls.
