# Build 29R.13 Member Directory Settings Runtime Correction

## Root cause
- The frontend enhancement script used a directory form selector that did not match the live BuddyPress markup shown in staging screenshots.
- Card enhancement classes were therefore never applied, so saved visual settings had no visible target.
- New unchecked settings inherited stored values during sanitization and could not reliably turn off.

## Corrected
- Detects the live members list first and resolves the nearest directory wrapper.
- Supports Nouveau and fallback member-directory list markup.
- Inserts Command Deck and status ribbon before available directory controls.
- Applies visibly distinct Grid and Compact structures.
- Applies Signature card, avatar-ring, achievement, motion, accent, glass, and tablet settings to live markup.
- Corrects checkbox-off persistence for the new Member Directory Experience settings.
