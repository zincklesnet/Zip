# Build 29R.20 Members and Groups Layout Cleanup

## Baseline
- Build 29R.19 BuddyX Site Sidebar Rollback behavior retained.
- Native BuddyX sidebar controls remain authoritative.
- Settings schema remains version 1.

## Members CSS Consolidation Plan Implemented
1. Retired six overlapping structural stylesheets.
2. Replaced them with one `members-groups-layout.css` authority.
3. Removed heading width calculations and negative sidebar margins.
4. Kept directory headings inside the native BuddyX content container.
5. Made Grid columns respond to available content width.
6. Made Compact cards stack safely on narrow layouts.
7. Replaced fixed card and avatar-panel heights with content-driven sizing.
8. Consolidated avatar, rewards, identity, and action containment.
9. Preserved Member Command, Community signal, Grid/Compact behavior, card accents, and dark mode.

## Groups Responsive Containment
- Kept BuddyX/BuddyPress group presentation native.
- Added min-width and max-width containment to directory wrappers, items, cards, media, descriptions, and actions.
- Enabled long text and action buttons to wrap instead of expanding the directory column.
- No Groups redesign or new settings introduced.

## Preserved Boundaries
- Native BuddyX Site Sidebar Customizer and sticky-sidebar behavior.
- ZinCelestial Community Layout shell remains removed.
- Retired ZinCelestial member/group widget regions remain unregistered.
- Existing administration settings and saved `zcbx_settings` data remain intact.
