document.addEventListener('DOMContentLoaded', function () {
  const form = document.querySelector('.z form[action*="admin-post.php"]');
  if (!form) return;

  let dirty = false;
  const markDirty = () => { dirty = true; form.classList.add('zcbx-has-unsaved-changes'); };
  form.querySelectorAll('input, select, textarea').forEach(el => {
    el.addEventListener('input', markDirty);
    el.addEventListener('change', markDirty);
  });

  form.addEventListener('submit', function () {
    dirty = false;
    sessionStorage.setItem('zcbx-save-started', String(Date.now()));
    form.querySelectorAll('button[type="submit"], input[type="submit"]').forEach(btn => {
      btn.disabled = true;
      if ('textContent' in btn) btn.textContent = 'Saving and verifying...';
    });
  });

  window.addEventListener('beforeunload', function (event) {
    if (!dirty) return;
    event.preventDefault();
    event.returnValue = '';
  });
});
