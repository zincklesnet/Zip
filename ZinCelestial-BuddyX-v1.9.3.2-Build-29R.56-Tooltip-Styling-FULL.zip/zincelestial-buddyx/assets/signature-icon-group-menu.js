(function(){
'use strict';
function make(key){var all=window.ZCBX_SIGNATURE_ICONS||{},icon=all[key]||all['library-signature'];if(!icon)return null;var ns='http://www.w3.org/2000/svg',svg=document.createElementNS(ns,'svg'),path=document.createElementNS(ns,'path');svg.setAttribute('class','zcbx-signature-icon zcbx-group-signature-icon');svg.setAttribute('viewBox','0 0 24 24');svg.setAttribute('fill','none');svg.setAttribute('stroke','currentColor');svg.setAttribute('stroke-width','1.8');svg.setAttribute('stroke-linecap','round');svg.setAttribute('stroke-linejoin','round');svg.setAttribute('aria-hidden','true');svg.setAttribute('focusable','false');path.setAttribute('d',icon.path);svg.appendChild(path);return svg;}
function slug(li){return (li.dataset.bpScope||li.dataset.bpObject||li.id||'').replace(/^.*?-group-li$/,'').replace(/-group-li$/,'').replace(/^nav-/,'').replace(/[^a-z0-9-]/gi,'').toLowerCase();}
function enhance(){var map=window.ZCBX_GROUP_ICON_MAP||{};document.querySelectorAll('#group-primary-nav>li,#groups-nav>li,.groups-nav>ul>li,[data-bp-navs] .groups-nav li').forEach(function(li){var a=li.querySelector(':scope>a');if(!a||a.querySelector('.zcbx-group-signature-icon')||a.querySelector('.zcbx-menu-custom-icon'))return;var key=map[slug(li)];if(!key)return;var icon=make(key);if(icon)a.insertBefore(icon,a.firstChild);});}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',enhance,{once:true});else enhance();
if(window.MutationObserver)new MutationObserver(enhance).observe(document.documentElement,{childList:true,subtree:true});
}());
