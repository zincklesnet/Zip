(function(){
'use strict';
function compactCovers(){}
function dedupe(){
  var seen={};
  document.querySelectorAll('.widget,.wp-block-widget,.widget_block').forEach(function(widget){
    var heading=widget.querySelector('.widget-title,.widgettitle,h2,h3');
    var title=(heading?heading.textContent:'').replace(/\s+/g,' ').trim().toLowerCase();
    if(!title)return;
    var key=title+'|'+widget.className.replace(/\s+/g,' ');
    if(seen[key]){widget.hidden=true;widget.setAttribute('aria-hidden','true');}
    else seen[key]=widget;
  });
  var translatorSeen=false;
  document.querySelectorAll('.widget_gtranslate,.gtranslate_wrapper,.translatepress-language-switcher,.wpml-ls').forEach(function(node){
    if(translatorSeen){node.hidden=true;node.setAttribute('aria-hidden','true');}else translatorSeen=true;
  });
}
function run(){compactCovers();dedupe();}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',run,{once:true});else run();
if(window.MutationObserver){var queued=false;new MutationObserver(function(){if(queued)return;queued=true;requestAnimationFrame(function(){queued=false;run();});}).observe(document.documentElement,{childList:true,subtree:true});}
}());
