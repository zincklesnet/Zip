<?php
namespace ZinCelestial\BuddyX\Community;
defined( 'ABSPATH' ) || exit;

final class MemberDirectoryExperience {
    private static bool $rendered = false;

    public static function register(): void {
        add_filter( 'body_class', array( self::class, 'body_classes' ), 40 );
        add_action( 'bp_before_directory_members_content', array( self::class, 'render' ), 4 );
        // One canonical render hook. The prior fallback hook caused duplicate controls on this BuddyPress installation.
    }

    private static function settings(): array {
        return function_exists( 'zcbx_settings' ) ? (array) zcbx_settings() : array();
    }

    private static function is_directory(): bool {
        if ( function_exists( 'bp_is_members_directory' ) ) return (bool) bp_is_members_directory();
        return function_exists( 'bp_is_members_component' ) && bp_is_members_component() && ! ( function_exists( 'bp_is_user' ) && bp_is_user() );
    }

    public static function body_classes( array $classes ): array {
        if ( ! self::is_directory() ) return $classes;
        $settings = self::settings();
        $view = in_array( ( $settings['member_directory_default_view'] ?? 'grid' ), array( 'grid', 'compact', 'spotlight' ), true ) ? $settings['member_directory_default_view'] : 'grid';
        $classes[] = 'zcbx-members-directory-server';
        $classes[] = 'zcbx-directory-view-' . $view;
        $classes[] = empty( $settings['member_directory_pizzazz'] ) ? 'zcbx-directory-experience-disabled' : 'zcbx-directory-experience-enabled';
        return $classes;
    }

    public static function render(): void {
        if ( self::$rendered || ! self::is_directory() ) return;
        $settings = self::settings();
        if ( empty( $settings['member_directory_pizzazz'] ) ) return;
        self::$rendered = true;
        $view = in_array( ( $settings['member_directory_default_view'] ?? 'grid' ), array( 'grid', 'compact', 'spotlight' ), true ) ? $settings['member_directory_default_view'] : 'grid';
        echo '<div id="zcbx-member-directory-experience" class="zcbx-directory-experience-server" data-zcbx-default-view="' . esc_attr( $view ) . '">';
        echo '<header class="zcbx-custom-subheader"><div class="zcbx-custom-subheader__content"><span class="zcbx-custom-subheader__eyebrow">' . esc_html__( 'ZinCelestial Community', 'zincelestial-buddyx' ) . '</span><h1>' . esc_html__( 'Members', 'zincelestial-buddyx' ) . '</h1><p>' . esc_html__( 'Discover people, connections, achievements and community activity.', 'zincelestial-buddyx' ) . '</p></div><span class="zcbx-custom-subheader__mark" aria-hidden="true">&#10022;</span></header>';
        if ( ! empty( $settings['member_directory_command_deck'] ) ) {
            echo '<section class="zcbx-command-deck" aria-label="' . esc_attr__( 'Member directory controls', 'zincelestial-buddyx' ) . '"><div class="zcbx-command-deck__identity"><span class="zcbx-command-deck__icon" aria-hidden="true">&#10022;</span><span><strong>' . esc_html__( 'Member Command', 'zincelestial-buddyx' ) . '</strong><small>' . esc_html__( 'Discover people, connections and achievements', 'zincelestial-buddyx' ) . '</small></span></div>';
            if ( ! empty( $settings['member_directory_allow_view_switch'] ) ) {
                $grid_label = __( 'Grid view', 'zincelestial-buddyx' );
                $grid_description = __( 'Show members as full visual cards in a multi-column grid.', 'zincelestial-buddyx' );
                $compact_label = __( 'Compact view', 'zincelestial-buddyx' );
                $compact_description = __( 'Show members in a tighter, scan-friendly card layout.', 'zincelestial-buddyx' );
                echo '<div class="zcbx-command-deck__actions" role="group" aria-label="' . esc_attr__( 'Member directory view', 'zincelestial-buddyx' ) . '">';
                echo '<button type="button" class="zcbx-command-chip zcbx-command-chip--icon' . ( 'grid' === $view ? ' is-active' : '' ) . '" data-zcbx-view="grid" aria-pressed="' . ( 'grid' === $view ? 'true' : 'false' ) . '" aria-label="' . esc_attr( $grid_label ) . '" aria-describedby="zcbx-grid-view-description"><span class="zcbx-command-chip__icon" aria-hidden="true">' . \ZinCelestial\BuddyX\DesignSystem\SignatureIconRegistry::render( 'directory-grid-view' ) . '</span><span class="zcbx-command-chip__tooltip" role="tooltip"><strong>' . esc_html( $grid_label ) . '</strong><small id="zcbx-grid-view-description">' . esc_html( $grid_description ) . '</small></span></button>';
                echo '<button type="button" class="zcbx-command-chip zcbx-command-chip--icon' . ( 'compact' === $view ? ' is-active' : '' ) . '" data-zcbx-view="compact" aria-pressed="' . ( 'compact' === $view ? 'true' : 'false' ) . '" aria-label="' . esc_attr( $compact_label ) . '" aria-describedby="zcbx-compact-view-description"><span class="zcbx-command-chip__icon" aria-hidden="true">' . \ZinCelestial\BuddyX\DesignSystem\SignatureIconRegistry::render( 'directory-compact-view' ) . '</span><span class="zcbx-command-chip__tooltip" role="tooltip"><strong>' . esc_html( $compact_label ) . '</strong><small id="zcbx-compact-view-description">' . esc_html( $compact_description ) . '</small></span></button>';
                echo '<button type="button" class="zcbx-command-chip zcbx-command-chip--icon' . ( 'spotlight' === $view ? ' is-active' : '' ) . '" data-zcbx-view="spotlight" aria-pressed="' . ( 'spotlight' === $view ? 'true' : 'false' ) . '" aria-label="' . esc_attr__( 'Spotlight view', 'zincelestial-buddyx' ) . '"><span class="zcbx-command-chip__icon" aria-hidden="true">&#10022;</span><span class="zcbx-command-chip__tooltip" role="tooltip"><strong>' . esc_html__( 'Spotlight view', 'zincelestial-buddyx' ) . '</strong><small>' . esc_html__( 'Show members as wide feature cards with expanded details.', 'zincelestial-buddyx' ) . '</small></span></button>';
                echo '</div>';
            }
            echo '</section>';
        }
        if ( ! empty( $settings['member_directory_status_ribbon'] ) ) {
            echo '<div class="zcbx-community-ribbon"><span class="zcbx-community-ribbon__pulse" aria-hidden="true"></span><strong>' . esc_html__( 'Community signal', 'zincelestial-buddyx' ) . '</strong><span>' . esc_html__( 'Explore the member constellation', 'zincelestial-buddyx' ) . '</span></div>';
        }
        echo '</div>';
    }
}
