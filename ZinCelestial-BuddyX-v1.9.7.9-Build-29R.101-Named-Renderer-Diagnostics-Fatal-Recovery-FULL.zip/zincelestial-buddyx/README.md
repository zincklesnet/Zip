# ZinCelestial-BuddyX 1.9.7.6 Build 29R.91

Stage 7 Hover Popups, Scroll, Trigger, and Close Controls. Adds configurable menu-item popup cards and resolves the requested panel interaction issues.

- Package: `ZinCelestial-BuddyX-v1.9.7.6-Build-29R.91-Stage-7-Hover-Popups-Scroll-Trigger-Close-Controls-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.7.5-Build-29R.90-Stage-7-Menu-Item-Hover-Open-Control-Cleanup-FULL.zip`
- Stage 7: active, incomplete
- Main settings schema: Version 1
- Roadmap entries through Stage 33: preserved

# ZinCelestial-BuddyX 1.9.7.5 Build 29R.90

Stage 7 Menu Item Hover and Open-Control Cleanup. Adds separate hover styling for each side and removes duplicate edge controls while a panel is expanded.

- Package: `ZinCelestial-BuddyX-v1.9.7.5-Build-29R.90-Stage-7-Menu-Item-Hover-Open-Control-Cleanup-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.7.4-Build-29R.89-Stage-7-Side-Menu-Administration-Style-Presets-FULL.zip`
- Stage 7: active, incomplete
- Main settings schema: Version 1
- Roadmap entries through Stage 33: preserved

# ZinCelestial-BuddyX 1.9.7.4 Build 29R.89

Stage 7 Side Menu Administration and Style Presets. Configure independent Left and Right Advanced Side Menus from the ZinCelestial administration area.

- Package: `ZinCelestial-BuddyX-v1.9.7.4-Build-29R.89-Stage-7-Side-Menu-Administration-Style-Presets-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.7.3-Build-29R.88-Stage-7-Side-Menu-Runtime-Isolation-Recovery-FULL.zip`
- Stage 7: active, incomplete
- Main settings schema: Version 1
- Roadmap entries through Stage 33: preserved

# ZinCelestial-BuddyX 1.9.7.3 Build 29R.88

Stage 7 Side Menu Runtime Isolation Recovery. Restores isolated, visible Left and Right Advanced Side Menu triggers without changing saved menu assignments.

- Package: `ZinCelestial-BuddyX-v1.9.7.3-Build-29R.88-Stage-7-Side-Menu-Runtime-Isolation-Recovery-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.7.2-Build-29R.87-Stage-7-Resizable-Side-Menu-Panels-FULL.zip`
- Stage 7: active, recovery applied
- Settings schema: Version 1
- Roadmap entries through Stage 33: preserved

# ZinCelestial-BuddyX 1.9.7.2 Build 29R.87

Stage 7 Resizable Side Menu Panels. Adds independent saved desktop widths for the Left and Right Advanced Side Menus while retaining fixed mobile behavior.

- Package: `ZinCelestial-BuddyX-v1.9.7.2-Build-29R.87-Stage-7-Resizable-Side-Menu-Panels-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.7.1-Build-29R.86-Stage-7-Accordion-Nested-Menu-Groups-FULL.zip`
- Stage 7: active, incomplete
- Settings schema: Version 1
- Roadmap entries through Stage 33: preserved

# ZinCelestial-BuddyX 1.9.7.1 Build 29R.86

Stage 7 Accordion and Nested Menu Groups. Adds accessible expandable hierarchy to the independent left and right Advanced Side Menus.

- Package: `ZinCelestial-BuddyX-v1.9.7.1-Build-29R.86-Stage-7-Accordion-Nested-Menu-Groups-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.7.0-Build-29R.85-Stage-7-Advanced-Side-Menus-Foundation-FULL.zip`
- Stage 7: active, incomplete
- Settings schema: Version 1
- Roadmap entries through Stage 33: preserved

# ZinCelestial-BuddyX 1.9.7.0 Build 29R.85

Stage 7 Advanced Side Menus Foundation from protected Build 29R.84. Adds independent WordPress-driven left and right off-canvas menus while preserving the completed Command system.

- Package: `ZinCelestial-BuddyX-v1.9.7.0-Build-29R.85-Stage-7-Advanced-Side-Menus-Foundation-FULL.zip`
- Protected baseline: `ZinCelestial-BuddyX-v1.9.6.4-Build-29R.84-Stage-6-Final-Reconciliation-FULL.zip`
- Stage 7: active, incomplete
- Settings schema: Version 1
- Roadmap entries through Stage 33: preserved

# ZinCelestial-BuddyX 1.9.6.4 Build 29R.84

Stage 6 Final Reconciliation from the approved Build 29R.83 baseline. The Member and Group Command front-page system is reconciled and complete without changing its approved visual presentation.

- Package: `ZinCelestial-BuddyX-v1.9.6.4-Build-29R.84-Stage-6-Final-Reconciliation-FULL.zip`
- Protected baseline: `ZinCelestial-BuddyX-v1.9.6.3-Build-29R.83-Stage-6-Edge-to-Edge-Mapped-Command-Cover-FULL.zip`
- Stage 6A Command Hubs: complete
- Stage 7: not started
- Settings schema: Version 1
- Roadmap entries through Stage 33: preserved

# ZinCelestial-BuddyX 1.9.6.3 Build 29R.83

Stage 6 Edge-to-Edge Mapped Command Cover. Member and Group Command Profile Covers now span the permanent boxed page while preserving mapped BuddyPress cover settings and widget-region gutters.

- Package: `ZinCelestial-BuddyX-v1.9.6.3-Build-29R.83-Stage-6-Edge-to-Edge-Mapped-Command-Cover-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.6.2-Build-29R.82-Stage-6-Dedicated-Command-Header-Foundation-FULL.zip`
- Stage 6: active
- Settings schema: Version 1
- Roadmap entries through Stage 33: preserved

# ZinCelestial-BuddyX 1.9.6.2 Build 29R.82

Stage 6 Dedicated Command Header Foundation. Member and Group Command pages now share a new boxed Left/Center/Right header with independent menus, custom-logo placement, and site-icon monogram placement.

- Package: `ZinCelestial-BuddyX-v1.9.6.2-Build-29R.82-Stage-6-Dedicated-Command-Header-Foundation-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.6.1-Build-29R.81-Stage-6-Permanent-Boxed-Command-Layout-FULL.zip`
- Stage 6: active
- Settings schema: Version 1
- Roadmap entries through Stage 33: preserved

# ZinCelestial-BuddyX 1.9.6.1 Build 29R.81

Stage 6 Permanent Boxed Command Layout. Member and Group Command pages now remain boxed regardless of inherited theme layout settings.

- Package: `ZinCelestial-BuddyX-v1.9.6.1-Build-29R.81-Stage-6-Permanent-Boxed-Command-Layout-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.6.0-Build-29R.80-Stage-6-Native-BuddyPress-Menu-Removal-FULL.zip`
- Stage 6: active
- Settings schema: Version 1
- Roadmap entries through Stage 33: preserved

# ZinCelestial-BuddyX 1.9.6.0 Build 29R.80

Stage 6 Native BuddyPress Menu Removal. Owned Member and Group Command front pages now use only the Command Header shortcuts and Command widget regions.

- Package: `ZinCelestial-BuddyX-v1.9.6.0-Build-29R.80-Stage-6-Native-BuddyPress-Menu-Removal-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.5.9-Build-29R.79-Stage-6-Native-Widget-Area-Removal-FULL.zip`
- Stage 6: active
- Settings schema: Version 1
- Roadmap entries through Stage 33: preserved

# ZinCelestial-BuddyX 1.9.5.9 Build 29R.79

Stage 6 Native Widget Area Removal. Owned member and group Command front pages now retain only their ZinCelestial Primary and Secondary regions.

- Package: `ZinCelestial-BuddyX-v1.9.5.9-Build-29R.79-Stage-6-Native-Widget-Area-Removal-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.5.8-Build-29R.78-Stage-6-Command-Frontpage-Ownership-Foundation-FULL.zip`
- Stage 6: active
- Settings schema: Version 1
- Roadmap entries through Stage 33: preserved

# ZinCelestial-BuddyX 1.9.5.8 Build 29R.78

Stage 6 Command Front-Page Ownership Foundation. Member and group front pages use the ZinCelestial Command Profile Header and ZinCelestial widget regions while remaining connected to authoritative BuddyPress data and permissions.

- Package: `ZinCelestial-BuddyX-v1.9.5.8-Build-29R.78-Stage-6-Command-Frontpage-Ownership-Foundation-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.5.6-Build-29R.76-Stage-6-Command-Hub-Widget-Region-Recovery-FULL.zip`
- Stage 6: active
- Settings schema: Version 1
- Roadmap entries through Stage 33: preserved

# ZinCelestial-BuddyX 1.9.5.6 Build 29R.76

Stage 6 Command Hub Widget Region Recovery. Restores Member and Group Primary and Secondary region enablement by using the authoritative schema-version-1 settings accessor.

- Package: `ZinCelestial-BuddyX-v1.9.5.6-Build-29R.76-Stage-6-Command-Hub-Widget-Region-Recovery-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.5.5-Build-29R.75-Stage-6-Native-Header-Region-Recovery-FULL.zip`
- Stage 6: active
- Settings schema: Version 1
- Roadmap entries through Stage 33: preserved

# ZinCelestial-BuddyX 1.9.5.5 Build 29R.75

Stage 6 Native Header and Region Recovery from the protected Build 29R.72 baseline. Corrects Command Hub placement and asset loading while preserving native BuddyPress headers and configured widgets.

- Package: `ZinCelestial-BuddyX-v1.9.5.5-Build-29R.75-Stage-6-Native-Header-Region-Recovery-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.5.2-Build-29R.72-Stage-6-Responsive-Accessibility-Coverage-FULL.zip`
- Stage 6: active
- Settings schema: Version 1
- Roadmap entries through Stage 33: preserved

# ZinCelestial-BuddyX 1.9.5.2 Build 29R.72

Stage 6 responsive and accessibility coverage for the existing Member and Group Command Hubs, front-page regions, and real-data widgets. Stage 6 remains active and incomplete.

- Package: `ZinCelestial-BuddyX-v1.9.5.2-Build-29R.72-Stage-6-Responsive-Accessibility-Coverage-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.5.1-Build-29R.71-Roadmap-Dark-Mode-Widget-Platform-Reconciliation-FULL.zip`
- Settings schema: Version 1
- Roadmap entries through Stage 33: preserved

# ZinCelestial-BuddyX 1.9.5.1 Build 29R.71

Roadmap reconciliation build. Stage 6 remains active and incomplete. All prior roadmap entries are preserved. Stage 32 Complete ZinCelestial Dark Mode System and Stage 33 ZinCelestial Widget Builder and Intelligent Widget Platform are appended as future milestones. Stage 33 includes Multisite, Network Administration, and connected external WordPress-site widgets. No Stage 32 or Stage 33 runtime implementation is included.

- Package: `ZinCelestial-BuddyX-v1.9.5.1-Build-29R.71-Roadmap-Dark-Mode-Widget-Platform-Reconciliation-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.5.0-Build-29R.70-Stage-6-Command-Hub-Widget-Expansion-Foundation-FULL.zip`
- Settings schema: Version 1
- Standard WordPress/BuddyX Customizer: preserved
- Validation: request-only

# Build 29R.70 Stage 6 Command Hub Widget Expansion Foundation

- Version: 1.9.5.0
- Build: 29R.70
- Package: `ZinCelestial-BuddyX-v1.9.5.0-Build-29R.70-Stage-6-Command-Hub-Widget-Expansion-Foundation-FULL.zip`
- Baseline: complete Build 29R.69 package
- Settings schema: 1, unchanged

## Scope

- Adds real-data Member Summary, Member Activity, Member Connections, Member Groups, Group Summary, and Community Status widgets.
- Widgets are designed for the existing Member and Group Command Hub primary and secondary regions.
- Preserves native BuddyPress permissions, URLs, data, and fallback behavior.
- Reuses existing ZinCelestial surfaces and design tokens.
- Stage 6 remains active and incomplete.

No live, installation, visual, or accessibility validation was performed.
