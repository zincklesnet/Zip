(()=>{
  const panels=[...document.querySelectorAll('.zcbx-advanced-side-panel')];
  const setPanel=(panel,open,restore=true)=>{
    const toggle=document.querySelector(`[aria-controls="${panel.id}"]`);
    panel.classList.toggle('is-open',open);
    panel.setAttribute('aria-hidden',open?'false':'true');
    if(toggle)toggle.setAttribute('aria-expanded',open?'true':'false');
    document.body.classList.toggle('zcbx-advanced-side-panel-open',panels.some(item=>item.classList.contains('is-open')));
    if(open){const focusable=panel.querySelector('a,button');if(focusable)focusable.focus();}
    else if(restore&&toggle)toggle.focus();
  };
  const closeAll=(restore=true)=>panels.forEach(panel=>setPanel(panel,false,restore));
  const setupAccordions=panel=>{
    panel.querySelectorAll('.menu-item-has-children').forEach((item,index)=>{
      const submenu=item.querySelector(':scope > .sub-menu');
      const link=item.querySelector(':scope > a');
      if(!submenu||!link||item.querySelector(':scope > .zcbx-advanced-side-panel__accordion'))return;
      const id=`${panel.id}-submenu-${index+1}`;
      submenu.id=id;
      const current=item.classList.contains('current-menu-ancestor')||item.classList.contains('current-menu-parent');
      const button=document.createElement('button');
      button.type='button';
      button.className='zcbx-advanced-side-panel__accordion';
      button.setAttribute('aria-controls',id);
      button.setAttribute('aria-expanded',current?'true':'false');
      button.innerHTML='<span class="screen-reader-text">Toggle submenu</span><span aria-hidden="true">⌄</span>';
      link.insertAdjacentElement('afterend',button);
      item.classList.toggle('is-expanded',current);
      submenu.hidden=!current;
    });
  };
  panels.forEach(setupAccordions);
  document.addEventListener('click',event=>{
    const panelToggle=event.target.closest('.zcbx-advanced-side-trigger');
    if(panelToggle){const panel=document.getElementById(panelToggle.getAttribute('aria-controls'));if(panel)setPanel(panel,!panel.classList.contains('is-open'));return;}
    const close=event.target.closest('.zcbx-advanced-side-panel__close');
    if(close){const panel=close.closest('.zcbx-advanced-side-panel');if(panel)setPanel(panel,false);return;}
    const accordion=event.target.closest('.zcbx-advanced-side-panel__accordion');
    if(accordion){const submenu=document.getElementById(accordion.getAttribute('aria-controls'));const item=accordion.closest('.menu-item-has-children');if(!submenu||!item)return;const next=accordion.getAttribute('aria-expanded')!=='true';accordion.setAttribute('aria-expanded',next?'true':'false');item.classList.toggle('is-expanded',next);submenu.hidden=!next;}
  });
  document.addEventListener('keydown',event=>{
    if(event.key==='Escape'){closeAll();return;}
    if(event.key!=='Tab')return;
    const panel=panels.find(item=>item.classList.contains('is-open'));if(!panel)return;
    const focusable=[...panel.querySelectorAll('a,button,[tabindex]:not([tabindex="-1"])')].filter(item=>!item.closest('[hidden]'));
    if(!focusable.length)return;
    const first=focusable[0],last=focusable[focusable.length-1];
    if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}
    else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}
  });
})();

(()=>{
  const MIN=240,MAX=520,DEFAULT=320;
  const clamp=value=>Math.max(MIN,Math.min(MAX,Math.round(value)));
  document.querySelectorAll('.zcbx-advanced-side-panel').forEach(panel=>{
    const side=panel.dataset.side;
    const handle=panel.querySelector('.zcbx-advanced-side-panel__resizer');
    if(!handle)return;
    const key=`zcbx-advanced-side-panel-width-${side}`;
    let width=clamp(parseInt(panel.dataset.width||DEFAULT,10));
    try{width=clamp(parseInt(localStorage.getItem(key)||width,10));}catch(error){width=DEFAULT;}
    const apply=value=>{width=clamp(value);panel.style.setProperty('--zcbx-panel-width',`${width}px`);handle.setAttribute('aria-valuenow',String(width));};
    const save=()=>{try{localStorage.setItem(key,String(width));}catch(error){}}
    apply(width);
    handle.addEventListener('pointerdown',event=>{
      if(window.matchMedia('(max-width:782px)').matches)return;
      event.preventDefault();handle.setPointerCapture(event.pointerId);document.body.classList.add('zcbx-advanced-side-panel-resizing');
      const startX=event.clientX,startWidth=width;
      const move=moveEvent=>apply(startWidth+(side==='left'?moveEvent.clientX-startX:startX-moveEvent.clientX));
      const end=()=>{handle.removeEventListener('pointermove',move);document.body.classList.remove('zcbx-advanced-side-panel-resizing');save();};
      handle.addEventListener('pointermove',move);handle.addEventListener('pointerup',end,{once:true});handle.addEventListener('pointercancel',end,{once:true});
    });
    handle.addEventListener('keydown',event=>{
      const direction=side==='left'?1:-1;
      if(event.key==='ArrowRight'){event.preventDefault();apply(width+10*direction);save();}
      else if(event.key==='ArrowLeft'){event.preventDefault();apply(width-10*direction);save();}
      else if(event.key==='Home'){event.preventDefault();apply(MIN);save();}
      else if(event.key==='End'){event.preventDefault();apply(MAX);save();}
    });
  });
})();

/* Build 29R.89: administration-driven state behavior. */
(()=>{
  document.querySelectorAll('.zcbx-advanced-side-panel').forEach(panel=>{
    const side=panel.dataset.side||'left';
    const trigger=document.querySelector(`[aria-controls="${panel.id}"]`);
    const stateKey=`zcbx-advanced-side-panel-state-${side}`;
    let desired=panel.dataset.state||'closed';
    if(panel.dataset.remember==='1'){try{desired=localStorage.getItem(stateKey)||desired;}catch(error){}}
    if(desired==='expanded'&&trigger&&!panel.classList.contains('is-open'))trigger.click();
    if(desired==='compact')panel.classList.add('is-compact');
    const observer=new MutationObserver(()=>{if(panel.dataset.remember==='1'){try{localStorage.setItem(stateKey,panel.classList.contains('is-open')?'expanded':'closed');}catch(error){}}});
    observer.observe(panel,{attributes:true,attributeFilter:['class']});
    if(panel.dataset.closeSelect==='1')panel.addEventListener('click',event=>{if(event.target.closest('.zcbx-advanced-side-panel__list a')&&trigger&&panel.classList.contains('is-open'))trigger.click();});
  });
})();

/* Build 29R.91: accessible hover/focus popup cards. */
(()=>{
  document.querySelectorAll('.zcbx-advanced-side-panel.has-popup_enabled').forEach(panel=>{
    const popup=document.createElement('div');popup.className='zcbx-advanced-side-popup';popup.setAttribute('role','tooltip');popup.id=`${panel.id}-popup`;panel.appendChild(popup);
    let timer=0;
    const place=(link)=>{const r=link.getBoundingClientRect(),p=popup.getBoundingClientRect(),gap=10;let pos=panel.dataset.popupPosition||'auto';if(pos==='auto')pos=panel.dataset.side==='left'?'right':'left';let x=r.right+gap,y=r.top+(r.height-p.height)/2;if(pos==='left')x=r.left-p.width-gap;if(pos==='top'){x=r.left+(r.width-p.width)/2;y=r.top-p.height-gap;}if(pos==='bottom'){x=r.left+(r.width-p.width)/2;y=r.bottom+gap;}x=Math.max(8,Math.min(innerWidth-p.width-8,x));y=Math.max(8,Math.min(innerHeight-p.height-8,y));popup.style.left=`${x}px`;popup.style.top=`${y}px`;};
    const show=link=>{clearTimeout(timer);timer=setTimeout(()=>{popup.textContent=link.getAttribute('aria-label')||link.textContent.trim();if(!popup.textContent)return;link.setAttribute('aria-describedby',popup.id);popup.classList.add('is-visible');place(link);},parseInt(panel.dataset.popupDelay||'180',10));};
    const hide=link=>{clearTimeout(timer);popup.classList.remove('is-visible');if(link)link.removeAttribute('aria-describedby');};
    panel.querySelectorAll('.zcbx-advanced-side-panel__list a').forEach(link=>{link.addEventListener('mouseenter',()=>show(link));link.addEventListener('mouseleave',()=>hide(link));link.addEventListener('focus',()=>show(link));link.addEventListener('blur',()=>hide(link));});
    window.addEventListener('scroll',()=>popup.classList.remove('is-visible'),{passive:true});window.addEventListener('resize',()=>popup.classList.remove('is-visible'));
  });
})();
