# Build 29R.90: Stage 7 Menu Item Hover and Open-Control Cleanup

- Version: 1.9.7.5
- Baseline: `ZinCelestial-BuddyX-v1.9.7.4-Build-29R.89-Stage-7-Side-Menu-Administration-Style-Presets-FULL.zip`
- Package: `ZinCelestial-BuddyX-v1.9.7.5-Build-29R.90-Stage-7-Menu-Item-Hover-Open-Control-Cleanup-FULL.zip`
- Adds per-side hover effects and hover color/style controls.
- Applies hover styling to every menu item with matching keyboard-focus styling.
- Hides the matching edge trigger and resize handle while the panel is open when enabled.
- Preserves the panel header close button.
- Stage 7 remains active and incomplete.
- Main settings schema remains Version 1.
- Validation remains request-only.
