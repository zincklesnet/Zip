# Build 29R.68 Stage 6 Community Layout Framework Foundation

- Added a native BuddyPress Community Layout Framework foundation for member, group, activity, directory, profile, header, feedback, control, and empty-state surfaces.
- Uses existing ZinCelestial design tokens and the existing schema-version-1 `community_layout_enabled` setting.
- Preserves BuddyPress Nouveau and Legacy markup, URLs, permissions, actions, data, and template fallbacks.
- Preserves Member and Group Command Hubs, front-page widget regions, appearance controls, the standard WordPress/BuddyX Customizer, and every roadmap entry through Stage 31.
- Stage 6 remains active and incomplete. Activity and communication presentation plus widget/component expansion remain next.

