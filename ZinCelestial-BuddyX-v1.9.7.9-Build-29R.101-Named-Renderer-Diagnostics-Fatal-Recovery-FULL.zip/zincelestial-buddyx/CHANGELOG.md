# 1.9.7.9 - Build 29R.101 - Named Renderer Diagnostics Fatal Recovery

- Removed the invalid `break` statement left inside `zcbx_render_admin_panel_diagnostics()`.
- Corrects the PHP fatal error: `'break' not in the 'loop' or 'switch' context`.
- Retains the Build 29R.100 renderer registry without other functional changes.

# 1.9.7.8 - Build 29R.100 - Community Experience Named Panel Renderer Registry

- Replaced inline route branches with 18 dedicated renderer functions.
- Added one explicit server-side renderer registry.
- The platform shell now executes one resolved renderer per request.
- Dashboard remains isolated to its renderer.
- Preserved existing administration styling, forms, read-only pages, and settings behavior.
- Kept Advanced Side Menus separate.

# 1.9.7.7 - Build 29R.99 - Community Experience Direct Panel Router Foundation

- Rebuilt Community Experience page routing from protected Build 29R.91.
- Removed shared output buffering and generated-HTML panel extraction.
- Added direct active-panel switch routing for all existing registered panels.
- Dashboard is rendered only by its own selected branch.
- Preserved the Build 29R.91 visual design and field-row styling.
- Kept Advanced Side Menus separate from the platform during this foundation stage.

# 1.9.7.6 - Build 29R.91 - Stage 7 Hover Popups, Scroll, Trigger, and Close Controls

- Added configurable hover/focus popup cards with five placement modes and five visual styles.
- Added detailed popup typography, surface, sizing, blur, delay, and color controls independently per side.
- Restored page scrolling while panels are open by default, with optional scroll lock.
- Added per-side top trigger offset and five trigger presets.
- Added adaptive close-button sizing tied to panel width plus fixed and compact choices.
- Preserved hover styling, hidden expanded controls, runtime isolation, resizing, accessibility, and protected Command pages.

# 1.9.7.5 - Build 29R.90 - Stage 7 Menu Item Hover and Open-Control Cleanup

- Added separate Left and Right menu-item hover controls.
- Added None, Fill, Lift, Slide, Underline, and Glow hover effects.
- Added hover background, text, icon, border, radius, timing, and glow options.
- Matched hover and keyboard-focus presentation.
- Added an enabled-by-default option to hide the edge trigger and resize handle while its panel is open.
- Preserved the header close control, five presets, assigned menus, runtime isolation, accordions, accessibility, and protected Command pages.

# 1.9.7.4 - Build 29R.89 - Stage 7 Side Menu Administration and Style Presets

- Added Appearance > Advanced Side Menus administration.
- Added fully separate Left and Right settings.
- Added Expanded Panel, Compact Icon Rail, Expandable Rail, Floating Utility Dock, and Command Glass Panel presets.
- Added width, compact width, trigger position/icon, default state, display mode, colors, opacity, blur, radius, shadow, glow, separators, close behavior, remembered state, and device controls.
- Added independent menu headers and footers with text and sanitized shortcode fields.
- Preserved WordPress menu assignments, isolated runtime, accordions, resizing, accessibility behavior, and protected Command pages.

# 1.9.7.3 - Build 29R.88 - Stage 7 Side Menu Runtime Isolation Recovery

- Replaced generic side-menu frontend classes with isolated Advanced Side Panel classes.
- Added footer fallback rendering and duplicate-output protection.
- Restored explicit left-edge and right-edge trigger placement.
- Prevented closed panels from leaving clipped menu text or interactive fragments.
- Preserved assigned WordPress menus, accordion behavior, resizing, accessibility safeguards, and Stage 6 Command systems.

# 1.9.7.2 - Build 29R.87 - Stage 7 Resizable Side Menu Panels

- Added separate desktop resize handles for Left and Right Advanced Side Menu panels.
- Constrained panel widths to 240–520 CSS pixels.
- Remembered each panel width in browser-local storage without changing schema Version 1.
- Added keyboard resizing using arrow, Home, and End keys.
- Preserved fixed mobile width, accordion behavior, accessibility safeguards, and completed Stage 6 Command systems.

# 1.9.7.1 - Build 29R.86 - Stage 7 Accordion and Nested Menu Groups

- Added accessible accordion controls to parent items in both Advanced Side Menus.
- Preserved parent menu links as independent navigation targets.
- Collapsed nested groups by default and automatically expanded the active navigation branch.
- Added explicit submenu control relationships and expanded-state updates.
- Preserved Stage 7 foundation behavior and the completed Stage 6 Command system.

# 1.9.7.0 - Build 29R.85 - Stage 7 Advanced Side Menus Foundation

- Started Stage 7 from protected Build 29R.84.
- Registered independent WordPress Left and Right Advanced Side Menu locations.
- Added off-canvas panels that render only for assigned locations.
- Added internal scrolling, nested menu support, active-item highlighting, responsive behavior, Escape closing, focus containment, reduced motion, and forced colors support.
- Added structural header, content, and footer regions in both panels.
- Preserved the completed Stage 6 Command system, permanent boxed Command pages, all roadmap entries, and schema Version 1.

# 1.9.6.4 - Build 29R.84 - Stage 6 Final Reconciliation

- Reconciled the approved Command-page work from Builds 29R.78 through 29R.83.
- Established Build 29R.83 as the protected visual and runtime baseline.
- Marked Stage 6A Member and Group Command Hubs complete.
- Preserved permanent boxed Command pages and rejected full-width Command layouts.
- Preserved the dedicated three-section Command header, independent menu locations, retina logo, monogram, exact five-pixel gap, and edge-to-edge mapped cover.
- Preserved Command widget regions, saved assignments, BuddyPress ownership boundaries, and schema Version 1.
- Stage 7 remains unstarted.
- No new visual or functional scope was introduced.

# 1.9.6.3 - Build 29R.83 - Stage 6 Edge-to-Edge Mapped Command Cover

- Removed horizontal padding from Member and Group Command Profile Covers inside the permanent boxed page.
- Preserved responsive gutters for Command widget regions.
- Confirmed Command Hub Appearance remains mapped to the existing BuddyPress profile/group cover and background settings.
- Enforced an exact five-pixel gap between the dedicated Command header and Command Profile Cover.
- Preserved three independent Command menu locations, saved widgets, boxed ownership, and schema Version 1.

# 1.9.6.2 - Build 29R.82 - Stage 6 Dedicated Command Header Foundation

- Added a new dedicated Command header for Member and Group Command pages.
- Added independent Left, Center Main Menu, and Right sections.
- Registered `ZinCelestial Command Header: Left`, `Center Main Menu`, and `Right` menu locations.
- Added retina-capable custom-logo placement on the left and site-icon monogram placement on the right.
- Did not reuse or copy existing global-site or BuddyPress menu links.
- Removed the ordinary site header and community bar on owned Command pages.
- Positioned Command Profile Headers five pixels below the new header.
- Preserved permanent boxed layout, Command widgets, BuddyPress ownership boundaries, and schema Version 1.

# 1.9.6.1 - Build 29R.81 - Stage 6 Permanent Boxed Command Layout

- Established boxed layout as a permanent invariant for Member and Group Command pages.
- Enforced a centered 1180-pixel maximum content width with responsive horizontal padding.
- Applied the invariant to the Command Profile Header and both Command widget regions.
- Prevented inherited full-width content-area rules from expanding Command pages.
- Preserved Build 29R.80 menu removal, saved widget assignments, BuddyPress connections, and schema Version 1.

# 1.9.6.0 - Build 29R.80 - Stage 6 Native BuddyPress Menu Removal

- Removed native BuddyPress member primary navigation from owned Member Command front pages.
- Removed native BuddyPress group primary navigation from owned Group Command front pages.
- Covered Nouveau and legacy navigation containers including item, object, primary, tab-list, and single-screen navigation wrappers.
- Preserved Command Header shortcut controls and all non-front-page BuddyPress navigation.
- Preserved Command widget regions, saved widget assignments, and schema Version 1.

# 1.9.5.9 - Build 29R.79 - Stage 6 Native Widget Area Removal

- Added request-scoped sidebar filtering on owned member and group Command front pages.
- Member front pages allow only Member Command Primary and Secondary regions.
- Group front pages allow only Group Command Primary and Secondary regions.
- Suppressed residual native BuddyPress/BuddyX, bbPress, theme sidebar, and footer widget containers on those front pages.
- Preserved all saved widget assignments without moving or deleting them.
- Preserved all other pages and every roadmap entry through Stage 33.

# 1.9.5.8 - Build 29R.78 - Stage 6 Command Front-Page Ownership Foundation

- Rebuilt from protected Build 29R.76.
- Rejected Build 29R.77 ownership direction.
- Added a dedicated member/group Command front-page ownership service.
- Suppressed native BuddyPress/BuddyX profile header output only on enabled member and group front pages.
- Suppressed native BuddyPress front-page body and widget output only on enabled member and group front pages.
- Preserved the complete ZinCelestial Member and Group Command Profile Headers.
- Preserved BuddyPress navigation, data, permissions, URLs, actions, and non-front-page component screens.
- Preserved Primary and Secondary ZinCelestial widget regions and saved assignments.
- Preserved every roadmap entry through Stage 33 and schema Version 1.

# 1.9.5.6 - Build 29R.76 - Stage 6 Command Hub Widget Region Recovery

- Corrected `FrontPageRegions::enabled()` to read settings from `zcbx_settings()` instead of the unavailable `zcbx_get_settings()` function.
- Restored the existing schema-version-1 `command_hub_frontpage_regions_enabled` setting.
- Restored rendering access for populated Member and Group Primary and Secondary regions.
- Preserved all saved widget assignments and Build 29R.75 Command Hub placement and stylesheet loading.
- Preserved native BuddyPress headers, navigation, permissions, URLs, data, and fallback behavior.
- Preserved every roadmap entry through Stage 33.

# 1.9.5.5 - Build 29R.75 - Stage 6 Native Header and Region Recovery

- Rebuilt from protected Build 29R.72 instead of superseded Builds 29R.73 or 29R.74.
- Render Member Command Hub through `bp_after_member_header`.
- Render Group Command Hub through `bp_after_group_header`.
- Enqueue Command Hub styles on supported member/group pages without requiring front-page detection during enqueue.
- Removed conditional custom-style dependencies and added file-modification cache versions.
- Kept Primary and Secondary widget regions directly attached to the existing after-hub actions.
- Preserved native BuddyPress headers, navigation, permissions, widgets, saved assignments, URLs, data, and fallback behavior.
- Preserved every roadmap entry through Stage 33 and settings schema Version 1.

# 1.9.5.2 - Build 29R.72 - Stage 6 Responsive and Accessibility Coverage

- Added container-aware responsive reflow for Member and Group Command Hubs.
- Added narrow-region stacking for metrics, shortcuts, widget rows, and Command Hub front-page regions.
- Added consistent visible focus indicators and 44-pixel minimum interactive targets within Stage 6 surfaces.
- Added long-text containment, responsive media containment, forced-colors support, and reduced-motion behavior.
- Preserved native BuddyPress permissions, URLs, data, and fallback behavior.
- Preserved every roadmap entry through Stage 33, `zcbx_settings`, schema Version 1, and the standard WordPress/BuddyX Customizer.
- Stage 6 remains active and incomplete pending final reconciliation.

# 1.9.5.1 - Build 29R.71 - Roadmap Dark Mode and Widget Platform Reconciliation

- Preserved every existing roadmap entry through Stage 31.
- Appended Stage 32 Complete ZinCelestial Dark Mode System.
- Appended Stage 33 ZinCelestial Widget Builder and Intelligent Widget Platform.
- Added explicit WordPress Multisite, Network Administration, and connected external WordPress-site widget scope.
- Preserved Stage 6 as active and incomplete.
- Preserved `zcbx_settings`, settings schema Version 1, and the standard WordPress/BuddyX Customizer.
- Added no Stage 32 or Stage 33 runtime or styling implementation.

## 1.9.5.0 - Build 29R.70 - Stage 6 Command Hub Widget Expansion Foundation

- Added six real-data Command Hub widgets for members and groups.
- Integrated widgets with the existing primary and secondary Command Hub regions.
- Preserved BuddyPress behavior, Stage 1-31 roadmap entries, schema version 1, and the standard Customizer.
- Stage 6 remains active and incomplete.

## 1.9.4.9 - Build 29R.69 - Stage 6 Activity and Communication Foundation

- Added an activity and communication presentation layer for native BuddyPress activity items and group activity.
- Coordinated threaded activity comments and replies, composer forms, action controls, notices, status feedback, privacy and visibility indicators, loading controls, focus presentation, responsive behavior, and reduced-motion handling.
- Reused the existing Community Layout Framework setting and ZinCelestial design tokens.
- Preserved native BuddyPress permissions, actions, data, URLs, and fallback behavior.
- Kept future Stage 31 moderation outside this build.
- Preserved `zcbx_settings`, settings schema version 1, and the standard WordPress/BuddyX Customizer.
- Baseline: `ZinCelestial-BuddyX-v1.9.4.8-Build-29R.68-Stage-6-Community-Layout-Framework-Foundation-FULL.zip`.

# v1.9.4.8 Build 29R.68 - Stage 6 Community Layout Framework Foundation

- Added the Community Layout Framework foundation using native BuddyPress wrappers.
- Coordinated cards, surfaces, spacing, controls, feedback, focus treatment, and responsive behavior through existing ZinCelestial design tokens.
- Preserved BuddyPress Nouveau and Legacy output, URLs, permissions, actions, data, and fallbacks.
- Preserved Member and Group Command Hubs, front-page regions, appearance controls, `zcbx_settings`, schema version 1, and the standard WordPress/BuddyX Customizer.
- Stage 6 remains active and incomplete.

# v1.9.4.7 Build 29R.67 - Stage 6 Command Hub Appearance Foundation

- Connected Member and Group Command Hubs to the existing profile and group background and cover-image controls.
- Reused existing desktop/mobile images, positioning, sizing, repeat, overlay color, and overlay opacity settings.
- Added responsive mobile-image handling scoped to the Command Hubs.
- Added no second appearance system and no settings schema migration.
- Preserved native BuddyPress navigation, permissions, URLs, and fallback content.
- Stage 6 remains active and incomplete.

# 1.9.4.6 - Build 29R.66

- Continued Stage 6 with configurable Member and Group Command Hub front-page widget regions.
- Registered primary and secondary widget regions for member and group front pages.
- Rendered only populated regions below the existing Command Hub foundations.
- Added a schema-version-1 administrator toggle and responsive region styling.
- Preserved native BuddyPress content, permissions, URLs, fallbacks, and all prior roadmap entries.
- Stage 6 remains active and incomplete.

# 1.9.4.5 - Build 29R.65

- Continued Stage 6 with the BuddyPress-native Group Command Hub foundation.
- Added group identity, member count, activity, members, and overview shortcuts using native BuddyPress group data and URLs.
- Added an administrator enable/disable control using the existing schema-version-1 settings system.
- Preserved Build 29R.64 Member Command Hub, native BuddyPress navigation, permissions, and fallback content.
- Stage 6 remains active and incomplete.

# 1.9.4.4 - Build 29R.64 Stage 6 Member Command Hub Foundation

- Began Stage 6A with a BuddyPress-native Member Command Hub overview shell on member front pages.
- Added member identity, connection, group, and activity summaries using existing BuddyPress data and URLs.
- Added administrator enable/disable control within the existing schema-version-1 settings system.
- Preserved native BuddyPress profile navigation, template content, permissions, and fallback behavior.
- Reused the existing ZinCelestial visual tokens and responsive presentation without introducing another component or icon system.
- Preserved every roadmap stage through Stage 31; Stage 6 remains active and incomplete.
- Baseline: `ZinCelestial-BuddyX-v1.9.4.3-Build-29R.63-Roadmap-Reconciliation-FULL.zip`.
- Package: `ZinCelestial-BuddyX-v1.9.4.4-Build-29R.64-Stage-6-Member-Command-Hub-Foundation-FULL.zip`.

# 1.9.4.3 - Build 29R.63 Roadmap Reconciliation

- Preserved every existing roadmap entry and stage.
- Recorded Stage 5 Navigation Icon Controls as completed through Build 29R.62.
- Defined Stage 6 Deferred Community Experience Features as the active next milestone with command hubs, appearance, community layouts, activity and communication, widgets, and explicit completion conditions.
- Appended Stage 30 Main Menu and Mega Menu System without replacing Stage 7 Advanced Left and Right Menu System.
- Appended Stage 31 Network Moderation and Community Safety System with multisite, network, group, user, external-site, reporting, privacy, enforcement, blocking, muting, suspension, and administrator controls.
- Preserved `zcbx_settings`, settings schema version 1, and the standard WordPress/BuddyX Customizer.
- No functional runtime code or styling scope was added.
- Baseline: ZinCelestial-BuddyX-v1.9.4.2-Build-29R.62-Stage-5-Presets-Bulk-Actions-FULL.zip.

# Changelog

## 1.9.4.2 - Build 29R.62: Stage 5 Presets and Bulk Actions

- Added navigation icon preset export as a portable JSON file.
- Added navigation icon preset import with item ID and menu-label matching.
- Added bulk application of Playground and built-in navigation presets.
- Added bulk clearing of Signature Icon assignments without removing menu labels or native menu data.
- Preserved the existing Signature Icon Library, WordPress menu editor, BuddyPress profile-navigation runtime, settings schema version 1, and standard WordPress/BuddyX Customizer.
- Completed the approved Stage 5 Navigation Icon Controls roadmap scope.

## 1.9.4.2 - Build 29R.62 - Stage 5 Playground and Navigation Controls

- Connected the ZinCelestial Libraries Playground to navigation icon assignments through reusable navigation presets.
- Added icon size, spacing, placement, alignment, mobile visibility, variant, color, opacity, glow, and interaction-color controls.
- Added accessible icon-only labels and responsive mobile display choices.
- Added clear and Apply Playground preset actions to native WordPress menu items.
- Preserved the existing Signature Icon Library as the only icon source, schema version 1, and native WordPress menu behavior.
- Baseline: `ZinCelestial-BuddyX-v1.9.4.0-Build-29R.60-Stage-5-Navigation-Icon-Controls-Foundation-FULL.zip`.

## 1.9.4.0 - Build 29R.60 - Stage 5 Navigation Icon Controls Foundation

- Started Stage 5 using the existing ZinCelestial Signature Icon Library as the only icon source.
- Added native WordPress menu-item Signature Icon selection.
- Added before-label, after-label, above-label, below-label, and icon-only placement.
- Preserved menu labels for assistive technology in icon-only mode.
- Added reduced-motion-safe frontend presentation without replacing WordPress, BuddyX, or BuddyPress navigation behavior.
- Preserved `zcbx_settings`, settings schema version 1, and the standard WordPress/BuddyX Customizer.
- Baseline: `ZinCelestial-BuddyX-v1.9.3.5-Build-29R.59-Member-Directory-Stage-Closeout-FULL.zip`.

## 1.9.3.5 - Build 29R.59 - Member Directory Stage Closeout

- Removed Spotlight from settings sanitization, administration choices, server runtime, frontend runtime, view controls, and styling.
- Removed the custom Active, Newest, A-Z, and Reset buttons from the Members subheader.
- Preserved the custom Search Members field, Grid view, Compact view, `zcbx_settings`, schema version 1, and the standard WordPress/BuddyX Customizer.
- Confirmed Stage 5 Navigation Icon Controls as the next official milestone.

## 1.9.3.4 — Build 29R.58 — Spotlight and Filter Recovery

- Repaired custom member search, Active, Newest, A–Z, and reset controls by delegating them to the native BuddyPress directory controls.
- Rebuilt Spotlight cards as featured profiles with a controlled cover rail, anchored avatar, stronger identity hierarchy, organized rewards, and a dedicated action area.
- Preserved Grid and Compact presentation, settings schema version 1, the standard WordPress/BuddyX Customizer, and the existing Signature Icon registry.
- Baseline: Build 29R.57 Member Directory Recovery.

# 1.9.3.3 - Build 29R.57 Member Directory Recovery

- Preserved Grid as the default member-directory view and added Spotlight to the schema-version-1 sanitizer allowlist and administration selector.
- Corrected initial directory-view handling so configured and remembered Grid, Compact, and Spotlight selections remain valid.
- Replaced duplicate friendship SVG paths with the existing `friendship-add` and `friendship-cancel` entries in `window.ZCBX_SIGNATURE_ICONS`, preserving accessible labels and tooltips.
- Reconciled theme metadata and governance for Build 29R.57.
- Recorded Stage 4 Signature Icon Library as completed across Builds 29R.23 through 29R.30; Stage 5 Navigation Icon Controls is next.
- Preserved the standard WordPress/BuddyX Customizer and settings schema version 1.
- Protected recovery baseline: ZinCelestial-BuddyX-v1.9.3.1-Build-29R.55-Signature-Filter-Friendship-Controls-FULL.zip.

# 1.9.3.1 - Build 29R.55 Signature Filter and Friendship Controls

- Added a reset-filters Signature Icon control.
- Replaced Active, Newest, and A–Z text controls with 20px ZinCelestial Signature Icons and hover descriptions.
- Standardized Grid and Compact view Signature Icons at 20px.
- Replaced Add Friend and Cancel Friendship card actions with 20px ZinCelestial Signature Icons and hover descriptions while preserving BuddyPress action targets.
- Baseline: ZinCelestial-BuddyX-v1.9.3.0-Build-29R.54-Spotlight-Refinement-Subheader-Filters-FULL.zip.

# 1.9.3.0 - Build 29R.54 Spotlight Refinement and Subheader Filters

- Added refined two-column Spotlight cards with a vertical cover rail and anchored avatar.
- Added custom-subheader search and Active, Newest, and A–Z directory filters.
- Filters bridge to BuddyPress native search and ordering controls.
- Retained expanded GamiPress rewards, equal-height cards, and decorative line-break removal.
- Baseline: ZinCelestial-BuddyX-v1.9.2.8-Build-29R.52-Subheader-Removal-GamiPress-Card-Fit-FULL.zip.

# 1.9.2.8 - Build 29R.52 Subheader Removal and GamiPress Card Fit

- Removed the current frontend site subheader and disabled its legacy runtime style output.
- Added a dedicated subheader-removal stylesheet so a custom replacement can be introduced later.
- Consolidated all distinct GamiPress reward blocks into one compact member-card reward tray.
- Physically moved the username after the complete reward tray in the member-card DOM.
- Standardized reward spacing, container sizing, and 20px icon presentation.
- Preserved Build 29R.51 grid spacing and compact-view behavior.
- Baseline: ZinCelestial-BuddyX-v1.9.2.7-Build-29R.51-Member-Card-Final-Spacing-FULL.zip.

# 1.9.2.7 - Build 29R.51 Member Card Final Spacing

- Moved member usernames below GamiPress reward rows in both grid and compact views.
- Reduced Member Directory grid spacing from 34px to 22px without changing compact spacing.
- Reduced member-card body left and right padding by 5px, from 24px to 19px, without changing compact padding.
- Preserved group cards, subheader behavior, settings schema version 1, and all unrelated systems.
- Baseline: ZinCelestial-BuddyX-v1.9.2.6-Build-29R.49-Member-Directory-Runtime-Stability-FULL.zip.

# 1.9.2.6 - Build 29R.49 Member Directory Runtime Stability

- Fixed the member directory page hang caused by recursive MutationObserver updates.
- Added bounded, debounced, idempotent card normalization.
- Preserved username-before-GamiPress ordering without continuous DOM movement.

# 1.9.2.3 - Build 29R.46 Member Identity and Signature View Controls

- Moved member identity and username above GamiPress output in directory cards.
- Preserved the audited Build 29R.44 directory card engine, BuddyPress actions, and schema version 1.
- Baseline: ZinCelestial-BuddyX-v1.9.2.1-Build-29R.44-Audited-Directory-Card-Engine-FULL.zip.

# 1.9.2.1 - Build 29R.44 Audited Directory Card Engine

- Replaced all legacy and additive member/group card CSS with one canonical audited engine.
- Added separate Member Directory and Group Directory adapters.
- Removed arbitrary image cover fallback; fallback now requires a verified wide image ratio.
- Removed directory cover mutation from layout-runtime-cleanup.js.
- Removed fixed card heights, minimum heights, grid rows, and obsolete compact cover relocation.
- Preserved BuddyPress content, actions, mobile navigation, saved settings, and schema version 1.
- Baseline: ZinCelestial-BuddyX-v1.9.2.0-Build-29R.43-Directory-Card-Final-Restoration-FULL.zip.

# 1.9.2.0 - Build 29R.43 Directory Card Final Restoration

- Removed all generated and separate desktop submenu arrows from the site header.
- Replaced Build 29R.42 image-moving logic with safe cover cloning.
- Removed forced equal-height and minimum-height card behavior that created empty lower panels.
- Corrected Member Directory and Group Directory card ordering, cover placement, avatar overlap, content flow, and action placement.
- Preserved BuddyPress content, actions, mobile navigation, saved settings, and schema version 1.
- Baseline: ZinCelestial-BuddyX-v1.9.1.9-Build-29R.42-Member-Group-Directory-Card-Restoration-FULL.zip.

# 1.9.1.9 - Build 29R.42 Member and Group Directory Card Restoration

- Restored Member Directory cards to the supplied member-card references.
- Restored Group Directory cards to the supplied group-card references.
- Removed the oversized desktop submenu arrow controls shown in arrows.png.
- Preserved BuddyPress-generated identities, metadata, actions, schema version 1, saved settings, and mobile navigation.
- Baseline: ZinCelestial-BuddyX-v1.9.1.8-Build-29R.41-Member-Directory-Visual-Restoration-FULL.zip.

# 1.9.1.8 - Build 29R.41 Member Directory Visual Restoration

- Restored the compact Member Command and Community Signal presentation.
- Restored the approved two-column member card grid with full-width top covers and overlapping avatars.
- Added runtime cover normalization to prevent detached member-cover blocks.
- Preserved the server-rendered administration shell and schema version 1.

# 1.9.1.7 - Build 29R.40 Live Variants, 400% Zoom, and Navigation Audit

- Loaded the shared Signature Icon variant stylesheet inside ZinCelestial Administration.
- Restored visible Plain, Badge, Glow, and Button preview changes.
- Audited live update paths plus all top-level navigation icon sizing at normal and 320 CSS pixel widths.
- Preserved the server-rendered panel shell and schema version 1.

# 1.9.1.6 - Build 29R.39 Icon Preview and Navigation Size Fix

- Restored visible Icon Preview Playground SVG rendering.
- Rebuilt preview SVGs on every selection, variant, size, and color change.
- Unified all top-level administration icons to 24px inside consistent 48px link targets.
- Preserved the server-rendered one-panel shell and schema version 1.

# 1.9.1.5 - Build 29R.38 Server-Rendered Panel Shell

- Replaced browser-side page simulation with an authoritative panel registry and one-panel server response.
- Read-only screens now render outside forms; editable screens receive a form containing only the active panel.
- Navigation is server-first and works without JavaScript.
- Preserved settings schema version 1 and protected systems.

# 1.9.1.4 - Build 29R.37 Server-Side Panel Routing Recovery

- Replaced fragile form-ancestry panel detection with explicit top-level panel classes.
- Converted icon navigation controls into real server-routed links with validated active-panel selection.
- Added server-side isolation plus optional JavaScript enhancement, restoring navigation even when scripts fail.
- Preserved global field rows and schema version 1.

# 1.9.1.3 - Build 29R.36 Administration Panel Isolation Recovery

- Repaired the regression that rendered every ZinCelestial administration panel on one continuous page.
- Scoped main navigation to direct top-level panels and enforced hard inactive-panel isolation.
- Added hidden/ARIA synchronization, saved-tab validation, Dashboard fallback, and pre-initialization isolation.
- Preserved the approved global field-row presentation and schema version 1.

# 1.9.1.2 - Build 29R.35 Global Field Rows and 400% Zoom

- Applied the explicit `zcbx-field-row` class to every generated settings row.
- Corrected top-level settings controls without relying on section ancestry.
- Added global desktop, tablet, mobile, and 320 CSS pixel field behavior.
- Completed all-panel source-level 400% zoom-equivalent checks while retaining live-browser verification as pending.

# 1.9.1.1 - Build 29R.34 Administration Control Structure and Reflow

- Corrected run-together administration labels, defaults, checkboxes, selects, sliders, and outputs.
- Added wide two-column field structure with tablet, mobile, and 400% zoom stacking.
- Added accessible range labels and polite output updates without changing saved settings or schema version 1.

# 1.9.1.0 - Build 29R.33 Accessibility Live-Verification Preparation

- Added hidden panel state synchronization, roving library-tab focus, and screen-reader copy announcements.
- Added explicit 320 CSS pixel reflow hardening for 400% zoom conditions.
- Added a truthful verification record separating passed source checks from pending live assistive-technology tests.
- Preserved schema version 1 and protected systems.

# 1.9.0.9 - Build 29R.32 Accessibility, Group Icons, and Responsive Audit

- Added accessible Signature Icons to core BuddyPress group navigation contexts.
- Completed and documented a WCAG 2.2 AA-oriented static accessibility audit.
- Added ARIA tab semantics, keyboard tab operation, focus visibility, target sizing, forced-colors, reduced-motion, and responsive library corrections.
- Preserved schema version 1, News Feed activity parity, and native BuddyX sidebars.

# 1.9.0.8 - Build 29R.31 Library Layout Containment Fix

- Corrected malformed Signature Icon Library grid containment shown in the supplied screenshots.
- Separated the Preview Playground, Runtime Usage, and Context Assignment Matrix from the icon-card grid.
- Added responsive overflow and text containment safeguards.
- Hid irrelevant Save Settings controls on read-only panels.

# 1.9.0.7 - Build 29R.30 Unified Administration Libraries

- Unified Element, Component, and Signature Icon Libraries under coordinated library sub-navigation.
- Added read-only Element and Component catalogs with extension filters and counts.
- Preserved complete Signature Icon Library functionality and schema version 1.

# 1.9.0.6 - Build 29R.29 Signature Icon Preview and Variants

- Added a non-persistent Signature Icon Preview Playground.
- Added plain, badge, glow, and button variants with sanitized color and constrained sizing.
- Added copyable generated shortcode output.
- Preserved schema version 1, activity parity, and native BuddyX sidebars.

# 1.9.0.5 - Build 29R.28 Signature Icon Diagnostics

- Added read-only registry diagnostics and health reporting.
- Detects missing alias/context targets and incomplete icon records.
- Added icon diagnostics to the existing system diagnostics snapshot.
- Preserved activity parity, native sidebars, and settings schema version 1.

# 1.9.0.4 - Build 29R.27 Icon Context Matrix and Export

- Added a read-only context assignment matrix to the Signature Icon Library.
- Added an administrator-only, nonce-protected registry JSON export.
- Preserved profile icon integration, News Feed parity, native sidebars, and settings schema version 1.

# 1.9.0.3 - Build 29R.26 Signature Icon Context API

- Added stable aliases, category retrieval, and a filterable context-to-icon map.
- Added global icon and context rendering helper functions.
- Added copy-shortcode controls to the shared Signature Icon Library.
- Preserved profile integration, activity parity, native sidebars, and settings schema version 1.

# 1.9.0.2 - Build 29R.25 Profile Menu Signature Icons

- Expanded the Signature Icon Registry for BuddyPress profile menu contexts.
- Added a controlled frontend registry payload and profile navigation icon resolver.
- Preserved administrator-provided custom icon images as the highest-priority choice.
- Preserved News Feed activity parity, native BuddyX sidebars, and settings schema version 1.

# 1.9.0.1 - Build 29R.24 Signature Icon Runtime Integration

- Added the reusable Signature Icon frontend runtime and `[zcbx_icon]` shortcode.
- Integrated matching registry icons into ZinCelestial Administration navigation.
- Added accessible labels, decorative mode, controlled sizing, fallback behavior, glow, and reduced-motion-aware styling.
- Preserved activity parity, native BuddyX sidebars, and settings schema version 1.

# 1.9.0.0 - Build 29R.23 Signature Icon Registry

- Added the reusable SignatureIconRegistry with stable keys, categories, accessible SVG rendering, fallback behavior, and extension filtering.
- Added search, category filtering, result count, previews, and copy-key controls to the shared ZinCelestial Administration Libraries section.
- Preserved News Feed activity parity, native BuddyX sidebars, and settings schema version 1.

# 1.8.9.9 - Build 29R.22 Activity Parity and Administration Libraries Foundation

- Restored Member Activity padding and card containment to the sitewide News Feed.
- Added a shared Libraries tab inside ZinCelestial Administration.
- Placed Element Library, Component Library, and Signature Icon Library together.
- Added the Signature Icon Library foundation without changing settings schema version 1.
- Preserved native BuddyX sidebar ownership and existing activity functionality.

# 1.8.9.8 - Build 29R.21 Member Card Rhythm and Widget Cleanup

- Corrected Compact covers so they cannot render below member rewards.
- Reduced Grid card height and normalized action containment.
- Added compact native Groups card safeguards.
- Strengthened retired widget-region unregistration and duplicate widget/language-switcher cleanup.
- Preserved native BuddyX sidebar controls and settings schema version 1.

# 1.8.9.7 - Build 29R.20 Members and Groups Layout Cleanup

- Consolidated six overlapping Members Directory stylesheets into one authoritative layout file.
- Removed obsolete heading width calculations, negative margins, and retired shell assumptions.
- Added content-width-safe Grid and Compact member cards.
- Added responsive containment for native BuddyPress Groups directory output.
- Preserved native BuddyX sidebar controls and settings schema version 1.

# 1.8.9.5 - Build 29R.18 Sidebar-System Removal

- Removed the ZinCelestial Community Layout shell and member/group sidebar regions.
- Removed the current BuddyX Site Sidebar Customizer controls and forced retired layouts to no-sidebar.
- Removed obsolete Build 29R.17 overrides and Build 29R.16 title/sidebar relocation.
- Preserved member-directory experience features and settings schema version 1.

# Changelog

## 1.8.9.3 - Build 29R.16 - Canonical Directory Panel

- Removed the duplicate BuddyPress directory render hook.
- Added canonical panel deduplication for initial and AJAX-rendered content.
- Structurally moved and normalized the Members title row across the complete directory shell.

## 1.8.9.2 - Build 29R.15 - Member Directory Single Runtime

- Removed duplicate frontend rendering of the ribbon and Command Deck.
- Corrected Grid and Compact targeting to complete member entries.
- Rebuilt Compact desktop and mobile layouts.
- Versioned remembered visitor view storage.

## 1.8.9.0 - Build 29R.13 - Member Directory Settings Runtime Correction

- Corrected live BuddyPress directory detection.
- Connected all Member Directory Experience settings to actual live card and directory wrappers.
- Made Grid and Compact layouts visibly distinct.
- Corrected off-state saving for the new experience checkboxes.

## 1.8.8.9 - Build 29R.12 - Member Directory Experience Settings

- Added a Member Directory Experience section to the existing administration page.
- Added persisted schema-1 settings for Grid/Compact defaults, visitor switching, browser memory, Command Deck, ribbon, card accents, avatar rings, achievement constellation, glass, motion, and tablet behavior.
- Connected frontend Pizzazz behavior to the saved administration settings.

## 1.8.8.8 - Build 29R.11 - Community Pizzazz Candidate

- Structurally moved the Members heading above the content/sidebar layout row.
- Added a contextual Member Command Deck and community status ribbon.
- Added Signature member-card accents, avatar rings, achievement constellation styling, and compact view.
- Added coordinated light/dark and reduced-motion treatments.

## 1.8.8.7 - Build 29R.10 - Member Directory Final Order

- Expanded and centered the Members sub-header across the live content and sidebar span.
- Moved member avatars above GamiPress reward groups.
- Removed absolute avatar overlap and standardized avatar-to-reward spacing.

## 1.8.8.6 - Build 29R.9 - Member Directory Final Alignment

- Removed black tab and search-area separator lines.
- Re-aligned the Members sub-header to the full directory width.
- Separated GamiPress reward rows from member avatars.
- Lowered and centered directory avatars with consistent clearance.

## 1.8.8.5 - Build 29R.8 - Member Directory Structure Correction

- Corrected the split Members title background and centered the complete title surface.
- Corrected inset member-card cover areas and inconsistent internal spacing.
- Standardized avatar overlap, reward alignment, identity spacing, and dark-mode equivalents.

## 1.8.8.4 - Build 29R.7 - Live Directory Visual Correction

- Removed the second oversized desktop dropdown arrow.
- Corrected sticky-header flow and scroll clearance.
- Reconciled member-card spacing, surfaces, borders, shadows, links, and action buttons.
- Added coordinated right-sidebar and dark-mode card surfaces.

## 1.8.8.3 - Build 29R.6 - CSS and Dark-Mode Audit Correction

- Darkened coordinated light-theme surfaces and borders.
- Removed white frontend widget and card surfaces in dark mode.
- Corrected primary, muted, link, placeholder, form, table, and metadata contrast.
- Added a final audited color-scheme stylesheet after the retained foundation.

## 1.8.8.2 - Build 29R.5 - Header Menu Final Correction

- Removed duplicate desktop dropdown arrows.
- Removed header-navigation link underline color and decoration.
- Hid the mobile hamburger control on desktop while preserving mobile display.

## 1.8.8.1 - Build 29R.4 - Header Menu Dropdown Correction

- Corrected oversized desktop dropdown indicators extending below the site header.
- Contained parent-menu toggle controls and icons within the header row.
- Preserved submenu behavior and mobile navigation layout.

## 1.8.8.0 - Build 29R.3 - Customizer Scaffold Cleanup

- Completed removal of the inactive ZinCelestial Community Experience Customizer ownership scaffold.
- Removed CommunitySettingsMigrator, CommunityMigrationSnapshot, and NavigationInventory.
- Preserved standard WordPress/BuddyX Customizer behavior, administration settings, saved data, schema version 1, and frontend runtime.
- Deferred the ZinCelestial Community Experience Customizer indefinitely.
- Set Stage 4 Signature Icon Library as the next roadmap milestone.

## 1.8.7.8 - Build 29R.1 - Customizer Preview Refresh Correction

- Unified every ZinCelestial Customizer setting under a controls-side debounced preview refresh.
- Included delegated Community Layout controls in the same preview path.
- Disabled the obsolete preview-side three-setting refresh bridge.
- Preserved schema version 1 and the externalized component-library boundary.

## 1.8.7.7 - Build 29R - Visual Foundation Externalization

- Removed global loading of the uploaded-board component layer.
- Removed board-derived component and integration styles from the theme package.
- Removed component-board images and the board-derived ComponentRegistry.
- Preserved the reusable implementation in ZinCelestial Skin Component Library v1.0.0.
- Preserved settings schema version 1 and the protected Build 28 baseline.
- Added a minimal theme core-token layer so retained theme styles do not depend on the externalized library.

# Build 28 Stage 2 Certification

## 1.8.7.6 - Build 28

### Changed
- Reconciled Theme Name to ZinCelestial-BuddyX and Author to Zinckles.
- Reconciled release version to 1.8.7.6 and build number to 28.
- Reconciled root metadata, current roadmap status, changelog, and package manifest.
- Recorded Stage 2 as certified and approved by the project owner.
- Recorded the current policy that validation is performed only when explicitly requested.

### Preserved
- Complete protected baseline: ZinCelestial-BuddyX-v1.8.7.5-Build-27-Customizer-Fatal-Recovery-FULL.
- Settings schema version 1 and the existing `zcbx_settings` option.
- Protected save engine, active asset loader, Customizer ownership, Community Layout behavior, and integration ownership.
- Build 27 duplicate `OptionRegistry::is_color()` fatal-recovery correction.
- Stage 3 remains planning-only and is not implemented in Build 28.

## 1.8.7.5 - Build 27 - Customizer Fatal Recovery

- Removed the duplicate OptionRegistry::is_color() declaration introduced in Build 26.
- Consolidated color detection into the existing helper while retaining semantic color-picker behavior.
- Restored Customizer loading without changing setting IDs, schema version, defaults, sanitizers, or Stage 2 control scope.

## 1.8.7.4 - Build 26 - Stage 2 Semantic Customizer Controls

- Added WordPress color-picker controls for color-valued settings.
- Added synchronized slider and precise number inputs for bounded numeric settings.
- Added responsive and keyboard-focus styling for the new numeric controls.
- Preserved all setting IDs, defaults, sanitization, schema version 1, administration-page synchronization, runtime behavior, and prior roadmap scope.
- Stage 3 remains blocked pending live Stage 2 certification and promotion approval.

## 1.8.7.3 - Build 25 - Stage 2 Customizer Certification Kit

### Added
- Stage 2 Customizer certification matrix and live evidence record.
- Build 25 certification checklist and governance reconciliation.

### Preserved
- Complete Build 24 functionality and Stage 1 corrections.
- Settings schema version 1, protected systems, Community Layout delegation, and platform asset separation.
- Stage 3 remains unstarted.

### Validation status
- Static package validation completed.
- Live WordPress staging certification remains pending.
- Promotion remains on hold.

## 1.8.7.2 - Build 24 - Shared Label Helper Correction and Customizer Registration Verification

### Fixed
- Removed malformed shared label-map fragments in the Stage 1 option registry.
- Restored the plain-text Profile Header Layout label.

### Verified
- Scanned all Customizer registration owners and created a registration verification matrix.
- Preserved duplicate guards, Community Layout delegation, protected systems, and settings schema version 1.
- Live WordPress staging validation remains pending.

# Build 23 - v1.8.7.1
- Rebuilt the shared admin control renderers as direct PHP/HTML templates.
- Removed affected literal concatenation fragments from select, checkbox, range, color, and media renderers.
- Added package-wide literal-fragment and archive-integrity rescans.

## 1.8.7.0 - Build 22 - Stage 1 Customizer Integration Staging Candidate

### Added
- Stage 1 Customizer option registry and registration bootstrap.
- Existing sanitizer allowlist, numeric range, administration label, and image-media control reconciliation.
- Duplicate-registration guards, read-only ownership and diagnostics sections, and refresh-based preview transport.
- Stage 1 static validation, staging checklist, evidence record, handoff manifest, and final boundary audit.

### Preserved
- Complete Build 21 baseline functionality and existing administration page.
- Protected save engine, save script, and asset loader.
- Settings schema version 1, Community Layout delegation, and platform asset separation.
- Stage 2 remains unstarted.

### Validation status
- Static validation and scope-boundary audit passed.
- Live WordPress staging validation remains pending.
- Packaged only as a staging candidate, not as a stable release.

## 1.8.6.9 - Build 21 - VS-10 Certification Traceability and Promotion Decision Controls

### Added
- Certification traceability matrix.
- Promotion decision register.
- Rollback rehearsal procedure.
- Defect triage policy.
- Build 21 checklist and validation report.

### Preserved
- Full VS-2 through VS-10 implementation and governance.
- Protected systems, settings schema version 1, Customizer authority, and platform asset separation.
- Build 16 as the approved stable baseline.
- No VS-11 milestone introduced or started.

## 1.8.6.8 - Build 20 - VS-10 Staging Certification Execution Kit

### Added
- Staging certification execution kit.
- Evidence index and defect-record template.
- Build 20 staging checklist and validation report.

### Preserved
- Complete VS-2 through VS-10 coverage and governance.
- Protected systems, settings schema 1, Customizer authority, and platform asset separation.
- Stable promotion hold pending live evidence and explicit approval.
- No VS-11 milestone was introduced or started.

## 1.8.6.7 - Build 19 - VS-10 Audit Reconciliation and Certification Readiness

### Added
- Build 19 audit-reconciliation record.
- Certification-readiness record.
- Build 19 staging checklist and validation report.

### Reconciled
- Continued VS-10 without creating or starting VS-11.
- Preserved protected systems, settings schema 1, Customizer authority, platform asset separation, and all earlier Visual System coverage.
- Kept stable-baseline promotion blocked until live staging evidence and user approval are complete.

## 1.8.6.6 - Build 18 - VS-10 Token Usage, Component Mapping, and Visual QA Lock

### Added
- Mandatory design-token policy.
- Semantic token mapping for VS-2 through VS-8.
- Integration alias mapping requirements.
- Token exception register.
- Visual QA lock and Build 18 staging checklist.
- Hard-coded visual-value audit inventory.

### Preserved
- Complete Build 17 runtime, presentation, and VS-9 release governance.
- Protected systems, settings schema version 1, Customizer authority, and platform asset separation.

### Status
- VS-10 governance implemented. Explicit packaging approval received. Token-audit reconciliation and staging certification remain required before promotion.

## 1.8.6.5 - Build 17 - VS-9 Visual Certification and Release Governance

### Added
- VS-9 visual certification matrix for VS-2 through VS-8.
- Light/dark and desktop/tablet/mobile evidence requirements.
- Keyboard, contrast, responsive, reduced-motion, and regression certification gates.
- Release governance with HOLD, ready-for-approval, approved-for-packaging, and promoted states.
- Build 17 staging validation checklist.

### Preserved
- All Build 16 runtime and presentation behavior.
- Settings schema version 1.
- Protected save engine and active asset loader.
- Customizer authority and platform asset separation.

### Status
- Governance implemented. Explicit packaging approval received. Staging visual certification remains required before promotion.


## 1.8.6.4 - Build 16 - VS-8 Extended Page-System Integration
- Applied shared components to support, legal, recipe, alias profile, business profile, gallery, poll and Community Experience page systems.
- Added shared empty, loading, error, restricted and private page states.
- Added only narrowly scoped page structures while extending the existing token and component inventory.
- Preserved VS-2 through VS-7, protected systems, schema version 1, Customizer authority and platform separation.

## 1.8.6.3 - Build 15 - VS-7 WooCommerce and Marketplace Integration
- Applied the shared system to products, archives, galleries, ratings, prices, stock, variations, cart, checkout, coupons, taxes, shipping, payments, accounts, orders, refunds, downloads, addresses and notices.
- Added marketplace vendor cards, shop grids, storefront headers, policies, ratings, enquiry and support surfaces, including approved WCFM-compatible presentation mappings.
- Added currency, points-balance and payment-badge presentation while preserving commerce plugin ownership of data and workflows.
- Preserved VS-2 through VS-6, protected systems, schema version 1, Customizer authority and platform asset separation.

## 1.8.6.2 - Build 14 - VS-6 WordPress and Community Integration
- Applied VS-2 through VS-5 components across WordPress posts, pages, archives, comments, search, forms, navigation, blocks, and system states.
- Applied the system to BuddyPress members, groups, profiles, headers, activity, gallery, polls, privacy, frontpages, notifications, messaging, forms, and directory surfaces.
- Applied the system to bbPress forums, topics, replies, notices, profiles, forms, pagination, and responsive layouts.
- Preserved native markup, hooks, permissions, extension points, semantics, data ownership, protected systems, schema version 1, and platform asset separation.

## 1.8.6.1 - Build 13 - VS-5 Cards, Lists, Tables, and Data Displays
- Added complete shared card variants, lists, responsive tables, statistics, progress indicators, chart surfaces, calendars, avatar groups, and steppers.
- Added loading, empty, error, selected, unread, sorting, filtering, row-action, pagination-ready, responsive-overflow, hover, and focus states.
- Preserved approved Build 12 VS-4 plus VS-2 and VS-3 coverage, protected systems, schema version 1, Customizer authority, and platform asset separation.

## 1.8.6.0 - Build 12 - VS-4 Navigation and Application Shells
- Expanded the shared navigation foundation across horizontal, vertical, nested, scrolling, current and active states.
- Added tabs, breadcrumbs, pagination, dropdowns, search bars, account menus and utility controls.
- Added left, right, mobile and responsive menu surfaces with pinned, collapsed, open and scrolling states.
- Added a responsive application shell with header, sidebar, main and footer regions.
- Preserved Build 11 VS-2 and VS-3 coverage, protected systems, schema version 1 and Customizer authority.
- Kept the advanced side-menu feature set and BuddyPress Builder outside this milestone.

## 1.8.5.9 - Build 11 - VS-2 and VS-3 Complete Coverage
- Preserved the complete Build 10 baseline and protected systems.
- Corrected VS-2 structural button leakage affecting the BuddyX header and hamburger controls.
- Added responsive header, dropdown and submenu sizing corrections.
- Completed VS-2 coverage across the default ZinCelestial theme surfaces.
- Added VS-3 alerts, notices, notifications, unread markers, toasts, snackbars, banners, badges, tags, chips, counters, status pills, tooltips and popovers.
- Added scoped WordPress, BuddyPress, bbPress and WooCommerce integration mappings.
- Preserved schema version 1, Customizer authority, existing records and plugin data ownership.
- Kept platform.css and platform.js outside the theme.

## 1.8.5.8 - Build 10 VS-2 Core Controls

- Implemented default-theme buttons, links, fields, selects, textareas, searches and uploads.
- Implemented toggles, checkboxes, radio controls, sliders, ranges and ratings.
- Added normal, hover, focus, active, selected, loading, disabled, success, warning and error states.
- Added shared control dimensions, icon sizing, focus rings, validation messages, responsive behavior and reduced-motion handling.
- Preserved schema version 1, protected save systems and platform asset separation.

## 1.8.5.7 - Build 9 correction pass

- Reconciled the approved Build 8 baseline identity across governance records.
- Added canonical semantic surface and motion tokens.
- Corrected remaining dark-mode surface fallbacks through the active Visual Foundation.
- Removed reserved platform.css and platform.js filenames from the main theme.
- Preserved approved profile behavior under profile-experience.css and profile-experience.js.
- Preserved settings schema version 1 and protected save systems.
- Kept VS-2 unstarted as the next milestone.

## v1.8.5.6 - Build 8 Community Layout Visual Corrections

### Fixed
- Removed forced empty height behavior from Community Layout regions and command-center containers.
- Corrected sticky sidebar offsets so sticky regions clear the WordPress administration bar and theme header.
- Improved Member Groups title and metadata spacing.
- Added compact responsive Member Connections and member/group card grids.
- Rebalanced wide widget cards across one, two, and three-column layouts.
- Added safe duplicate language-selector suppression inside the Community Layout shell.
- Added responsive overflow and narrow-column safeguards.

### Preserved
- Settings schema version 1.
- Protected save engine and active asset loader.
- Customizer ownership, BuddyPress permissions, marketplace adapters, and WooCommerce data ownership.
- Approved light and dark ZinCelestial Neon visual references.

# Changelog

## v1.8.5.5 - BuddyPress 12+ Directory URL Compatibility

### Fixed
- Replaced the deprecated BuddyPress groups-directory permalink call with `bp_get_groups_directory_url()` when available.
- Retained a guarded legacy fallback for BuddyPress versions older than 12.0.

### Preserved
- Theme Identity and Customizer Foundation implementation from v1.8.5.4.
- Protected save engine, schema version 1, active asset loader, styling, and existing records.


## v1.8.5.4 - Theme Identity and Customizer Foundation

### Added
- Locked ZinCelestial as the public theme identity while retaining ZinCelestial-BuddyX as the technical BuddyX child-theme project.
- Added the ZinCelestial Community Experience Customizer panel.
- Added schema-1 option, defaults, sanitizer, dependency, and preview-transport registries.
- Added design token, skin, component, and CSS-property registries.
- Added ZinCelestial Default plus five skin variations.
- Added default dark mode, matching light mode, device preference, and visitor-toggle settings.
- Added basic Theme Appearance, Top Bar, Header, Accessibility, and Diagnostics controls.
- Added shared frontend mode classes and reduced-motion safeguards.

### Preserved
- Protected save engine, last-known-good recovery, settings schema 1, existing administration interface, BuddyPress ownership, current JavaScript, and business records.
- Active inc/assets.php loader; Services/AssetManager.php remains inactive.


## v1.8.5.3

### Added
- Isolated Visual Foundation tokens, components, accessibility utilities, and responsive utilities.

### Changed
- Enqueued the Visual Foundation after the existing header navigation stylesheet.
- Applied the approved profile-header dependency correction to `zcbx-header`.

### Documentation correction
- Replaced the abbreviated roadmap with the complete ZinCelestial-BuddyX roadmap, including VS-1 through VS-10, Stages 1 through 29, deferred work, validation gates, and the release principle.

### Preserved
- Approved v1.8.5 runtime, settings schema 1, Customizer ownership, save engine, JavaScript, and business records.

## v1.8.5

### Added
- Passive Community Experience Platform scaffolding.
- Customizer ownership registry definitions.
- Disabled reader, migrator, snapshot, and navigation inventory service shells.
- Passive admin section definitions and read-only diagnostics status.
- Community Experience, ownership, migration, and staging documentation.

### Changed
- Registered the passive scaffold through the existing autoloaded bootstrap.
- Updated release records for v1.8.5.

### Preserved
- Customizer controls and values remain active and authoritative.
- Frontend CSS, JavaScript, runtime ownership, settings schema 1, and business records remain unchanged.
- Protected save engine remains byte-for-byte unchanged.
- No database migration and no automatic writes.


## v1.8.5.5 Complete Replacement Package
- Corrected the installable internal theme folder to `zincelestial-buddyx`.
- Reassembled the complete production asset and PHP tree.
- Excluded obsolete standalone profile hotfix, duplicate loader snippet, and patch-note artifact.
- Preserved schema version 1, the protected save engine, Customizer ownership, and existing runtime behavior.


## v1.8.5.5 Customizer Fix
- Fixed the Customizer preview JavaScript error caused by calling the unavailable `api.previewer.refresh()` method.
- Preserved Customizer transport registration, schema version 1, production assets, styling, and the protected save engine.

### Unreleased - Community Member and Group Layout
- Rebuilt Batches 0 through 3 from the recorded source manifest and retained checksum-matched files.
- Added Batch 4 gated static three-column member and group shell.
- Added empty-region collapse, responsive stacking, and sensitive-screen exclusions.
- Frontend remains disabled by default; no widgets are seeded automatically.

#### Batch 5
- Added opt-in Customizer controls for member and group three-column layouts.
- Added independent member and group layout modes.
- Added validated left and right width choices and responsive stack-point choices.
- Preserved the existing save engine and kept all new settings inside the existing schema-version-1 settings option.

#### Batch 6
- Added allowlisted column and widget spacing controls.
- Added optional desktop sticky sidebars and sticky offset controls.
- Added optional internal sidebar scrolling with bounded viewport height.
- Added independent mobile placement rules for left and right sidebars: before, after, or hidden.

#### Batch 7
- Added side-level audience rules for everyone, logged-in visitors, or logged-out visitors.
- Added member-profile scope rules for all profiles, own profile, or other profiles.
- Added group scope rules for all visitors, group members, or non-members.
- Added independent enable controls for all six sidebar regions.
- Visibility evaluation is read-only and does not seed or move widgets.

## Build 7 Corrected Full - WooCommerce and Marketplace Compatibility

- Merged a read-only WooCommerce compatibility matrix and state resolver into the complete v1.8.5.5 Community Layout Settings Correction baseline.
- Added named detection adapters for Dokan, WCFM Marketplace, WC Vendors, MultiVendorX, and YITH WooCommerce Multi Vendor.
- Added report-only detection for multiple active marketplace engines.
- Added resolver tests and a Build 7 staging validation checklist.
- Preserved the Community Experience Platform, Customizer ownership, Community Layout controls, active asset loader, settings schema version 1, and protected save engine.
- Added no product, order, checkout, vendor, commission, payout, refund, or marketplace-settings writes.
- Rejected the earlier incomplete Build 7 archive as a release baseline.

### Packaging validation

- User approved Option 1 packaging with completed structural PHP validation because PHP CLI was unavailable in the execution environment.
- Native `php -l` remains a WordPress staging verification item and is not represented as completed.
- Package status is staging candidate, not production release.
