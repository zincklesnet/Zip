# Build 29R.83: Stage 6 Edge-to-Edge Mapped Command Cover

- Version: 1.9.6.3
- Baseline: `ZinCelestial-BuddyX-v1.9.6.2-Build-29R.82-Stage-6-Dedicated-Command-Header-Foundation-FULL.zip`
- Package: `ZinCelestial-BuddyX-v1.9.6.3-Build-29R.83-Stage-6-Edge-to-Edge-Mapped-Command-Cover-FULL.zip`
- Member and Group Command Profile Covers span side to side with no horizontal cover padding.
- Cover backgrounds remain mapped to existing BuddyPress profile/group cover settings.
- Dedicated Command header gap is exactly five pixels.
- Command pages remain permanently boxed.
- Stage 6 remains active.
- Stage 7 is not started.
- Settings schema remains Version 1.
- Validation remains request-only.
