# Build 29R.82: Stage 6 Dedicated Command Header Foundation

- Version: 1.9.6.2
- Baseline: `ZinCelestial-BuddyX-v1.9.6.1-Build-29R.81-Stage-6-Permanent-Boxed-Command-Layout-FULL.zip`
- Package: `ZinCelestial-BuddyX-v1.9.6.2-Build-29R.82-Stage-6-Dedicated-Command-Header-Foundation-FULL.zip`
- Dedicated Command header shared by Member and Group pages.
- Three independent sections and menu locations: Left, Center Main Menu, Right.
- Retina custom-logo and site-icon monogram placements.
- No reuse of existing site or BuddyPress links.
- Command Profile Header begins five pixels below the new header.
- Command pages remain permanently boxed.
- Stage 6 remains active.
- Stage 7 is not started.
- Settings schema remains Version 1.
- Validation remains request-only.
