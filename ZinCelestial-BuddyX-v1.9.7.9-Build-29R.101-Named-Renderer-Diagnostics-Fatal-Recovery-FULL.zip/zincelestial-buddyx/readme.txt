# Build 29R.91 Stage 7 Hover Popups, Scroll, Trigger, and Close Controls

- Version: 1.9.7.6
- Build: 29R.91
- Package: `ZinCelestial-BuddyX-v1.9.7.6-Build-29R.91-Stage-7-Hover-Popups-Scroll-Trigger-Close-Controls-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.7.5-Build-29R.90-Stage-7-Menu-Item-Hover-Open-Control-Cleanup-FULL.zip`
- Adds popup cards, page-scroll control, trigger presets/offset, and adaptive close sizing.

# Build 29R.90 Stage 7 Menu Item Hover and Open-Control Cleanup

- Version: 1.9.7.5
- Build: 29R.90
- Package: `ZinCelestial-BuddyX-v1.9.7.5-Build-29R.90-Stage-7-Menu-Item-Hover-Open-Control-Cleanup-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.7.4-Build-29R.89-Stage-7-Side-Menu-Administration-Style-Presets-FULL.zip`
- Adds Left/Right hover styling controls.
- Hides the trigger and resize handle while open when enabled.

# Build 29R.89 Stage 7 Side Menu Administration and Style Presets

- Version: 1.9.7.4
- Build: 29R.89
- Package: `ZinCelestial-BuddyX-v1.9.7.4-Build-29R.89-Stage-7-Side-Menu-Administration-Style-Presets-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.7.3-Build-29R.88-Stage-7-Side-Menu-Runtime-Isolation-Recovery-FULL.zip`
- Adds separate Left and Right settings and five presets.
- Preserves assigned menus and Build 29R.88 runtime recovery.

# Build 29R.88 Stage 7 Side Menu Runtime Isolation Recovery

- Version: 1.9.7.3
- Build: 29R.88
- Package: `ZinCelestial-BuddyX-v1.9.7.3-Build-29R.88-Stage-7-Side-Menu-Runtime-Isolation-Recovery-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.7.2-Build-29R.87-Stage-7-Resizable-Side-Menu-Panels-FULL.zip`
- Isolates frontend classes and restores both side triggers.
- Preserves assigned menus, accordion groups, and resizing.

# Build 29R.87 Stage 7 Resizable Side Menu Panels

- Version: 1.9.7.2
- Build: 29R.87
- Package: `ZinCelestial-BuddyX-v1.9.7.2-Build-29R.87-Stage-7-Resizable-Side-Menu-Panels-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.7.1-Build-29R.86-Stage-7-Accordion-Nested-Menu-Groups-FULL.zip`
- Adds independent pointer and keyboard resize controls.
- Preserves accordion groups and Stage 6 Command systems.

# Build 29R.86 Stage 7 Accordion and Nested Menu Groups

- Version: 1.9.7.1
- Build: 29R.86
- Package: `ZinCelestial-BuddyX-v1.9.7.1-Build-29R.86-Stage-7-Accordion-Nested-Menu-Groups-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.7.0-Build-29R.85-Stage-7-Advanced-Side-Menus-Foundation-FULL.zip`
- Adds accessible accordion controls to nested side-menu groups.
- Preserves the completed Stage 6 Command system.

# Build 29R.85 Stage 7 Advanced Side Menus Foundation

- Version: 1.9.7.0
- Build: 29R.85
- Package: `ZinCelestial-BuddyX-v1.9.7.0-Build-29R.85-Stage-7-Advanced-Side-Menus-Foundation-FULL.zip`
- Protected baseline: `ZinCelestial-BuddyX-v1.9.6.4-Build-29R.84-Stage-6-Final-Reconciliation-FULL.zip`
- Adds independent left and right WordPress side-menu locations.
- Preserves Stage 6 Command pages and boxed layout.

# Build 29R.84 Stage 6 Final Reconciliation

- Version: 1.9.6.4
- Build: 29R.84
- Package: `ZinCelestial-BuddyX-v1.9.6.4-Build-29R.84-Stage-6-Final-Reconciliation-FULL.zip`
- Protected baseline: `ZinCelestial-BuddyX-v1.9.6.3-Build-29R.83-Stage-6-Edge-to-Edge-Mapped-Command-Cover-FULL.zip`
- Reconciles Builds 29R.78 through 29R.83.
- Preserves the approved Command presentation unchanged.
- Stage 7 has not started.

# Build 29R.83 Stage 6 Edge-to-Edge Mapped Command Cover

- Version: 1.9.6.3
- Build: 29R.83
- Package: `ZinCelestial-BuddyX-v1.9.6.3-Build-29R.83-Stage-6-Edge-to-Edge-Mapped-Command-Cover-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.6.2-Build-29R.82-Stage-6-Dedicated-Command-Header-Foundation-FULL.zip`
- Full side-to-side Command Profile Cover inside the boxed page.
- Existing BuddyPress profile/group cover settings remain mapped.
- Dedicated header gap remains five pixels.

# Build 29R.82 Stage 6 Dedicated Command Header Foundation

- Version: 1.9.6.2
- Build: 29R.82
- Package: `ZinCelestial-BuddyX-v1.9.6.2-Build-29R.82-Stage-6-Dedicated-Command-Header-Foundation-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.6.1-Build-29R.81-Stage-6-Permanent-Boxed-Command-Layout-FULL.zip`
- New boxed Command header with Left, Center, and Right sections.
- New dedicated Command menus, retina logo, and monogram placement.
- Command Profile Header begins five pixels below.

# Build 29R.81 Stage 6 Permanent Boxed Command Layout

- Version: 1.9.6.1
- Build: 29R.81
- Package: `ZinCelestial-BuddyX-v1.9.6.1-Build-29R.81-Stage-6-Permanent-Boxed-Command-Layout-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.6.0-Build-29R.80-Stage-6-Native-BuddyPress-Menu-Removal-FULL.zip`
- Member and Group Command pages are permanently boxed.
- Full-width Command layouts are unsupported.

# Build 29R.80 Stage 6 Native BuddyPress Menu Removal

- Version: 1.9.6.0
- Build: 29R.80
- Package: `ZinCelestial-BuddyX-v1.9.6.0-Build-29R.80-Stage-6-Native-BuddyPress-Menu-Removal-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.5.9-Build-29R.79-Stage-6-Native-Widget-Area-Removal-FULL.zip`
- Removes native BuddyPress menus only from owned Command front pages.
- Preserves Command Header shortcuts and Command widget regions.

# Build 29R.79 Stage 6 Native Widget Area Removal

- Version: 1.9.5.9
- Build: 29R.79
- Package: `ZinCelestial-BuddyX-v1.9.5.9-Build-29R.79-Stage-6-Native-Widget-Area-Removal-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.5.8-Build-29R.78-Stage-6-Command-Frontpage-Ownership-Foundation-FULL.zip`
- Removes residual non-Command widget areas on owned member/group front pages.
- Preserves Command Primary and Secondary regions and saved assignments.

# Build 29R.78 Stage 6 Command Front-Page Ownership Foundation

- Version: 1.9.5.8
- Build: 29R.78
- Package: `ZinCelestial-BuddyX-v1.9.5.8-Build-29R.78-Stage-6-Command-Frontpage-Ownership-Foundation-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.5.6-Build-29R.76-Stage-6-Command-Hub-Widget-Region-Recovery-FULL.zip`
- Command Profile Header owns member/group front pages.
- Native BuddyPress header and native front-page widget output are suppressed only on those front pages.
- Stage 6 remains active.
- Settings schema: Version 1

# Build 29R.76 Stage 6 Command Hub Widget Region Recovery

- Version: 1.9.5.6
- Build: 29R.76
- Package: `ZinCelestial-BuddyX-v1.9.5.6-Build-29R.76-Stage-6-Command-Hub-Widget-Region-Recovery-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.5.5-Build-29R.75-Stage-6-Native-Header-Region-Recovery-FULL.zip`
- Restores Member and Group Primary and Secondary widget-region enablement.
- Stage 6 remains active.
- Settings schema: Version 1

# Build 29R.75 Stage 6 Native Header and Region Recovery

- Version: 1.9.5.5
- Build: 29R.75
- Package: `ZinCelestial-BuddyX-v1.9.5.5-Build-29R.75-Stage-6-Native-Header-Region-Recovery-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.5.2-Build-29R.72-Stage-6-Responsive-Accessibility-Coverage-FULL.zip`
- Builds 29R.73 and 29R.74 are superseded as completion candidates.
- Stage 6 remains active.
- Settings schema: Version 1

# Build 29R.72 Stage 6 Responsive and Accessibility Coverage

- Version: 1.9.5.2
- Build: 29R.72
- Package: `ZinCelestial-BuddyX-v1.9.5.2-Build-29R.72-Stage-6-Responsive-Accessibility-Coverage-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.5.1-Build-29R.71-Roadmap-Dark-Mode-Widget-Platform-Reconciliation-FULL.zip`
- Settings schema: Version 1
- Stage 6 remains active and incomplete.

# Build 29R.71 Roadmap Dark Mode and Widget Platform Reconciliation

- Version: 1.9.5.1
- Build: 29R.71
- Package: `ZinCelestial-BuddyX-v1.9.5.1-Build-29R.71-Roadmap-Dark-Mode-Widget-Platform-Reconciliation-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.5.0-Build-29R.70-Stage-6-Command-Hub-Widget-Expansion-Foundation-FULL.zip`
- Stage 6 remains active and incomplete.
- Stage 32 and Stage 33 are future roadmap milestones.
- Existing roadmap entries are preserved.
- Settings schema remains Version 1.
- No new runtime or styling implementation is included.

# Build 29R.70 Stage 6 Command Hub Widget Expansion Foundation

- Version: 1.9.5.0
- Build: 29R.70
- Package: `ZinCelestial-BuddyX-v1.9.5.0-Build-29R.70-Stage-6-Command-Hub-Widget-Expansion-Foundation-FULL.zip`
- Baseline: complete Build 29R.69 package
- Settings schema: 1, unchanged

## Scope

- Adds real-data Member Summary, Member Activity, Member Connections, Member Groups, Group Summary, and Community Status widgets.
- Widgets are designed for the existing Member and Group Command Hub primary and secondary regions.
- Preserves native BuddyPress permissions, URLs, data, and fallback behavior.
- Reuses existing ZinCelestial surfaces and design tokens.
- Stage 6 remains active and incomplete.

No live, installation, visual, or accessibility validation was performed.
