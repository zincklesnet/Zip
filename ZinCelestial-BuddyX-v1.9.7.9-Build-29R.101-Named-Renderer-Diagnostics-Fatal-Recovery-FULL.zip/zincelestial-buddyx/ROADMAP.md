# Current recovery status - Build 29R.101

- Version: 1.9.7.9
- Build: 29R.101
- Package: `ZinCelestial-BuddyX-v1.9.7.9-Build-29R.101-Named-Renderer-Diagnostics-Fatal-Recovery-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.7.8-Build-29R.100-Community-Experience-Named-Panel-Renderer-Registry-FULL.zip`
- Removed the stray `break` statement from the dedicated Diagnostics renderer that caused a PHP fatal error during theme loading.
- Preserved all 18 named renderers and the direct renderer registry.
- No scope expansion. Advanced Side Menus remain separate.
- Main settings schema remains Version 1.
- Roadmap entries through Stage 33 remain preserved.

# Current Community Experience architecture status - Build 29R.100

- Version: 1.9.7.8
- Build: 29R.100
- Package: `ZinCelestial-BuddyX-v1.9.7.8-Build-29R.100-Community-Experience-Named-Panel-Renderer-Registry-FULL.zip`
- Protected baseline: `ZinCelestial-BuddyX-v1.9.7.7-Build-29R.99-Community-Experience-Direct-Panel-Router-Foundation-FULL.zip`
- Builds 29R.92 through 29R.98 remain rejected.
- Converted all 18 Community Experience routes from inline switch branches into dedicated named panel renderer functions.
- Added a single renderer registry mapping every registered panel key to its renderer function.
- The platform shell validates the route, resolves one callable, and executes only that renderer.
- Dashboard exists only in its dedicated renderer.
- Preserved Build 29R.91 styling and Build 29R.99 direct-route behavior.
- Advanced Side Menus remain separate from the Community Experience Platform.
- Stage 7 remains active and incomplete.
- Main settings schema remains Version 1.
- Every roadmap entry through Stage 33 remains preserved.
- Validation remains request-only.

# Current Community Experience architecture status - Build 29R.99

- Version: 1.9.7.7
- Build: 29R.99
- Package: `ZinCelestial-BuddyX-v1.9.7.7-Build-29R.99-Community-Experience-Direct-Panel-Router-Foundation-FULL.zip`
- Protected baseline: `ZinCelestial-BuddyX-v1.9.7.6-Build-29R.91-Stage-7-Hover-Popups-Scroll-Trigger-Close-Controls-FULL.zip`
- Builds 29R.92 through 29R.98 remain rejected and are not used as baselines.
- Replaced shared all-panel output buffering and HTML extraction with direct server-side selection through the registered active panel key.
- Only the selected panel renderer branch executes during a request.
- Dashboard executes only for the Dashboard route or an invalid unregistered route normalized before rendering.
- Preserved Build 29R.91 administration styling, responsive field rows, Libraries, diagnostics, tools, saved settings, and Stage 7 Advanced Side Menu runtime.
- Advanced Side Menus remain on their separate Appearance administration page and are not integrated into the Community Experience Platform in this foundation build.
- Stage 7 remains active and incomplete.
- Main settings schema remains Version 1.
- Every roadmap entry through Stage 33 remains preserved.
- Validation remains request-only.

# Current Stage 7 status - Build 29R.91

- Version: 1.9.7.6
- Build: 29R.91
- Package: `ZinCelestial-BuddyX-v1.9.7.6-Build-29R.91-Stage-7-Hover-Popups-Scroll-Trigger-Close-Controls-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.7.5-Build-29R.90-Stage-7-Menu-Item-Hover-Open-Control-Cleanup-FULL.zip`
- Added configurable accessible hover/focus popup cards for menu items with automatic, top, right, bottom, or left placement.
- Added Minimal Tooltip, Rounded Card, Glass, Neon, and Solid popup styles.
- Added popup font size, width, padding, radius, opacity, blur, delay, text, background, and border controls separately for Left and Right menus.
- Added viewport collision containment and automatic outward placement based on panel side.
- Added Allow page scrolling while menu is open, enabled by default, while preserving an optional scroll-lock mode.
- Added configurable top trigger offset to place the open trigger closer to the top.
- Added Rounded Square, Square, Pill, Glass, and Minimal trigger presets.
- Added Fixed, Adaptive, and Compact close-control sizing; Adaptive scales between 44 and 64 pixels with panel width.
- Preserved the Build 29R.90 option that hides the matching trigger and resize handle while expanded.
- Stage 7 remains active and incomplete.
- The completed Stage 6 Command system and permanently boxed Command pages remain protected.
- Every roadmap entry through Stage 33 remains preserved.
- Main settings schema remains Version 1; side-menu administration remains isolated.
- Validation remains request-only.

# Current Stage 7 status - Build 29R.90

- Version: 1.9.7.5
- Build: 29R.90
- Package: `ZinCelestial-BuddyX-v1.9.7.5-Build-29R.90-Stage-7-Menu-Item-Hover-Open-Control-Cleanup-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.7.4-Build-29R.89-Stage-7-Side-Menu-Administration-Style-Presets-FULL.zip`
- Added separate Left and Right menu-item hover styling controls in Appearance > Advanced Side Menus.
- Added item hover effects: None, Color Fill, Lift, Slide, Underline, and Glow.
- Added hover background, text, icon, border, radius, transition-duration, and optional glow controls.
- Hover styles apply consistently to every menu link on the configured side while preserving keyboard focus parity.
- Added Hide trigger and resize controls while open as a separate setting for each side, enabled by default.
- When a panel is open, its edge trigger and vertical resize handle are hidden; the panel header close button remains available.
- Build 29R.89 administration, five presets, independent Left/Right controls, and Build 29R.88 runtime isolation remain preserved.
- Stage 7 remains active and incomplete.
- The completed Stage 6 Command system and permanently boxed Command pages remain protected.
- Every roadmap entry through Stage 33 remains preserved.
- Main settings schema remains Version 1; side-menu administration remains isolated.
- Validation remains request-only.

# Current Stage 7 status - Build 29R.89

- Version: 1.9.7.4
- Build: 29R.89
- Package: `ZinCelestial-BuddyX-v1.9.7.4-Build-29R.89-Stage-7-Side-Menu-Administration-Style-Presets-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.7.3-Build-29R.88-Stage-7-Side-Menu-Runtime-Isolation-Recovery-FULL.zip`
- Added a dedicated Advanced Side Menus administration page under Appearance > Advanced Side Menus.
- Added separate Left and Right settings with independent enablement, style, dimensions, state, display mode, trigger, color, surface, header, footer, shortcode, separator, close behavior, state memory, and device controls.
- Added five style presets: Expanded Panel, Compact Icon Rail, Expandable Rail, Floating Utility Dock, and Command Glass Panel.
- Added independent header titles and sanitized shortcode inputs plus independent footer text and sanitized shortcode inputs.
- Added separate trigger positions and icon choices for each side.
- Added overlay, push-content, and floating display modes.
- Existing WordPress menu assignments remain managed in Appearance > Menus.
- Build 29R.88 runtime isolation, accordion groups, nested hierarchy, resizing, focus handling, and responsive safeguards remain preserved.
- Stage 7 remains active and incomplete; advanced context/audience rules, scheduling, menu profiles, import/export, and preset duplication remain later Stage 7 work.
- The completed Stage 6 Command system and permanently boxed Command pages remain protected.
- Every roadmap entry through Stage 33 remains preserved.
- Main settings schema remains Version 1; side-menu administration uses its own isolated option.
- Validation remains request-only.

# Current Stage 7 recovery status - Build 29R.88

- Version: 1.9.7.3
- Build: 29R.88
- Package: `ZinCelestial-BuddyX-v1.9.7.3-Build-29R.88-Stage-7-Side-Menu-Runtime-Isolation-Recovery-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.7.2-Build-29R.87-Stage-7-Resizable-Side-Menu-Panels-FULL.zip`
- Isolated the Stage 7 frontend runtime from older generic side-menu class names.
- Replaced runtime selectors with dedicated Advanced Side Panel and Advanced Side Trigger namespaces.
- Added `wp_footer` fallback rendering with duplicate-output protection when `wp_body_open` is absent or inconsistent.
- Left and Right triggers are explicitly fixed, visible, unclipped, and independently positioned on their matching viewport edges.
- Closed panels are fully hidden and non-interactive; open panels restore visibility and interaction.
- Existing WordPress menu assignments remain unchanged.
- Accordion groups, nested hierarchy, current-item states, internal scrolling, keyboard behavior, independent saved widths, reduced motion, and forced colors remain preserved.
- Stage 7 remains active and incomplete.
- The completed Stage 6 Command system and permanently boxed Command pages remain protected.
- Every roadmap entry through Stage 33 remains preserved.
- Settings schema remains Version 1.
- Validation remains request-only.

# Current Stage 7 status - Build 29R.87

- Version: 1.9.7.2
- Build: 29R.87
- Package: `ZinCelestial-BuddyX-v1.9.7.2-Build-29R.87-Stage-7-Resizable-Side-Menu-Panels-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.7.1-Build-29R.86-Stage-7-Accordion-Nested-Menu-Groups-FULL.zip`
- Added independent desktop resizing for the Left and Right Advanced Side Menu panels.
- Panel widths are constrained from 240 to 520 CSS pixels.
- Each panel remembers its own browser-local width without changing the schema-version-1 settings store.
- Resize handles support pointer dragging, Left/Right Arrow adjustment, Home minimum, and End maximum.
- Mobile panels retain the protected fixed responsive width and hide resize handles.
- Accordion groups, focus containment, Escape closing, internal scrolling, current-item highlighting, reduced-motion, and forced-colors safeguards remain preserved.
- Stage 7 remains active and incomplete.
- The completed Stage 6 Command system and permanently boxed Command pages remain protected.
- Every roadmap entry through Stage 33 remains preserved.
- Validation remains request-only.

# Current Stage 7 status - Build 29R.86

- Version: 1.9.7.1
- Build: 29R.86
- Package: `ZinCelestial-BuddyX-v1.9.7.1-Build-29R.86-Stage-7-Accordion-Nested-Menu-Groups-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.7.0-Build-29R.85-Stage-7-Advanced-Side-Menus-Foundation-FULL.zip`
- Added accessible accordion controls for WordPress menu items with child menus in both Advanced Side Menu panels.
- Nested groups are collapsed by default, while current-menu ancestors are expanded automatically.
- Each accordion control uses an explicit controlled-submenu relationship and expanded state.
- Accordion controls preserve parent menu links instead of replacing them.
- Keyboard focus containment, Escape closing, internal scrolling, responsive behavior, reduced motion, and forced-colors safeguards remain preserved.
- Stage 7 remains active and incomplete.
- The completed Stage 6 Command system and permanent boxed Command-page invariant remain protected.
- Every roadmap entry through Stage 33 remains preserved.
- Settings schema remains Version 1.
- Validation remains request-only.

# Current Stage 7 status - Build 29R.85

- Version: 1.9.7.0
- Build: 29R.85
- Package: `ZinCelestial-BuddyX-v1.9.7.0-Build-29R.85-Stage-7-Advanced-Side-Menus-Foundation-FULL.zip`
- Protected baseline: `ZinCelestial-BuddyX-v1.9.6.4-Build-29R.84-Stage-6-Final-Reconciliation-FULL.zip`
- Stage 7 Advanced Left and Right Menu System has started.
- Added independent native WordPress menu locations for the left and right side panels.
- Panels render only when their menu location has an assigned menu.
- Added off-canvas open/close controls, internal scrolling, nested menu hierarchy, smart current-item highlighting, Escape close, focus containment, responsive mobile behavior, reduced-motion support, and forced-colors safeguards.
- Added dedicated header, content, and footer regions in each panel as the Stage 7 structural foundation.
- Stage 7 remains active and incomplete; profiles, presets, resizing controls, context rules, scheduling, visual controls, and expanded device modes remain future Stage 7 work.
- The completed Stage 6 Command system and permanent boxed Command-page invariant remain protected.
- All roadmap entries through Stage 33 remain preserved.
- Settings schema remains Version 1.
- Validation remains request-only.

# Current Stage 6 final reconciliation - Build 29R.84

- Version: 1.9.6.4
- Build: 29R.84
- Package: `ZinCelestial-BuddyX-v1.9.6.4-Build-29R.84-Stage-6-Final-Reconciliation-FULL.zip`
- Protected baseline: `ZinCelestial-BuddyX-v1.9.6.3-Build-29R.83-Stage-6-Edge-to-Edge-Mapped-Command-Cover-FULL.zip`
- Stage 6 Member and Group Command front-page ownership work is complete.
- Build 29R.83 is the approved protected visual and runtime baseline for the reconciled package.
- Reconciled Builds 29R.78 through 29R.83 without changing the approved frontend presentation.
- Member and Group Command pages remain permanently boxed; full-width Command layouts are unsupported.
- Preserved the dedicated Left, Center Main Menu, and Right Command header locations, retina custom-logo placement, site-icon monogram placement, exact five-pixel header gap, edge-to-edge cover, and BuddyPress cover/background mapping.
- Preserved Command Primary and Secondary regions, saved widget assignments, BuddyPress data, permissions, URLs, actions, and non-Command screens.
- Native BuddyPress headers, menus, and non-Command widget areas remain removed only from owned Command front pages.
- Stage 7 has not started.
- All roadmap entries through Stage 33 remain preserved.
- Settings schema remains Version 1.
- Standard WordPress/BuddyX Customizer remains preserved.
- Validation remains request-only.

# Current Stage 6 status - Build 29R.83

- Version: 1.9.6.3
- Build: 29R.83
- Package: `ZinCelestial-BuddyX-v1.9.6.3-Build-29R.83-Stage-6-Edge-to-Edge-Mapped-Command-Cover-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.6.2-Build-29R.82-Stage-6-Dedicated-Command-Header-Foundation-FULL.zip`
- Member and Group Command Profile Covers now span fully side to side inside the permanent boxed Command page with no horizontal cover padding.
- Primary and Secondary widget regions retain responsive inner gutters.
- Existing Command Hub Appearance mapping continues to use the authoritative BuddyPress profile/group cover and background settings, including desktop/mobile images, position, repeat, fit, overlay color, and overlay opacity.
- The gap between the dedicated Command header and Command Profile Cover is fixed at five pixels.
- The three dedicated Command menu locations remain independent and do not copy global menus.
- Stage 6 remains active.
- All roadmap entries through Stage 33 remain preserved.
- Settings schema remains Version 1.
- Stage 7 has not started.
- Validation remains request-only.

# Current Stage 6 status - Build 29R.82

- Version: 1.9.6.2
- Build: 29R.82
- Package: `ZinCelestial-BuddyX-v1.9.6.2-Build-29R.82-Stage-6-Dedicated-Command-Header-Foundation-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.6.1-Build-29R.81-Stage-6-Permanent-Boxed-Command-Layout-FULL.zip`
- Added one dedicated boxed Command site header shared by Member and Group Command pages.
- Removed the ordinary global site header and community bar from owned Command pages.
- Added independent Left, Center Main Menu, and Right Command header sections.
- Added three dedicated WordPress menu locations without copying existing global or BuddyPress links.
- Left section contains retina-capable custom-logo placement; Right section contains site-icon monogram placement.
- Command Profile Headers begin five pixels below the dedicated Command header.
- Member and Group Command pages retain the permanent boxed-layout invariant.
- Build 29R.80 native BuddyPress menu removal and Build 29R.79 native widget-area removal remain preserved.
- Stage 6 remains active.
- All roadmap entries through Stage 33 remain preserved.
- Settings schema remains Version 1.
- Stage 7 has not started.
- Validation remains request-only.

# Current Stage 6 status - Build 29R.81

- Version: 1.9.6.1
- Build: 29R.81
- Package: `ZinCelestial-BuddyX-v1.9.6.1-Build-29R.81-Stage-6-Permanent-Boxed-Command-Layout-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.6.0-Build-29R.80-Stage-6-Native-BuddyPress-Menu-Removal-FULL.zip`
- Member and Group Command pages are permanently boxed.
- Full-width Command page presentation is unsupported and cannot be selected by layout settings.
- The boxed invariant applies to the Command Profile Header, Primary region, Secondary region, and Command front-page body at desktop, tablet, and mobile widths.
- Build 29R.80 native BuddyPress menu removal remains preserved.
- Stage 6 remains active.
- All roadmap entries through Stage 33 remain preserved.
- Settings schema remains Version 1.
- Stage 7 has not started.
- Validation remains request-only.

# Current Stage 6 status - Build 29R.80

- Version: 1.9.6.0
- Build: 29R.80
- Package: `ZinCelestial-BuddyX-v1.9.6.0-Build-29R.80-Stage-6-Native-BuddyPress-Menu-Removal-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.5.9-Build-29R.79-Stage-6-Native-Widget-Area-Removal-FULL.zip`
- Stage 6 remains active.
- Removed native BuddyPress member and group primary navigation menus from owned Command front pages.
- Preserved the Command Profile Header shortcut controls as the only front-page command navigation.
- Native BuddyPress navigation remains available on non-Command member and group component screens.
- Preserved Command Primary and Secondary widget regions, saved assignments, BuddyPress data, permissions, URLs, and actions.
- All roadmap entries through Stage 33 remain preserved.
- Settings schema remains Version 1.
- Stage 7 has not started.
- Validation remains request-only.

# Current Stage 6 status - Build 29R.79

- Version: 1.9.5.9
- Build: 29R.79
- Package: `ZinCelestial-BuddyX-v1.9.5.9-Build-29R.79-Stage-6-Native-Widget-Area-Removal-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.5.8-Build-29R.78-Stage-6-Command-Frontpage-Ownership-Foundation-FULL.zip`
- Stage 6 remains active.
- Removed residual native BuddyPress/BuddyX, bbPress, theme sidebar, and footer widget output from owned member and group front pages.
- Preserved only the context-correct ZinCelestial Command Primary and Secondary widget regions on owned front pages.
- Widget assignments are not deleted, moved, or changed; non-Command sidebars are filtered only during owned front-page requests.
- Other BuddyPress, bbPress, theme, and WordPress pages retain their normal widget areas.
- All roadmap entries through Stage 33 remain preserved.
- Settings schema remains Version 1.
- Stage 7 has not started.
- Validation remains request-only.

# Current Stage 6 status - Build 29R.78

- Version: 1.9.5.8
- Build: 29R.78
- Package: `ZinCelestial-BuddyX-v1.9.5.8-Build-29R.78-Stage-6-Command-Frontpage-Ownership-Foundation-FULL.zip`
- Protected baseline: `ZinCelestial-BuddyX-v1.9.5.6-Build-29R.76-Stage-6-Command-Hub-Widget-Region-Recovery-FULL.zip`
- Build 29R.77 is rejected because removing identity presentation from the Command Profile Header conflicts with approved ownership.
- Stage 6 remains active.
- Added Member and Group Command Front-Page Ownership Foundation.
- On member/group front pages only, the ZinCelestial Command Profile Header remains visible while native BuddyPress/BuddyX profile header output and native front-page body/widget output are suppressed.
- Other BuddyPress member and group component screens remain native.
- Primary and Secondary ZinCelestial Command Hub widget regions remain connected to saved WordPress widget assignments.
- BuddyPress data, permissions, URLs, actions, navigation, and extension points remain authoritative.
- All roadmap entries through Stage 33 remain preserved.
- Settings schema remains Version 1.
- Standard WordPress/BuddyX Customizer remains preserved.
- Stage 7 has not started.
- Validation remains request-only.

# Current Stage 6 recovery status - Build 29R.76

- Version: 1.9.5.6
- Build: 29R.76
- Package: `ZinCelestial-BuddyX-v1.9.5.6-Build-29R.76-Stage-6-Command-Hub-Widget-Region-Recovery-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.5.5-Build-29R.75-Stage-6-Native-Header-Region-Recovery-FULL.zip`
- Stage 6 remains active pending frontend confirmation and later final reconciliation.
- Corrected the Command Hub widget-region settings lookup to use the theme's authoritative `zcbx_settings()` accessor.
- Restored enablement of Member Primary, Member Secondary, Group Primary, and Group Secondary regions when the saved schema-version-1 option is enabled.
- Preserved Build 29R.75 native after-header placement, independent asset loading, configured widget assignments, and single native BuddyPress profile/group header ownership.
- Context-incompatible widgets may intentionally return no content, but compatible assigned widgets and region wrappers can now render.
- All roadmap entries through Stage 33 remain preserved.
- Settings schema remains Version 1.
- Standard WordPress/BuddyX Customizer remains preserved.
- Stage 7 has not started.
- Validation remains request-only.

# Current Stage 6 recovery status - Build 29R.75

- Version: 1.9.5.5
- Build: 29R.75
- Package: `ZinCelestial-BuddyX-v1.9.5.5-Build-29R.75-Stage-6-Native-Header-Region-Recovery-FULL.zip`
- Protected recovery baseline: `ZinCelestial-BuddyX-v1.9.5.2-Build-29R.72-Stage-6-Responsive-Accessibility-Coverage-FULL.zip`
- Builds 29R.73 and 29R.74 are superseded as Stage 6 completion candidates.
- Stage 6 remains active pending corrected frontend confirmation and later final reconciliation.
- Member and Group Command Hubs now render through native BuddyPress after-header hooks.
- Command Hub assets enqueue on supported BuddyPress member/group pages without front-page detection during enqueue.
- Command Hub styles have no conditional custom-style dependency and use file modification time for cache invalidation.
- Primary and Secondary regions remain attached directly after their respective Command Hub through existing custom actions.
- All widget assignments, BuddyPress permissions, URLs, data, navigation, and fallback behavior remain preserved.
- All roadmap entries through Stage 33 remain preserved.
- Settings schema remains Version 1.
- Standard WordPress/BuddyX Customizer remains preserved.
- Stage 7 has not started.
- Validation remains request-only.

# Current Stage 6 status - Build 29R.72

- Version: 1.9.5.2
- Build: 29R.72
- Package: `ZinCelestial-BuddyX-v1.9.5.2-Build-29R.72-Stage-6-Responsive-Accessibility-Coverage-FULL.zip`
- Protected baseline: `ZinCelestial-BuddyX-v1.9.5.1-Build-29R.71-Roadmap-Dark-Mode-Widget-Platform-Reconciliation-FULL.zip`
- Stage 6 remains active and incomplete.
- Added responsive and accessibility implementation coverage for Member Command Hub, Group Command Hub, Command Hub regions, and Command Hub widgets.
- Preserved all roadmap entries through Stage 33.
- Stages 32 and 33 remain future milestones and are not implemented by this build.
- Settings schema remains Version 1.
- Standard WordPress/BuddyX Customizer remains preserved.
- Validation remains request-only.

# Current roadmap status - Build 29R.71

- Version: 1.9.5.1
- Build: 29R.71
- Package: `ZinCelestial-BuddyX-v1.9.5.1-Build-29R.71-Roadmap-Dark-Mode-Widget-Platform-Reconciliation-FULL.zip`
- Protected baseline: `ZinCelestial-BuddyX-v1.9.5.0-Build-29R.70-Stage-6-Command-Hub-Widget-Expansion-Foundation-FULL.zip`
- Stage 6 remains active and incomplete.
- All existing roadmap entries through Stage 31 are preserved without removal, replacement, renaming, merging, or reordering.
- Stage 32 and Stage 33 are appended as future milestones.
- Settings schema remains Version 1.
- Standard WordPress and BuddyX Customizer remains preserved.
- This is a roadmap and governance reconciliation build only. No Stage 32 or Stage 33 runtime implementation is included.

# Current Stage 6 status - Build 29R.70

Stage 6 remains active and incomplete. Build 29R.70 establishes the Command Hub widget and component expansion foundation with real BuddyPress data in the existing member and group front-page regions. All roadmap entries through Stage 31 remain preserved. Responsive and accessibility coverage plus final Stage 6 reconciliation remain next.


# Current Stage 6 status - Build 29R.70

Stage 6 remains active and incomplete. Build 29R.70 establishes the Activity and Communication Experience foundation across native BuddyPress activity items, threaded comments and replies, group activity, notices, feedback, and privacy or visibility indicators. Existing roadmap entries through Stage 31 remain preserved. Widget and component expansion remains next.

# Current Stage 6 status - Build 29R.68

Stage 6 remains active and incomplete. Build 29R.68 establishes the Community Layout Framework foundation through native BuddyPress wrappers and existing ZinCelestial design tokens. Existing roadmap entries through Stage 31 remain preserved. Activity and communication presentation plus widget/component expansion remain next.

# Current Stage 6 status - Build 29R.67

Stage 6 remains active and incomplete. Build 29R.67 establishes the Command Hub appearance foundation by connecting the Member and Group Command Hubs to the existing schema-version-1 profile and group background and cover controls. Existing roadmap entries through Stage 31 remain preserved. The next Stage 6 work remains broader Community Layout Framework reconciliation, activity and communication presentation, and widget/component expansion.

# ZinCelestial-BuddyX Roadmap

## Current build

- Version: 1.9.5.0
- Build: 29R.70
- Package: `ZinCelestial-BuddyX-v1.9.5.0-Build-29R.70-Stage-6-Activity-Communication-Foundation-FULL.zip`
- Baseline: `ZinCelestial-BuddyX-v1.9.4.5-Build-29R.65-Stage-6-Group-Command-Hub-Foundation-FULL.zip`
- Stage 6 now includes Member and Group Command Hub foundations plus configurable front-page widget regions.

## Next official milestone

- Stage 6 Deferred Community Experience Features

## Current recovery status

- Current target: ZinCelestial-BuddyX v1.9.3.3 Build 29R.57 Member Directory Recovery.
- Protected recovery baseline: ZinCelestial-BuddyX-v1.9.3.1-Build-29R.55-Signature-Filter-Friendship-Controls-FULL.zip.
- Stage 4 Signature Icon Library: Completed across Builds 29R.23 through 29R.30.
- Next official milestone: Stage 5 Navigation Icon Controls.
- Standard WordPress/BuddyX Customizer: Preserved.
- Settings schema: Version 1, unchanged.
- Delivery rule: One complete WordPress-installable ZIP; no patch, hotfix, or corrected-file bundle.
- Validation rule: Perform validation only when explicitly requested.

## Current authoritative status

- Active working package: `ZinCelestial-BuddyX-v1.9.3.1-Build-29R.55-Signature-Filter-Friendship-Controls-FULL.zip`.
- Protected source baseline: `ZinCelestial-BuddyX-v1.8.7.6-Build-28-Stage-2-Certification-FULL`.
- Settings schema: Version 1.
- Uploaded-board components: externalized to `ZinCelestial-Skin-Component-Library-v1.0.0.zip`.
- ZinCelestial Community Experience Customizer: removed from active runtime and deferred indefinitely.
- Standard WordPress and BuddyX Customizer: preserved.
- ZinCelestial administration settings page, saved settings, and frontend runtime: preserved.
- Builds 29 through 33 from the retired schema-2 line remain rejected and are not source baselines.
- Validation remains request-only.

## Build 29R.16 canonical directory correction

- Removed duplicate experience panels and structurally normalized the Members title row.
- Stage 4 Signature Icon Library remains next.

## Build 29R.15 single-runtime correction

- Removed duplicate controls and corrected full member-entry targeting for Grid and Compact views.
- Stage 4 Signature Icon Library remains next.

## Build 29R.13 runtime correction

- Corrected live BuddyPress markup targeting and settings runtime behavior for the Member Directory Experience candidate.
- Stage 4 Signature Icon Library remains the next official roadmap milestone.

## Build 29R.12 visual candidate settings

- Added existing-admin-page settings for the Member Directory Experience candidate while retaining settings schema version 1.
- Stage 4 Signature Icon Library remains the next official roadmap milestone.

## Build 29R.11 visual candidate

- Added a testable Community Pizzazz candidate and structural Members sub-header correction.
- Stage 4 Signature Icon Library remains the next official roadmap milestone pending candidate testing.

## Build 29R.10 maintenance correction

- Corrected the remaining live Members sub-header span and avatar-before-GamiPress order.
- No roadmap scope expansion.

## Build 29R.9 maintenance correction

- Corrected member directory tab lines, sub-header alignment, GamiPress spacing, and avatar placement from uploaded screenshots.
- No roadmap scope expansion.

## Build 29R.8 maintenance correction

- Corrected the member-directory title surface and member-card structure shown in the uploaded screenshots.
- No roadmap scope expansion.

## Build 29R.7 maintenance correction

- Corrected the live desktop header and member-directory CSS defects shown in the uploaded screenshot.
- No roadmap scope expansion.

## Build 29R.6 maintenance correction

- Completed static CSS, darker-light palette, dark-mode surface, and contrast correction.
- No roadmap scope expansion.

## Build 29R.5 maintenance correction

- Removed duplicate desktop dropdown arrows, header-link underlines, and desktop display of mobile hamburger controls.
- No roadmap scope expansion.

## Build 29R.4 maintenance correction

- Corrected desktop header dropdown controls that extended below the menu row.
- No roadmap scope expansion.

## Current decision: Customizer deferred

- Do not restart the ZinCelestial Community Experience Customizer.
- Do not add live preview, Customizer ownership, Customizer migration, or Customizer control mapping work.
- Preserve historical Customizer records only as project history.
- Inactive Customizer ownership scaffold cleanup completed in Build 29R.3: `CommunitySettingsMigrator.php`, `CommunityMigrationSnapshot.php`, and `NavigationInventory.php` were removed.
- Do not delete existing `zcbx_settings` values.

## Next approved roadmap milestone

### Stage 4: Signature Icon Library

Stage 4 is next because Stages 1 through 3 are now deferred and the Signature Icon Library can remain independent of Customizer and navigation assignment.

Execution order:

1. Inactive Customizer ownership-scaffold cleanup completed in Build 29R.3.
2. Define the standalone Signature Icon Library data model and storage boundary.
3. Add reusable icon records with accessible titles and descriptions.
4. Add administrator icon creation, validation, sanitization, and duplicate protection.
5. Keep navigation assignment out of scope until Stage 4 is stable.
6. Preserve schema version 1 and the protected Build 28 baseline.

## Following milestone

### Stage 5: Navigation Icon Controls

Stage 5 remains planned after Stage 4. Navigation icon assignment must consume the certified Signature Icon Library rather than embedding another icon system directly into the theme.

# Authoritative Build 28 Status

- Theme Name: ZinCelestial-BuddyX
- Author: Zinckles
- Current version: 1.8.7.6
- Current build: Build 28
- Protected baseline: ZinCelestial-BuddyX-v1.8.7.5-Build-27-Customizer-Fatal-Recovery-FULL
- Target package: ZinCelestial-BuddyX-v1.8.7.6-Build-28-Stage-2-Certification-FULL.zip
- Stage 2: Certified and approved by the project owner
- Validation policy: Run validation only when explicitly requested
- Stage 3: Planning authorized; implementation not started and not included
- Settings schema: Version 1
- Packaging rule: One complete WordPress-installable ZIP, never a patch or hotfix

# Build 24 Status
- Current package: ZinCelestial-BuddyX v1.8.7.2 Build 24 shared label helper correction.
- Scope: patch the shared label helper, scan all Customizer registrations, and create a verification matrix.
- Stable baseline remains Build 16 until live staging evidence and explicit promotion approval.
- Stage 2 remains unstarted.

# ZinCelestial-BuddyX Roadmap

## Release status
- Approved stable baseline: v1.8.5.3
- Current build: v1.8.5.5 BuddyPress 12+ Directory URL Compatibility
- Public theme name: ZinCelestial
- Technical project: ZinCelestial-BuddyX
- Parent theme: BuddyX
- Stable folder: zincelestial-buddyx
- Settings schema: version 1
- Default design system: ZinCelestial Neon
- Default skin: ZinCelestial Default
- Initial appearance: Dark mode with matching light mode
- Packaging rule: one complete installable ZIP, never a patch or hotfix.

## Theme Identity and Naming Lock
BuddyX is the parent compatibility foundation. ZinCelestial-BuddyX is the technical child-theme package. ZinCelestial is the public and administrator-facing theme name. ZinCelestial Neon is the shared design system, and ZinCelestial Default is the default skin. Additional skins are variations inside ZinCelestial, not separate themes.

## Current milestone
The v1.8.5.4 build introduces a schema-1 Customizer foundation, registered design-system metadata, six skins, dark/light mode controls, basic header and top-bar controls, accessibility controls, and read-only identity guidance while preserving the existing administration interface and save engine.

---

# ZinCelestial-BuddyX Roadmap

## Approved baseline
- v1.8.5 remains the rollback baseline.
- v1.8.5.2 is the Visual Foundation dependency-corrected candidate.
- v1.8.5.1 is superseded and must not be installed.

## Current milestone
- VS-1 Visual Foundation: tokens, typography, accessibility utilities, buttons, forms, alerts, badges, cards, navigation, header, and sidebar foundations.
- Stage 1 Customizer Foundation remains next after staging certification.

# ZinCelestial-BuddyX Roadmap

## Release status

- Approved working baseline: v1.8.5
- Stable theme folder: `zincelestial-buddyx`
- Settings schema: version 1
- Rejected builds: v1.9.0 and v1.9.1
- Development rule: expand the complete approved v1.8.5 package without reconstructing or replacing the stable foundation.
- Packaging rule: every stage must ship as a complete WordPress-installable ZIP, never as a patch or hotfix.

## Completed in v1.8.4.1

- Removed Profile Presets.
- Corrected horizontal profile-menu positions and defaults.
- Repaired frontend settings application.

## Completed in v1.8.5: Community Experience Scaffolding

- Added passive ownership, reader, migrator, snapshot, navigation inventory, platform, and administration classes.
- Kept settings schema version 1.
- Kept the Customizer and frontend ownership unchanged.
- Added read-only scaffold diagnostics and documentation.
- Preserved the protected save engine and last-known-good behavior.

## Rejected release history

### v1.9.0

- Rejected after a PHP syntax failure in `inc/Admin/Diagnostics.php`.
- Must not be used as a future baseline.

### v1.9.1

- Rejected after the Community Experience administration interface rendered without its settings panels and displayed duplicate save controls.
- Must not be used as a future baseline.


## Priority Design System: Approved Light and Dark Neon Component Boards

**Priority: Mandatory and cross-cutting for every future stage and release.**

- Use the uploaded light and dark neon component boards as the approved visual design system for the default ZinCelestial-BuddyX theme.
- Treat the light board as the default light-mode reference and the dark board as the dark-mode reference.
- Integrate the design system throughout existing and future frontend Community Experience interfaces, not only isolated demonstration pages.
- Preserve the functional ownership and markup requirements of WordPress, BuddyPress, bbPress, WooCommerce, and approved add-ons while applying the shared visual language.
- Build reusable components and design tokens rather than copying isolated page-specific CSS.
- Require matching light and dark variants for every component before the component is considered complete.
- Require responsive, keyboard-accessible, high-contrast, focus-visible, and reduced-motion variants.
- Do not introduce white surfaces into dark mode unless a narrowly scoped accessibility requirement requires one.
- Keep the approved neon cyan, electric blue, violet, magenta, pink, green, amber, red, and soft gradient treatments coordinated across both modes.
- Use glow and animation selectively, with reduced-motion fallbacks and readable contrast.

### Required design tokens

- Light and dark page backgrounds.
- Primary, secondary, elevated, glass, muted, and interactive surfaces.
- Text, muted text, link, border, divider, focus, selected, disabled, and overlay colors.
- Cyan, blue, violet, magenta, pink, green, amber, red, and neutral semantic colors.
- Gradient, glow, shadow, blur, transparency, opacity, radius, spacing, typography, and motion tokens.
- Component density, responsive breakpoint, icon-size, and focus-ring tokens.

### Required shell and navigation components

- Top headers, search bars, user/account menus, creation/action buttons, notification controls, and utility controls.
- Left navigation, right navigation, side panels, menu groups, active states, nested items, badges, and promotional cards.
- Breadcrumbs, tabs, subnavigation, pagination, dropdown menus, popovers, and tooltips.
- Desktop, tablet, and mobile navigation states.

### Required actions and controls

- Primary, secondary, success, danger, warning, information, outline, ghost, icon, and gradient call-to-action buttons.
- Text links, action links, inline links, destructive links, disabled links, and icon links.
- Toggles, switches, checkboxes, radio controls, sliders, range controls, ratings, and segmented controls.
- Text inputs, selects, textareas, search inputs, file uploads, media selectors, and validation states.
- Normal, hover, focus, active, selected, loading, disabled, success, warning, and error states.

### Required feedback and communication components

- Success, information, warning, and error alerts.
- Notifications, notification lists, unread markers, notification counts, and system notices.
- Toasts, snackbars, banners, confirmations, validation messages, empty states, loading states, and failure states.
- Badges, tags, removable chips, counters, status pills, labels, and availability indicators.
- Accessible announcements and reduced-motion behavior.

### Required content, data, and card components

- Hero cards, action cards, feature cards, product cards, media cards, profile cards, group cards, promotional cards, quote cards, and informational cards.
- Tables with headers, rows, actions, statuses, sorting, filtering, pagination, responsive overflow, and empty states.
- Lists, inbox lists, navigation lists, metadata lists, definition lists, activity lists, and selectable lists.
- Stats cards, progress bars, circular progress indicators, charts, legends, calendars, date pickers, avatars, avatar groups, and steppers.
- WordPress posts and pages, BuddyPress member and group content, activity cards, bbPress topics and replies, WooCommerce products and vendor shops, recipes, polls, galleries, support pages, and legal pages must use the shared component system where applicable.

### Required implementation rules

- Create one reusable component layer and token system shared across the default theme.
- Scope integrations carefully so third-party plugin behavior is not broken.
- Preserve native forms, permissions, semantics, hooks, and data ownership.
- Avoid scattered one-off styling and duplicate component implementations.
- Add visual regression checks for light mode, dark mode, desktop, tablet, and mobile.
- Add a component inventory and completion checklist to `BUILD-MANIFEST.json` for each release.
- Record component additions, removals, and visual changes in `CHANGELOG.md` and `ROADMAP.md`.
- Treat any new roadmap feature as incomplete until its applicable components match the approved light and dark boards.

### Initial component certification order

1. Design tokens, typography, surfaces, borders, shadows, glow, and focus states.
2. Buttons, links, form controls, toggles, selection controls, and file uploads.
3. Alerts, notifications, toasts, tags, badges, chips, tooltips, and popovers.
4. Navigation shells, left and right menus, tabs, breadcrumbs, pagination, and dropdowns.
5. Lists, tables, cards, hero cards, action cards, stats, progress, charts, and calendars.
6. BuddyPress member, group, activity, gallery, poll, privacy, and frontpage components.
7. bbPress forum components.
8. WooCommerce product, cart, checkout, vendor, currency, points, and marketplace components.
9. Support, legal, recipe, business-profile, alias-profile, and other future page systems.


## Visual-System Milestones

### VS-1: Foundation and Token Lock

- Convert the approved light and dark component boards into reusable design tokens.
- Define color, surface, text, border, glow, shadow, blur, radius, spacing, typography, icon, motion, and responsive tokens.
- Establish semantic tokens for success, information, warning, danger, active, selected, disabled, and focus states.
- Map every token to matching light-mode and dark-mode values.
- Keep dark mode free of white content surfaces.
- Document token ownership, fallback values, and allowed overrides.
- Validation gate: token documentation, contrast review, reduced-motion review, and visual comparison against both approved boards.

### VS-2: Core Controls and Interaction States

**Build 10 implementation status: implemented; staging certification pending.**

- Implement buttons, links, fields, selects, textareas, searches, uploads, toggles, checkboxes, radio controls, sliders, range controls, and ratings.
- Implement normal, hover, focus, active, selected, loading, disabled, success, warning, and error states.
- Create consistent icon sizing, control heights, spacing, focus rings, and validation messages.
- Validation gate: keyboard navigation, focus visibility, responsive behavior, light/dark parity, and reduced-motion behavior.

### VS-3: Feedback, Status, and Communication

- Implement alerts, notices, notifications, notification lists, unread markers, toasts, snackbars, banners, badges, tags, chips, counters, status pills, tooltips, and popovers.
- Define semantic color and icon rules for success, information, warning, danger, neutral, active, pending, and inactive states.
- Add accessible live-region behavior where required.
- Validation gate: contrast, dismissal behavior, timeout behavior, keyboard access, screen-reader labels, and light/dark parity.

### VS-4: Navigation and Application Shells

- Implement top headers, search bars, account menus, utility controls, left menus, right menus, nested menus, tabs, breadcrumbs, pagination, dropdowns, and mobile navigation.
- Add active, current, expanded, collapsed, pinned, scrolling, and responsive states.
- Integrate the system with native WordPress menu behavior and the planned advanced side-menu system.
- Validation gate: WordPress menu compatibility, keyboard traversal, mobile behavior, active-state accuracy, and light/dark parity.

### VS-5: Cards, Lists, Tables, and Data Displays

- Implement hero cards, action cards, feature cards, product cards, media cards, profile cards, group cards, promotional cards, quote cards, and informational cards.
- Implement lists, activity lists, metadata lists, inbox lists, selectable lists, and empty states.
- Implement tables with sorting, filtering, row actions, statuses, responsive overflow, pagination, loading, empty, and error states.
- Implement statistics cards, progress indicators, charts, legends, calendars, date pickers, avatar groups, and steppers.
- Validation gate: responsive density, overflow handling, readable hierarchy, data-state coverage, and light/dark parity.

### VS-6: WordPress and Community Integration

- Apply the component system to WordPress posts, pages, archives, comments, forms, search, navigation, and system messages.
- Apply the component system to BuddyPress member, group, activity, gallery, poll, privacy, frontpage, notification, and messaging interfaces.
- Apply the component system to bbPress topics, replies, forums, notices, and forms.
- Preserve native hooks, permissions, semantics, extension points, and data ownership.
- Validation gate: plugin compatibility, frontend regression testing, accessibility, responsive layouts, and light/dark parity.

### VS-7: WooCommerce and Marketplace Integration

- Apply the component system to WooCommerce products, archives, cart, checkout, account, orders, notices, currencies, points, and payment interfaces.
- Apply the component system to marketplace vendor shops, vendor cards, storefronts, policies, ratings, support, and approved WCFM-compatible interfaces.
- Preserve WooCommerce and marketplace-plugin ownership of commerce data and workflows.
- Validation gate: product, cart, checkout, account, order, refund, vendor, currency, and points-flow regression tests.

### VS-8: Extended Page-System Integration

- Apply the component system to support pages, legal pages, recipes, alias profiles, business profiles, galleries, polls, and future Community Experience systems.
- Add page-specific components only when the shared inventory cannot safely support the requirement.
- Require all additions to extend the shared tokens and component inventory.
- Validation gate: page-template consistency, accessibility, responsive behavior, and light/dark parity.

### VS-9: Visual Certification and Release Governance

- Maintain reference screenshots for light and dark modes at desktop, tablet, and mobile sizes.
- Run visual regression checks for every certified component and major integration surface.
- Track component status as planned, in progress, implemented, certified, or blocked.
- Record token and component changes in `ROADMAP.md`, `CHANGELOG.md`, and `BUILD-MANIFEST.json`.
- Prevent release promotion when required components lack light mode, dark mode, accessibility, responsive, or reduced-motion certification.


### VS-10: Token Usage, Component Mapping, and Visual QA Lock

- Enforce the mandatory token-usage rules in `DESIGN-TOKENS.md`.
- Map every component family to semantic tokens before implementation.
- Require integration aliases to resolve to the core token system.
- Maintain `COMPONENT-INVENTORY.md` as the source of truth for component status and certification.
- Use `VISUAL-QA-CRITERIA.md` for light, dark, responsive, accessibility, state, integration, and regression certification.
- Block promotion when token exceptions are undocumented or required visual evidence is missing.

## Planned staged releases

### Stage 1: Customizer Foundation

**Status: Deferred indefinitely. Historical scope retained for reference only.**

- Add a native **ZinCelestial Community Experience** Customizer panel.
- Mirror the existing v1.8.5 settings into organized Customizer sections.
- Continue using the existing `zcbx_settings` option.
- Reuse `zcbx_defaults()` and `zcbx_sanitize()`.
- Keep settings schema version 1.
- Keep the existing administration page available and unchanged.
- Preserve the protected save engine, active asset loader, frontend runtime, and CSS.
- Use refresh-based previews first.
- Do not perform automatic migration, ownership switching, control removal, data deletion, or schema changes.

#### Planned Customizer sections

- Site Experience
- Member Experience
- Group Experience
- Profile Menu
- Signature Icons
- Backgrounds and Covers
- Widget Titles
- Site Subheader
- Content Surfaces
- Migration and Ownership, read-only
- Diagnostics, read-only

### Stage 2: Customizer Certification

**Status: Deferred indefinitely because the ZinCelestial Community Experience Customizer was removed.**

- Verify every control saves correctly.
- Verify values persist after refresh and reload.
- Verify fallback behavior.
- Confirm the Customizer and existing administration page remain synchronized.
- Test member pages and group pages.
- Test desktop, tablet, and mobile previews.
- Test accessibility and reduced-motion behavior.
- Limit the stage to certification and confirmed corrections only.

### Stage 3: Selective Live Preview

**Status: Deferred indefinitely. No selective live-preview implementation is active.**

- Add selective `postMessage` previews after Stage 2 passes staging.
- Add live preview for colors, spacing, opacity, images, surfaces, and safe layout settings.
- Keep refresh fallback for controls that cannot update safely.
- Add contextual edit shortcuts for supported frontend areas.

### Stage 4: Signature Icon Library

**Status: Completed across Builds 29R.23 through 29R.30. The library remains independent of Customizer ownership and is the required source for later icon assignment.**

- Add a reusable ZinCelestial Signature Icon Library.
- Add an administrator icon generator.
- Add icon validation and sanitization.
- Add duplicate protection.
- Add reusable accessible icon titles and descriptions.
- Keep the library separate from navigation assignment until certified.

### Stage 5: Navigation Icon Controls

**Status: Completed through Build 29R.62. Foundation started in Build 29R.60, advanced Playground controls shipped in Build 29R.61, and preset import/export plus bulk actions shipped in Build 29R.62.**

- Add menu-item Signature Icon selection.
- Add before-label, after-label, above-label, below-label, and icon-only placement.
- Add icon size and spacing controls.
- Add desktop and mobile alignment.
- Add mobile visibility controls.
- Add normal, hover, focus, active, and disabled states.
- Add per-item colors, opacity, and glow controls.
- Add accessible labels and reduced-motion support.
- Add preset import and export.
- Add bulk apply and clear actions.
- Preserve the existing BuddyPress profile-navigation runtime instead of replacing it.

### Build 29R.64 Stage 6A progress

- Member Command Hub foundation implemented on BuddyPress member front pages.
- Native profile navigation and content remain the fallback and are not replaced.
- Member identity, connections, groups, activity shortcuts, responsive shell, and extension hook are available.
- Group Command Hub, configurable front-page composition, appearance controls, broader layout reconciliation, and remaining Stage 6 work remain planned.
- Stage 6 status: **Active, not complete**.

### Build 29R.65 Stage 6B progress

- Group Command Hub foundation implemented on BuddyPress group front pages.
- Native group navigation, permissions, and content remain the fallback and are not replaced.
- Group identity, member count, activity and members shortcuts, responsive shell, and extension hook are available.
- Member and Group Command Hub foundations are active; configurable front-page composition, appearance controls, broader layout reconciliation, and remaining Stage 6 work remain planned.
- Stage 6 status: **Active, not complete**.

### Build 29R.66 Stage 6C progress

- Registered primary and secondary widget regions for Member and Group Command Hub front pages.
- Empty regions do not render, preserving native BuddyPress fallback content and lean output.
- Added an administrator enable/disable control through the existing schema-version-1 settings system.
- Appearance controls, broader layout reconciliation, activity improvements, and widget expansion remain planned.
- Stage 6 status: **Active, not complete**.

## Stage 6: Deferred Community Experience Features

**Status: Active next milestone after Stage 5 completion. Stage 6 remains limited to the previously deferred community experience work and does not absorb later roadmap stages.**

- Reconcile and certify additional avatar shapes and frames.
- Preserve the double-avatar-frame correction.
- Expand boxed and full layout surface controls.
- Verify Site Subheader saving and frontend application.
- Review wider Signature Icon adoption without automatic plugin-wide replacement.
- Review scheduled visual effects such as confetti, fireworks, snow, falling hearts, Halloween candles, and holiday effects.
- Review scheduling, size, duration, color, opacity, overlay, profile targeting, and reduced-motion controls for visual effects.

#### Stage 6A: Member and Group Command Hubs

**Status: Complete in Build 29R.84, reconciled from approved Build 29R.83.**

- Complete the Member Command Hub and Group Command Hub while preserving native BuddyPress URLs, actions, permissions, data, and extension hooks.
- Upgrade member and group headers, overview regions, summary cards, and configurable frontpage surfaces.
- Support controlled widget placement and connect approved command actions to BuddyPress activity records where appropriate.

#### Stage 6B: Member and Group Appearance

- Add member-controlled profile backgrounds and group-controlled group-page backgrounds under administrator policy.
- Add cover presentation controls, safe defaults, responsive behavior, and coordinated light and dark presentation.
- Continue using the existing ZinCelestial design tokens and libraries.

#### Stage 6C: Community Layout Framework

- Reconcile member, group, activity, directory, profile, and header layouts under one coordinated visual system.
- Apply consistent cards, spacing, controls, action regions, feedback, and empty states across the default ZinCelestial theme.
- Preserve BuddyPress Nouveau and Legacy compatibility and avoid unnecessary template overrides.
- Preserve the standard WordPress/BuddyX Customizer.

#### Stage 6D: Activity and Communication Experience

- Improve activity stream presentation, threaded comments, mentions, notices, status messages, feedback, privacy indicators, and group activity presentation.
- Preserve BuddyPress ownership and permissions and connect supported command-hub actions to activity records where appropriate.

#### Stage 6E: Widget and Component Expansion

- Expand member and group summary, navigation, activity, achievement, and status widgets using real community data.
- Reuse the existing Element, Component, and Signature Icon Libraries.
- Preserve approved drag-and-drop behavior and add controlled visibility and placement options.

#### Stage 6 completion conditions

- Member and Group Command Hubs are operational.
- Member and group frontpages are distinct, configurable, responsive, and coordinated in light and dark modes.
- Community layouts use one coordinated visual system while preserving BuddyPress behavior and permissions.
- Every deferred Stage 6 item is completed or remains explicitly recorded as deferred.
- Governance documents identify the next unchanged roadmap stage.
- Validation is performed only when explicitly requested and does not block roadmap progress by default.

### Stage 7: Advanced Left and Right Menu System

**Status: Active. Foundation, accordion, resizing, runtime isolation, administration, and five presets are present; Build 29R.90 adds per-side menu-item hover styling and open-state control cleanup.**

- Add separate left-side and right-side menu systems using the native WordPress menu framework.
- Support independent menu locations, assignments, and menu profiles.
- Add accordion sections and nested menu groups.
- Add desktop, tablet, and mobile display modes.
- Add internal scrolling for long menus.
- Add panel resizing and width controls.
- Add menu presets and reusable configurations.
- Add context-based visibility rules.
- Add smart active-item and current-section states.
- Add header, content, and footer regions inside each side menu.
- Add device-specific visibility and behavior.
- Add scheduling controls.
- Add accessibility, keyboard navigation, contrast, and reduced-motion support.
- Add transparency, opacity, blur, surface, border, shadow, and glow controls.
- Preserve WordPress menu editing, hierarchy, custom links, categories, pages, and menu-item classes.

### Stage 8: BuddyPress Galleries

- Add member galleries.
- Add group galleries.
- Add global community galleries.
- Support images, videos, albums, captions, descriptions, and cover images.
- Add privacy and visibility controls.
- Add member-type, role, group, and context rules.
- Add moderation, reporting, approval, and ownership controls.
- Add responsive grid, masonry, carousel, and lightbox layouts.
- Add sorting, filtering, search, pagination, and featured media.
- Add upload limits, file-type rules, size limits, and storage safeguards.
- Add accessibility and mobile upload support.

### Stage 9: Activity Stream Editing and Revisions

- Add permitted activity-stream editing.
- Add editing time limits and role-based exceptions.
- Add revision history and restoration.
- Add edited-state labels and timestamps.
- Add moderation review for sensitive edits.
- Add audit records for edits, restores, and removals.
- Preserve BuddyPress activity ownership and permission checks.
- Add administrator settings for editable activity types and limits.

### Stage 10: BuddyPress, bbPress, Post, and Page Reactions

- Add reactions for BuddyPress activity items and comments.
- Add reactions for BuddyPress member and group content.
- Add reactions for bbPress topics and replies.
- Add reactions for WordPress posts, pages, and supported public post types.
- Add configurable reaction sets using ZinCelestial Signature Icons.
- Add per-content-type enable and disable controls.
- Add anonymous, member-only, role, member-type, and group rules.
- Add reaction counts, summaries, user lists, and privacy controls.
- Add rate limiting, duplicate protection, abuse reporting, and moderation.
- Add accessibility labels, keyboard support, and reduced-motion behavior.

### Stage 11: Social Trending and Reaction Analytics

- Add trending activity, posts, pages, topics, replies, members, groups, and media.
- Add reaction-based and engagement-based trend calculations.
- Add configurable time windows and decay rules.
- Add global, member-type, group, category, and site scopes.
- Add trending widgets, blocks, shortcodes, and BuddyPress components.
- Add administrator controls for weighting, exclusions, thresholds, and refresh intervals.
- Add privacy-aware aggregation and moderation exclusions.
- Add caching and performance safeguards.
- Add read-only analytics for reactions and trending content.

### Stage 12: BuddyPress Member Frontpage Upgrades

- Repair and certify existing member frontpage behavior.
- Add improved member frontpage layouts and presets.
- Add configurable content regions and widget zones.
- Add role, member-type, ownership, privacy, and context visibility rules.
- Add desktop, tablet, and mobile layouts.
- Add empty-state and fallback behavior.
- Add import and export for frontpage layouts.
- Preserve existing BuddyPress profile navigation and permissions.

### Stage 13: BuddyPress Group Frontpage Upgrades

- Repair and certify existing group frontpage behavior.
- Add improved group frontpage layouts and presets.
- Add configurable content regions and widget zones.
- Add group-type, membership, role, status, privacy, and context rules.
- Add desktop, tablet, and mobile layouts.
- Add empty-state and fallback behavior.
- Add import and export for group frontpage layouts.
- Preserve existing BuddyPress group navigation and permissions.

### Stage 14: Drag-and-Drop BuddyPress Frontpage Widget System

- Adapt the proven ZinCrew drag-and-drop widget approach for BuddyPress member and group frontpages.
- Keep ZinCrew and ZinCelestial-BuddyX as separate products with no runtime dependency between them.
- Support independent member and group widget registries.
- Support widget placement, ordering, pinning, collapsing, and visibility.
- Support multiple widget sizes and responsive spans.
- Support desktop, tablet, and mobile layouts.
- Support per-user, per-member-type, per-group-type, and administrator defaults.
- Support layout presets, reset controls, import, and export.
- Add permission checks, nonce protection, validation, and safe persistence.
- Add accessibility, keyboard reordering, reduced-motion, and touch controls.
- Preserve existing widgets and prevent layout changes from removing content.

### BuddyPress Add-on Expansion Backlog

- Add a formal BuddyPress add-on registry for future member, group, activity, media, forum, reaction, trending, and frontpage modules.
- Require each add-on to declare dependencies, permissions, settings ownership, assets, data storage, privacy behavior, and uninstall behavior.
- Keep add-ons modular so unfinished systems can remain disabled without affecting the stable theme.
- Add add-on diagnostics, compatibility status, and feature flags.
- Add more BuddyPress add-on ideas to this backlog as they are approved.


### Stage 15: Community Support Pages

- Add a complete support-page suite for members, groups, customers, visitors, and staff-facing help entry points.
- Add Help Center, Contact Support, Submit a Ticket, Ticket Status, Frequently Asked Questions, Knowledge Base, Troubleshooting, Community Guidelines, Report a Problem, Service Status, Hours of Operation, and Emergency Contact pages.
- Add reusable support page templates, blocks, widgets, and shortcodes.
- Add role, membership, logged-in, logged-out, group, and context visibility rules.
- Add support categories, search, filters, featured answers, related articles, and escalation paths.
- Add configurable support forms with required fields, attachments, consent notices, spam protection, and confirmation messages.
- Add administrator-managed support notices, closures, maintenance messages, and availability indicators.
- Add responsive layouts, accessibility, keyboard navigation, and reduced-motion support.
- Preserve boundaries between ZinCelestial-BuddyX frontend support pages and ZinCrew internal staff workflows.

### Stage 16: Legal Pages and Legal Document Generator

- Add a legal-page center for website legal and policy documents.
- Add guided generators for Privacy Policy, Terms of Service, Terms and Conditions, Cookie Policy, Accessibility Statement, Acceptable Use Policy, Community Guidelines, Refund Policy, Return Policy, Shipping Policy, Membership Terms, Subscription Terms, Marketplace Terms, Seller Terms, Contributor Terms, Copyright Policy, DMCA Process, Disclaimer, Affiliate Disclosure, Advertising Disclosure, Contest Rules, Event Terms, User-Generated Content Policy, Data Request Information, and other approved website documents.
- Add jurisdiction, business type, site features, audience, payments, memberships, ecommerce, community, forum, media, analytics, advertising, and data-processing questionnaires.
- Add reusable clauses, document sections, version history, effective dates, revision dates, review status, and approval workflow.
- Add draft, reviewed, approved, published, archived, and superseded document states.
- Add document duplication, import, export, print, and downloadable versions.
- Add automatic page creation only after explicit administrator approval.
- Add configurable policy links for registration, checkout, forms, uploads, comments, groups, forums, and account settings.
- Add consent checkboxes and acceptance records where separately approved.
- Add change notices and re-acceptance requirements where separately approved.
- Include clear notices that generated documents are templates and require qualified legal review before publication.
- Keep legal content generation separate from legal advice and do not represent generated documents as guaranteed compliance.

### Stage 17: New BuddyPress Member Pages

- Add new BuddyPress member-facing pages and components without replacing core BuddyPress account ownership or permissions.
- Add member dashboard, profile overview, activity overview, connections, groups, forums, media, galleries, bookmarks, reactions, achievements, points, badges, ranks, saved items, history, privacy, account tools, support, and other approved member pages.
- Add configurable navigation labels, order, icons, visibility, access rules, and empty states.
- Add member-type, role, ownership, privacy, logged-in, logged-out, and device conditions.
- Add page templates for full width, sidebar left, sidebar right, three column, dashboard, cards, feed, directory, and focused content layouts.
- Add responsive member navigation and mobile overflow handling.
- Add administrator controls for enabling, disabling, ordering, and assigning templates to member pages.
- Add extension hooks so future BuddyPress add-ons can register member pages safely.

### Stage 18: New BuddyPress Group Pages

- Add new BuddyPress group pages and components without replacing core group ownership, membership, privacy, or moderation rules.
- Add group dashboard, overview, activity, members, leadership, discussions, forums, media, galleries, files, resources, events, projects, announcements, reactions, trending content, support, and other approved group pages.
- Add configurable navigation labels, order, icons, visibility, access rules, and empty states.
- Add group-type, group-status, membership-level, moderator, administrator, owner, and device conditions.
- Add public, private, hidden, invitation-only, and restricted-state handling.
- Add page templates for full width, sidebar left, sidebar right, three column, dashboard, cards, feed, directory, and focused content layouts.
- Add administrator controls for enabling, disabling, ordering, and assigning templates to group pages.
- Add extension hooks so future BuddyPress add-ons can register group pages safely.

### Stage 19: Member and Group Profile Template System

- Add reusable member profile templates.
- Add reusable group profile templates.
- Add template assignment by member type, role, group type, group status, membership level, site, and context.
- Add header, cover, identity, navigation, sidebar, content, widget, call-to-action, footer, and mobile regions.
- Add full width, boxed, split, overlay, card, showcase, professional, creator, community, organization, portfolio, directory, and dashboard-style templates.
- Add template presets, duplication, naming, preview, draft, publish, archive, import, export, and reset controls.
- Add per-template colors, surfaces, typography, spacing, radius, border, shadow, transparency, opacity, blur, glow, and motion controls.
- Add desktop, tablet, and mobile template variants.
- Add safe fallback to the approved default template when a template is unavailable or invalid.
- Add compatibility checks for BuddyPress Nouveau, BuddyX, bbPress, WooCommerce, membership plugins, points systems, galleries, and approved add-ons.
- Preserve the existing stable profile-header and group-header behavior until each replacement template is certified.

### Stage 20: Recipe Pages and Community Recipe System

- Add recipe archive, recipe directory, single recipe, author recipes, group recipes, saved recipes, trending recipes, seasonal recipes, and featured recipe pages.
- Add recipe categories, cuisines, meal types, dietary labels, difficulty, preparation time, cooking time, total time, servings, occasions, seasons, equipment, and ingredient classifications.
- Add structured ingredient groups and step-by-step instructions.
- Add featured images, galleries, videos, printable views, notes, substitutions, nutrition fields, source attribution, and accessibility text.
- Add member recipe submissions with draft, review, approval, rejection, revision, published, archived, and reported states.
- Add group-owned and member-owned recipes.
- Add privacy, ownership, editing, moderation, reporting, and attribution controls.
- Add recipe reactions, ratings, comments, bookmarks, collections, sharing, and trending support where separately approved.
- Add serving-size scaling, unit display options, shopping-list support, and ingredient check-off controls where separately approved.
- Add recipe cards, widgets, blocks, shortcodes, profile components, group components, and frontpage widgets.
- Add responsive layouts, print styles, keyboard support, and reduced-motion behavior.
- Add compatibility planning for search, multilingual content, ecommerce ingredients, memberships, points, achievements, and community moderation.

### Community Page and Template Expansion Backlog

- Continue adding approved community page types, profile templates, content templates, generators, directories, and frontend systems to this backlog.
- Require each page system to declare ownership, permissions, privacy behavior, storage, moderation, accessibility, responsive behavior, dependencies, and uninstall handling.
- Keep unfinished page systems disabled behind feature flags until certified.


### WooCommerce Commerce Scope for Stages 21–24

- Stages 21 through 24 are WooCommerce systems.
- WooCommerce remains the commerce, product, cart, checkout, order, tax, shipping, coupon, refund, and payment foundation.
- Approved marketplace and points plugins extend WooCommerce rather than replacing WooCommerce ownership.
- Cross-site cart, currencies, GamiPress points, and vendor shops must preserve WooCommerce order integrity and compatibility.

### Stage 21: WooCommerce Multisite and Approved External-Site Global Cart

- Build the shared cart on WooCommerce for WordPress Multisite and explicitly approved external WordPress sites.
- Require explicit site registration, trust verification, capability negotiation, and administrator approval before a site can participate.
- Add cart item source-site and vendor attribution.
- Add cross-site product validation, availability checks, quantity checks, shipping context, tax context, and checkout reconciliation.
- Add clear handling for products that cannot be combined into one order.
- Add per-site, per-vendor, and per-product participation controls.
- Add cart expiration, conflict resolution, retry behavior, logging, diagnostics, and recovery safeguards.
- Add privacy, security, nonce, signature, rate-limit, and replay-protection requirements for external-site communication.
- Keep order ownership, refunds, fulfillment, taxes, shipping, commissions, and reporting traceable to the correct site and vendor.
- Add feature flags so the global cart remains disabled until each integration passes staging certification.

### Stage 22: WooCommerce Multi-Currency and Multi-Value Checkout

- Add support for more than one monetary currency through the approved WooCommerce commerce stack.
- Add administrator-approved currency lists, display formats, rounding rules, conversion sources, and refresh rules.
- Add base currency, shopper display currency, checkout currency, vendor settlement currency, and reporting currency definitions.
- Add clear price snapshots so later exchange-rate changes do not alter completed orders.
- Add taxes, shipping, discounts, fees, refunds, commissions, subscriptions, and reporting safeguards for multiple currencies.
- Add supported non-cash value types as separately governed WooCommerce payment methods.
- Add full-payment and, only when separately certified, partial-payment rules.
- Prevent unsupported currency or payment combinations at product, vendor, cart, and checkout level.
- Add audit history for conversion rates, payment method, value debits, refunds, and settlement records.

### Stage 23: GamiPress Points Commerce for WooCommerce

- Add approved GamiPress points types as optional WooCommerce payment methods.
- Add per-points-type conversion rates and labels.
- Add points balance display at cart and checkout.
- Add points debit, refund restoration, failed-order recovery, and duplicate-charge protection.
- Add product, category, vendor, shop, membership, role, site, and currency eligibility rules.
- Allow selected points types only in specifically approved vendor shops.
- Add vendor attribution and settlement rules for points-funded purchases.
- Add clear handling for mixed carts containing eligible and ineligible items.
- Keep full-payment and partial-payment support as separate certification tracks.
- Add limits, fraud controls, rate limits, minimum balances, maximum redemption, and administrator override rules.
- Add transaction logs, member history, vendor history, order notes, privacy export, and erasure handling.

### Stage 24: WooCommerce Marketplace Vendor Shops

- Add marketplace vendor-shop templates compatible with approved WooCommerce multivendor systems such as WCFM Marketplace.
- Add vendor storefront header, cover, identity, description, policies, products, categories, ratings, reactions, followers, galleries, support, and contact regions.
- Add vendor-specific currency and approved points-payment settings subject to network rules.
- Add vendor-specific product eligibility for global cart participation.
- Add vendor capability, membership, verification, suspension, privacy, and moderation controls.
- Add commission, payout, refund, shipping, tax, order, and settlement compatibility requirements.
- Add vendor shop layouts, presets, sidebars, widgets, mobile layouts, and Customizer options.
- Add safe fallback templates when a marketplace integration is unavailable.
- Preserve marketplace-plugin ownership of vendor accounts, commissions, payouts, and order records.

### Stage 25: BuddyPress, WordPress, and bbPress Polls

- Add a shared poll framework for BuddyPress activity, WordPress content, and bbPress discussions.
- Add four selectable poll types:
  - Single-choice poll.
  - Multiple-choice poll.
  - Ranked-choice poll.
  - Image or media-choice poll.
- Add poll placement in BuddyPress activity, activity comments where supported, WordPress posts and pages, supported public post types, bbPress topics, and bbPress replies where approved.
- Add start date, end date, scheduling, result visibility, anonymous voting, logged-in-only voting, and eligibility rules.
- Add member-type, role, group, forum, category, site, and context restrictions.
- Add option limits, vote-change rules, result locking, quorum, moderation, reports, and closure controls.
- Add duplicate-vote protection, rate limiting, audit records, privacy controls, and export behavior.
- Add responsive poll cards, charts, accessible labels, keyboard support, contrast, and reduced-motion behavior.
- Add widgets, blocks, shortcodes, trending-poll views, and profile or group poll history.

### Stage 26: BuddyPress Activity Stream Card Upgrade

- Upgrade BuddyPress activity entries into configurable responsive activity cards.
- Add card layout presets, density, surface, spacing, border, radius, shadow, transparency, opacity, blur, and glow controls.
- Improve author header, avatar, member type, timestamp, privacy marker, activity type, content, attachments, media, link previews, reactions, comments, sharing, saving, reporting, and moderation regions.
- Add optional compact, standard, expanded, media-first, discussion, announcement, marketplace, event, poll, and featured card styles.
- Add administrator controls for enabled card regions and activity types.
- Add member, group, site, activity-type, device, and context conditions.
- Add improved loading, pagination, infinite-scroll, empty, error, deleted, moderated, and archived states.
- Add accessibility, semantic markup, keyboard navigation, contrast, and reduced-motion support.
- Preserve BuddyPress activity ownership, permissions, filters, and extension hooks.

### Stage 27: Advanced Member and Group Privacy

- Add improved privacy settings for member profiles, profile fields, activity, connections, groups, galleries, media, reactions, polls, bookmarks, achievements, points, and supported custom components.
- Add improved privacy settings for group content, activity, members, galleries, files, forums, polls, events, projects, and supported custom components.
- Add public, members-only, connections-only, group-members-only, selected audiences, private, and administrator-only options where appropriate.
- Add field-level and component-level defaults controlled by administrators.
- Add member-controlled overrides only where administrators allow them.
- Add group-type, member-type, role, membership level, ownership, moderation, and site rules.
- Add privacy summaries, preview-as tools, warnings, safe defaults, inheritance, and conflict resolution.
- Add audit logs for administrator privacy-policy changes without exposing private content.
- Add privacy export, erasure, retention, consent, blocking, reporting, and account-deletion handling.

### Stage 28: Member Alias Profiles

- Allow up to three administrator-approved alias profiles per member account.
- Keep one underlying WordPress user account and one account email address.
- Allow each alias profile to be public or private, subject to administrator policy.
- Add alias display name, avatar, cover, biography, profile fields, navigation, template, privacy, and visibility controls.
- Add clear ownership links for administrators while preventing unauthorized public disclosure of the underlying account.
- Add controls for which alias may create activity, post content, comment, join groups, participate in forums, react, vote, upload media, or operate a vendor shop.
- Add alias switching with nonce protection, capability checks, session logging, and clear active-identity indicators.
- Add abuse prevention, impersonation rules, reserved names, verification, reporting, suspension, and administrator review.
- Add search, directory, mentions, notifications, messaging, moderation, privacy export, erasure, and account-deletion behavior.
- Prevent alias profiles from creating additional login credentials or bypassing bans, restrictions, memberships, or permissions.

### Stage 29: Business Member Profiles

- Add a dedicated business member profile type linked to an approved member account.
- Add business name, logo, cover, description, industry, services, products, locations, hours, contact methods, website links, galleries, announcements, reviews, reactions, support, and policy regions.
- Add business verification, ownership review, claimed-profile workflow, suspension, reporting, and moderation.
- Add public, private, members-only, selected-audience, and administrator-controlled visibility options.
- Add professional, storefront, portfolio, service provider, organization, creator, and marketplace template presets.
- Add connections to approved vendor shops, groups, jobs, events, recipes, galleries, support pages, and other separately approved modules.
- Keep business profiles separate from vendor-shop financial records unless an explicit integration is enabled.
- Add member navigation, directories, search, filters, widgets, blocks, shortcodes, and frontpage components.
- Add responsive layouts, accessibility, privacy export, erasure, and retention handling.


### Stage 30: Main Menu and Mega Menu System

- Extend native WordPress menus and the completed Stage 5 Navigation Icon Controls without creating a separate navigation framework or icon registry.
- Add standard dropdown and opt-in mega-menu modes per menu item.
- Add row, column, section, width, alignment, contained, full-width, and parent-aligned panel controls.
- Support native links, WordPress blocks, approved widgets, existing ZinCelestial components, images, promotional panels, search, account, notification, member, group, and permitted dynamic community content.
- Add hover, hover-intent, select-to-open, opening delay, safe closing, active item, sticky, transparent, solid, glass, compact, command, and neon presentation controls.
- Add independent desktop, tablet, and mobile behavior, including dropdown, accordion, left or right off-canvas, and full-screen command-menu modes.
- Add mobile header, content, and footer regions, internal scrolling, touch-safe controls, responsive breakpoints, device visibility, and context rules.
- Add complete keyboard navigation, visible focus, Enter and Space activation, Escape close behavior, expanded and collapsed states, accessible labels, icon-only fallbacks, and reduced-motion support.
- Add per-location configuration, presets, Playground preview, import, export, duplication, reset, scheduling, permissions, and bulk actions.
- Preserve native menu links, hierarchy, labels, classes, locations, WordPress behavior, and coordination with Stage 7 Advanced Left and Right Menu System.

### Stage 31: Network Moderation and Community Safety System

- Implement durable moderation records and enforcement in a network-capable platform service or plugin, with ZinCelestial-BuddyX providing coordinated frontend and administration presentation.
- Add multisite, network, site, group, member, and approved external-site moderation scopes.
- Moderate supported user activity, activity comments, WordPress posts and comments, group content, chats exposed by approved integrations, uploads, downloads, profiles, media, links, and embedded content.
- Add a central moderation queue, cases, priorities, categories, assignments, evidence references, moderator notes, decision history, reversible actions, escalation, appeals, complete audit history, and configurable retention.
- Add reporting for supported activities, comments, posts, messages, uploads, groups, and members, including configurable reasons, reporter notes, duplicate consolidation, status tracking, privacy, abuse controls, and emergency review paths.
- Add user blocking and muting as separate controls, plus contact, mention, invitation, notification, visibility, and selected-profile-information controls.
- Add content warnings, quarantine, unpublishing, removal, restoration, posting restrictions, messaging restrictions, upload and download restrictions, group participation restrictions, site suspension, network suspension, group suspension, group read-only mode, account review holds, and controlled permanent-removal processes.
- Add group moderator roles, group rules, member approval and removal, group queues, escalation, network administrator override, and group-action audit history.
- Add network, site, and group moderation dashboards with case search, filters, role-based access, delegated permissions, conflict reassignment, rule configuration, duration controls, notifications, privacy controls, diagnostics, and integration status.
- Add approved external WordPress site registration, authentication, signed requests, replay protection, capability negotiation, connection health, minimum-data event payloads, retries, failure logs, disconnection controls, and authorization-safe enforcement.
- Add data minimization, restricted evidence access, retention and deletion handling, privacy export, appeals, administrator review, and clear reasons for staff actions.
- Use real moderation data, the existing Signature Icon Library, coordinated light and dark modes, responsive interfaces, keyboard-accessible workflows, and clear warning, restriction, suspension, restoration, and appeal states.
- Preserve theme independence for moderation data, audit history, enforcement rules, and connected-site services.

### Federated Commerce and Identity Backlog

- Treat global cart, external-site commerce, multiple currencies, points payments, vendor settlements, alias identities, and business identities as separate high-risk systems with independent certification gates.
- Require compatibility reviews for WooCommerce, the selected multivendor system, GamiPress, payment gateways, taxes, shipping, subscriptions, refunds, privacy, and multisite behavior.
- Do not enable cross-site checkout, points settlement, alias commerce, or business commerce by default.

## Deferred until separately approved

- Automatic Customizer scanning or import. **Deferred indefinitely.**
- Automatic migration or ownership switching. **Deferred indefinitely.**
- Customizer control removal. **Completed for the ZinCelestial Community Experience Customizer in Build 29R.2; retained here as historical policy.**
- Schema version 2.
- Automatic rollback writes.
- Navigation inventory execution.
- Global forced icon replacement across WordPress and third-party plugins.
- Removal of the stable Community Experience administration page.
- Combining several uncertified stages into one release.

## Validation gates for every stage

- Start from the complete approved v1.8.5 ZIP.
- Reconcile `ROADMAP.md`, `CHANGELOG.md`, and `BUILD-MANIFEST.json` before packaging.
- Verify protected-file checksums.
- Run PHP syntax checks using a real PHP executable.
- Run WordPress activation and administration-load tests.
- Run Customizer load, save, refresh, reload, and fallback tests.
- Run existing administration-page regression tests.
- Run member-page and group-page frontend tests.
- Run desktop, tablet, mobile, keyboard, contrast, and reduced-motion tests.
- Validate the ZIP root folder and archive contents.
- Require staging approval before starting the next stage.

## Release principle

Expand, do not rewrite. Preserve the accepted v1.8.5 architecture, settings, save engine, frontend behavior, and styling unless a narrowly scoped functional or accessibility requirement makes a change necessary.

## Community Member and Group Layout Program
Status: Batches 0 through 4 implemented in source. Frontend remains disabled by default. Packaging remains separately gated. BuddyPress Builder remains deferred.

Batch 5 completed: opt-in Customizer settings, independent member/group modes, validated column widths, and responsive stack-point controls. Frontend remains inactive until the global control and the matching context control are both enabled.

Batch 6 completed: advanced spacing, optional sticky behavior, bounded internal scrolling, and independent mobile display positions. All advanced behaviors remain opt-in.

Batch 7 completed: side-level audience rules, member/group context scopes, and six independent region controls. Defaults preserve existing visibility and do not move widgets.

### Community Layout Settings Correction Build
- Integrated all Batch 5 through Batch 7 Community Layout controls into the authoritative schema-version-1 defaults and sanitizer.
- Preserved existing settings when a multidimensional option update contains only a subset of keys.
- Kept frontend activation disabled by default and automatic widget assignment disabled.
- Kept protected save-engine files and the active asset loader unchanged.
- Requires WordPress staging validation before stable approval.

## Build 7 Corrected Full - Completed Integration Scope

- [x] Rebuild Build 7 from the approved v1.8.5.5 Community Layout Settings Correction FULL baseline.
- [x] Preserve all existing Community Experience, Customizer, Community Layout, visual-foundation, and protected settings systems.
- [x] Add a read-only WooCommerce compatibility matrix and state resolver.
- [x] Add Dokan, WCFM Marketplace, WC Vendors, MultiVendorX, and YITH Multi Vendor adapters.
- [x] Add report-only multiple-marketplace conflict detection.
- [x] Keep vendor and commerce records under their owning plugins.
- [x] Add unit-test scaffolding and staging validation gates.
- [x] Complete structural PHP validation and record the user-approved PHP CLI lint waiver for the staging candidate.
- [ ] Complete WordPress staging activation, Customizer regression, commerce-screen, and log validation.


### Completed: Build 8 Community Layout Visual Corrections
- Corrected command-center empty-height behavior and oversized blank regions.
- Corrected sticky offsets and responsive shell overflow.
- Improved Member Groups, Member Connections, group front-page, and forum widget density.
- Added duplicate language-selector protection inside the Community Layout shell.
- Preserved all existing roadmap stages and protected systems.


## Build 9 correction status (v1.8.5.7)

- Approved baseline: `ZinCelestial-BuddyX-v1.8.5.6-Build-8-Community-Layout-Visual-Corrections-FULL.zip`.
- Build 9 correction pass: semantic dark-mode surfaces, canonical motion tokens, and governance reconciliation.
- Protected save systems and settings schema version 1 remain unchanged.
- VS-2 remains the next milestone and is not started by this correction pass.
- Main theme contains and enqueues no `platform.css` or `platform.js`.
- Delivery remains one complete installable ZIP after validation.


## Build 10 status (v1.8.5.8)

- VS-2 core controls are implemented inside the default ZinCelestial theme.
- Settings schema version 1 and protected systems remain unchanged.
- VS-3 has not started.
- Baseline: `ZinCelestial-BuddyX-v1.8.5.7-Build-9-Semantic-Dark-Mode-Governance-Corrections-FULL.zip`.


## Build 11 completion record
- Version: 1.8.5.9
- Baseline: ZinCelestial-BuddyX-v1.8.5.8-Build-10-VS-2-Core-Controls-FULL.zip
- VS-2 complete coverage: implemented; staging certification pending.
- VS-3 Feedback, Status, and Communication: implemented; staging certification pending.
- Header sizing, dropdown overlap, hamburger and structural-control corrections: implemented; staging certification pending.
- Protected systems and settings schema version 1: preserved.
- Next milestone: staging certification, then the next approved Visual System milestone without scope expansion.


## Build 12 completion record
- Version: 1.8.6.0
- Baseline: ZinCelestial-BuddyX-v1.8.5.9-Build-11-VS-2-VS-3-Complete-Coverage-FULL.zip
- VS-4 Navigation and Application Shells: implemented across the default ZinCelestial theme; staging certification pending.
- Covered headers, search, account and utility menus, nested menus, tabs, breadcrumbs, pagination, dropdowns, side-menu surfaces and mobile navigation.
- Covered active, current, expanded, collapsed, pinned, scrolling, open, closed and responsive states.
- Preserved protected systems, settings schema version 1 and Build 11 VS-2/VS-3 coverage.
- Next milestone after certification: VS-5 Cards, Lists, Tables, and Data Displays.


## Build 13 completion record
- Version: 1.8.6.1
- Baseline: ZinCelestial-BuddyX-v1.8.6.0-Build-12-VS-4-Navigation-Application-Shells-FULL.zip
- VS-5 Cards, Lists, Tables, and Data Displays: implemented across the default ZinCelestial theme; staging certification pending.
- Cards: hero, action, feature, product/media-ready, profile, group, promotional, quote, and informational foundations.
- Lists and tables: activity, metadata, inbox, selectable, sorting, filtering, actions, statuses, responsive overflow, loading, empty, and error states.
- Data displays: statistics, progress, chart/legend surfaces, calendar/date picker, avatar groups, and steppers.
- Next milestone after certification: VS-6 WordPress and Community Integration.


## Build 14 completion record
- Version: 1.8.6.2
- Baseline: ZinCelestial-BuddyX-v1.8.6.1-Build-13-VS-5-Cards-Lists-Tables-Data-Displays-FULL.zip
- VS-6 WordPress and Community Integration: implemented across the default ZinCelestial theme; staging certification pending.
- WordPress, BuddyPress, community extension, and bbPress presentation mappings added without replacing native hooks, permissions, semantics, workflows, or data ownership.
- VS-2 through VS-5 coverage, protected systems, schema version 1, Customizer authority, and platform asset separation preserved.
- Next milestone after certification: VS-7 WooCommerce and Marketplace Integration.


## Build 15 completion record
- Version: 1.8.6.3
- Baseline: ZinCelestial-BuddyX-v1.8.6.2-Build-14-VS-6-WordPress-Community-Integration-FULL.zip
- VS-7 WooCommerce and Marketplace Integration implemented across the default theme; staging certification pending.
- Product, cart, checkout, account, order, refund, vendor, currency, points and payment presentation covered without taking ownership of commerce data or workflows.
- Next milestone after certification: VS-8 Extended Page-System Integration.


## Build 16 completion record
- Version: 1.8.6.4
- Baseline: ZinCelestial-BuddyX-v1.8.6.3-Build-15-VS-7-WooCommerce-Marketplace-Integration-FULL.zip
- VS-8 Extended Page-System Integration implemented across the default theme; staging certification pending.
- Support, legal, recipes, aliases, businesses, galleries, polls and Community Experience page surfaces covered.
- Next milestone after certification: VS-9 Visual Certification and Release Governance.

## Build 17 implementation record
- Version: 1.8.6.5
- Baseline: ZinCelestial-BuddyX-v1.8.6.4-Build-16-VS-8-Extended-Page-System-Integration-FULL.zip
- VS-9 certification matrix, visual QA criteria, staging checklist, and release-promotion governance implemented.
- VS-2 through VS-8 remain implemented but are not yet visually certified.
- Release decision remains HOLD until all visual, accessibility, responsive, reduced-motion, integration, and explicit packaging-approval gates pass.
- Explicit packaging approval received for the complete Build 17 staging-candidate ZIP; promotion remains blocked pending certification.

## Build 18 implementation record
- Version: 1.8.6.6
- Baseline: ZinCelestial-BuddyX-v1.8.6.5-Build-17-VS-9-Visual-Certification-Release-Governance-FULL.zip
- VS-10 design-token policy, component mapping, integration alias rules, exception register, and visual QA lock implemented.
- VS-2 through VS-8 remain implemented and token mapped; staging certification remains pending.
- VS-9 release governance remains active.
- Promotion remains blocked until token audit, documented exceptions, visual evidence, accessibility, responsive, reduced-motion, integration, PHP, and approval gates pass.
- Explicit packaging approval received for the complete Build 18 staging-candidate ZIP; promotion remains blocked pending audit reconciliation and certification.



## Build 19 implementation record

- Version: 1.8.6.7.
- Milestone: VS-10 audit reconciliation and certification readiness.
- Source package: `ZinCelestial-BuddyX-v1.8.6.6-Build-18-VS-10-Token-Usage-Component-Mapping-Visual-QA-Lock-FULL.zip`.
- Added static audit reconciliation, certification-readiness documentation, Build 19 checklist, and Build 19 validation report.
- Preserved all approved Visual System coverage, protected systems, settings schema 1, Customizer authority, and platform asset separation.
- No VS-11 milestone was invented or started.
- Promotion remains blocked pending live visual, accessibility, responsive, reduced-motion, integration, PHP CLI, and user-approval gates.


## Build 20 implementation record

- Version: 1.8.6.8.
- Milestone: VS-10 staging certification execution kit.
- Source package: `ZinCelestial-BuddyX-v1.8.6.7-Build-19-VS-10-Audit-Reconciliation-Certification-Readiness-FULL.zip`.
- Added the staging execution order, evidence index, defect template, checklist, and validation report.
- Preserved all approved runtime systems and Visual System coverage without scope expansion.
- No VS-11 milestone was introduced or started.
- Build 16 remains the approved stable baseline until live certification and explicit promotion approval are complete.


## Build 21 implementation record

- Version: 1.8.6.9.
- Milestone: VS-10 certification traceability and promotion decision controls.
- Source package: `ZinCelestial-BuddyX-v1.8.6.8-Build-20-VS-10-Staging-Certification-Execution-Kit-FULL.zip`.
- Added gate-to-evidence traceability, promotion decisions, rollback rehearsal, and defect triage governance.
- Preserved all approved runtime scope, Visual System coverage, protected systems, schema 1, Customizer authority, and platform asset separation.
- No VS-11 milestone was introduced or started.
- Build 16 remains the approved stable baseline. Promotion remains on hold until every live gate passes and explicit approval is recorded.

## Build 22 implementation record

- Package: `ZinCelestial-BuddyX-v1.8.7.0-Build-22-Stage-1-Customizer-Integration-Staging-Candidate-FULL.zip`
- Scope: Stage 1 Customizer integration and staging handoff.
- Static implementation: complete.
- Static validation: passed.
- Live WordPress staging validation: pending.
- Promotion status: staging candidate only.
- Stable baseline remains unchanged pending staging approval.
- Stage 2 was not started.



## Build 25 implementation record

- Version: 1.8.7.3.
- Baseline: ZinCelestial-BuddyX-v1.8.7.2-Build-24-Shared-Label-Customizer-Verification-FULL.zip.
- Scope: Stage 2 Customizer Certification Kit.
- Certification matrix and live evidence record added.
- Live WordPress staging certification remains pending.
- Stage 3 Selective Live Preview was not started.
- Promotion decision remains HOLD.


## Build 26 implementation record

- Version: 1.8.7.4.
- Stage: Stage 2 Semantic Customizer Controls.
- Added native color-picker controls when a setting carries a color value.
- Added synchronized range sliders and precise numeric fields for bounded numbers.
- Retained checkboxes, selects, media selectors, text inputs, existing setting IDs, defaults, sanitizers, fallbacks, and settings schema version 1.
- Added responsive Customizer control styling and keyboard-visible focus.
- No existing roadmap item was removed or replaced.
- Stage 3 remains blocked until Stage 2 passes live WordPress staging certification and receives promotion approval.


## Build 27 correction record

- Version: 1.8.7.5.
- Corrected the Build 26 Customizer fatal caused by a duplicate `OptionRegistry::is_color()` method declaration.
- Preserved Stage 2 semantic controls and all existing roadmap scope.
- Stage 3 remains blocked pending successful live Stage 2 certification.


## Build 29R.18 Sidebar-System Removal
- Completed removal of the current ZinCelestial Community Layout sidebar system.
- Removed the current BuddyX Site Sidebar Customizer system from ZinCelestial runtime.
- Deferred the replacement unified layout system for later approval.


## Build 29R.20 Members and Groups Layout Cleanup
- Completed Members Directory CSS consolidation.
- Removed obsolete Community Layout width assumptions from Members presentation.
- Added Groups directory responsive containment without redesigning native BuddyPress output.
- Native BuddyX Site Sidebar Customizer remains authoritative.


## Build 29R.21 Member Card Rhythm and Widget Cleanup
- Corrected Compact cover placement and reduced Members Grid card height.
- Added stale region and duplicate widget/language-selector cleanup.
- Preserved native BuddyX sidebar ownership and Groups structure.


## Build 29R.22 Activity Parity and Administration Libraries Foundation
- Restored Member Activity padding/structure parity to News Feed after rollback.
- Added the shared ZinCelestial Administration Libraries area.
- Element Library, Component Library, and Signature Icon Library are housed together.
- Signature Icon Library foundation started; schema version 1 and protected systems preserved.


## Build 29R.23 Signature Icon Registry
- Completed the first functional Signature Icon Registry milestone.
- Added accessible registry rendering, categories, search/filtering, fallback behavior, and extension hooks.
- Kept all three libraries together inside ZinCelestial Administration.


## Build 29R.24 Signature Icon Runtime Integration
- Connected the Signature Icon Registry to frontend shortcode rendering and matching ZinCelestial Administration navigation.
- Added accessible runtime options and reduced-motion-aware styling.
- Preserved shared Administration Libraries placement and protected systems.


## Build 29R.25 Profile Menu Signature Icons
- Integrated registry icons into supported BuddyPress profile-navigation contexts.
- Retained custom administrator icon-image priority and existing profile-menu behavior.
- Preserved all shared library placement and protected systems.


## Build 29R.26 Signature Icon Context API
- Added stable aliases, category retrieval, filterable context mapping, and public rendering helpers.
- Added copy-shortcode controls inside the existing Signature Icon Library.
- Preserved all shared library placement and protected systems.


## Build 29R.27 Icon Context Matrix and Export
- Added a read-only context-to-icon assignment matrix inside the shared Signature Icon Library.
- Added secure registry JSON export for reuse and auditing.
- Preserved all shared library placement and protected systems.


## Build 29R.28 Signature Icon Diagnostics
- Added read-only registry health checks and system-diagnostics reporting.
- Added missing-target and incomplete-record detection.
- Preserved shared library placement and protected systems.


## Build 29R.29 Signature Icon Preview and Variants
- Added a non-persistent preview playground and approved runtime presentation variants.
- Added generated shortcode copying without adding settings or changing schema version 1.
- Preserved shared library placement and protected systems.


## Build 29R.30 Unified Administration Libraries
- Unified Element Library, Component Library, and Signature Icon Library under one coordinated sub-navigation interface in ZinCelestial Administration.
- Added read-only Element and Component catalogs while retaining all Signature Icon Library functions.
- Preserved settings schema version 1 and protected systems.


## Build 29R.31 Library Layout Containment Fix
- Corrected Signature Icon Library grid containment and responsive wrapping based on supplied live screenshots.
- Separated library tools from icon cards and suppressed Save controls on read-only panels.
- Preserved schema version 1 and protected systems.


## Build 29R.32 Accessibility, Group Icons, and Responsive Audit
- Added core group-navigation Signature Icons.
- Completed static WCAG 2.2 AA-oriented accessibility and responsive audits.
- Added tab semantics, keyboard operation, focus/target/reflow safeguards, and documented remaining live verification.
- Preserved all protected systems and schema version 1.


## Build 29R.33 Accessibility Live-Verification Preparation
- Added stronger screen-reader state handling, roving keyboard focus, copy announcements, and 320 CSS pixel reflow behavior.
- Source verification passed; installed screen-reader, physical keyboard, and browser-rendered 400% zoom execution remain explicitly pending.
- Preserved all protected systems and schema version 1.


## Build 29R.34 Administration Control Structure and Reflow
- Corrected administration field spacing and responsive structure based on supplied live screenshots.
- Added accessible range labels and narrow-width containment while preserving schema version 1.
- Preserved unified libraries, icon systems, activity parity, and native BuddyX sidebars.


## Build 29R.35 Global Field Rows and 400% Zoom
- Applied a single explicit field-row class to every generated administration control.
- Corrected top-level settings rows and completed all-panel 320 CSS pixel source reflow checks.
- Preserved schema version 1 and all protected systems.


## Build 29R.36 Administration Panel Isolation Recovery
- Corrected the all-panels-on-one-page regression.
- Enforced one active top-level Administration panel while preserving independent nested Library tabs.
- Preserved global field rows, schema version 1, and protected systems.


## Build 29R.37 Server-Side Panel Routing Recovery
- Replaced failed form-ancestry panel isolation with explicit panel classes and real server-routed icon links.
- Added validated server-side active-panel rendering and retained JavaScript enhancement.
- Preserved schema version 1 and all protected systems.


## Build 29R.38 Server-Rendered Panel Shell
- Replaced all-panels-in-the-browser architecture with one validated server-rendered panel per request.
- Separated read-only screens from active settings forms while preserving schema version 1.
- Preserved unified Libraries, icon systems, activity parity, Customizer authority, and native BuddyX sidebars.


## Build 29R.39 Icon Preview and Navigation Size Fix
- Restored the Icon Preview Playground display.
- Unified top-level administration icons at 24px in 48px targets.
- Preserved server-rendered panel routing, schema version 1, and protected systems.


## Build 29R.40 Live Variants, 400% Zoom, and Navigation Audit
- Restored visible preview variants by loading shared variant CSS in Administration.
- Audited live preview update paths and unified navigation icons at normal and 400% zoom-equivalent widths.
- Preserved server-rendered routing, schema version 1, and protected systems.


## Build 29R.41 Member Directory Visual Restoration
- Restored approved Member Command, Community Signal, and member-card presentation from supplied visual references.
- Corrected detached covers and restored the stable two-column member grid.
- Preserved schema version 1 and protected systems.


## Build 29R.42 Member and Group Directory Card Restoration

- Status: completed.
- Baseline: ZinCelestial-BuddyX-v1.9.1.8-Build-29R.41-Member-Directory-Visual-Restoration-FULL.zip.
- Restored coordinated Member Directory and Group Directory cards from the supplied visual references.
- Removed the supplied red-circled oversized desktop submenu arrows while preserving mobile navigation.
- Settings schema remains version 1.


## Build 29R.43 Directory Card Final Restoration

- Status: completed.
- Removed all oversized desktop submenu arrows.
- Corrected member and group cards against the supplied final visual references.
- Removed empty lower card panels and unsafe image relocation.
- Settings schema remains version 1.


## Build 29R.44 Audited Directory Card Engine

- Status: completed.
- Replaced three conflicting card engines with one canonical system.
- Added separate member and group adapters and removed the secondary cover mutation path.
- Settings schema remains version 1.


## Build 29R.46 Member Identity and Signature View Controls

- Status: completed.
- Member identity and username now render before GamiPress output.
- Settings schema remains version 1.


## Build 29R.49 Member Directory Runtime Stability

- Version: 1.9.2.6
- Baseline: ZinCelestial-BuddyX-v1.9.2.3-Build-29R.46-Member-Identity-Signature-View-Controls-FULL.7z
- Correct recursive member-card mutation and page hangs.
- Preserve bounded username and decorative-break corrections.


## Build 29R.51 Member Card Final Spacing

- Version: 1.9.2.7
- Baseline: `ZinCelestial-BuddyX-v1.9.2.6-Build-29R.49-Member-Directory-Runtime-Stability-FULL.zip`
- Moved usernames below GamiPress rewards in Member Directory cards.
- Reduced grid-only member-card spacing to 22px.
- Reduced standard member-card inner horizontal padding to 19px per side.
- Compact spacing and padding remain unchanged.
- Current subheader remains in place and may be replaced by a custom subheader in a later approved milestone.


## Build 29R.52 Subheader Removal and GamiPress Card Fit

- Version: 1.9.2.8
- Baseline: `ZinCelestial-BuddyX-v1.9.2.7-Build-29R.51-Member-Card-Final-Spacing-FULL.zip`
- Current frontend subheader removed pending a later custom ZinCelestial replacement.
- Member rewards consolidated into a compact tray.
- Username placed after the complete reward tray through DOM ordering.


## Build 29R.54 Spotlight Refinement and Subheader Filters

- Version: 1.9.3.0
- Baseline: `ZinCelestial-BuddyX-v1.9.2.8-Build-29R.52-Subheader-Removal-GamiPress-Card-Fit-FULL.zip`
- Refined Spotlight view and added BuddyPress-backed search and sorting filters to the custom subheader.


## Build 29R.55 Signature Filter and Friendship Controls

- Version: 1.9.3.1
- Baseline: `ZinCelestial-BuddyX-v1.9.3.0-Build-29R.54-Spotlight-Refinement-Subheader-Filters-FULL.zip`
- Added reset filters and standardized directory filter, view, and friendship actions as 20px ZinCelestial Signature Icons with descriptions.

## Stage 32: Complete ZinCelestial Dark Mode System

### Status
- Future milestone.
- Must not be pulled into Stage 6 or any earlier stage without explicit approval.

### Purpose
Create a complete native ZinCelestial frontend and template dark-mode system that replaces fragmented or inherited dark-mode behavior only after the replacement reaches functional and visual parity.

### Protected migration sequence
1. Inventory every existing dark-mode setting, class, stylesheet, script, cookie, browser-storage key, user preference, hard-coded color, and inherited BuddyX behavior.
2. Build the new ZinCelestial appearance engine alongside the current system while the replacement remains disabled by default.
3. Complete default-theme and supported-template coverage.
4. Migrate compatible saved preferences.
5. Activate the new system through a controlled transition.
6. Remove or disable obsolete dark-mode code only after the new system is active and complete.

### Appearance modes and preference ownership
- Light mode.
- Dark mode.
- Follow-device mode.
- Optional administrator-forced mode.
- Visitor preference stored locally.
- Logged-in member preference.
- Per-site default for WordPress Multisite.
- Controlled network default with permitted site override.
- Server-rendered initial mode to prevent a light-mode flash.
- Safe fallback when JavaScript is unavailable.

### Complete frontend and template coverage
- Site header, primary navigation, secondary navigation, mobile navigation, left and right menus, and footer.
- Posts, pages, archives, search, comments, forms, pagination, sidebars, and widget regions.
- Members, groups, directories, profiles, activity streams, notices, forms, and Command Hubs.
- Supported WooCommerce, membership, login, registration, and account surfaces.
- Loading, empty, success, information, warning, error, disabled, selected, active, current, hover, and focus states.
- Desktop, tablet, and mobile layouts.

### Semantic design-token system
- Page, elevated, card, muted, glass, overlay, input, and interactive surfaces.
- Primary, secondary, muted, inverse, link, heading, and disabled text.
- Border, divider, outline, shadow, focus-ring, accent, icon, and glow values.
- Success, information, warning, error, and neutral status values.
- Shared motion and reduced-motion behavior.
- No page-specific white fallback surfaces in supported dark-mode templates.

### Administration and diagnostics
- Mode enablement and default-mode controls inside the ZinCelestial administration section.
- Network default and site-override controls where permitted.
- Member and visitor override policies.
- Light and dark previews.
- Restore-default controls.
- Legacy dark-mode conflict inventory.
- Token-coverage and unsupported-surface diagnostics.

### Compatibility boundaries
- Preserve the standard WordPress and BuddyX Customizer.
- Do not restart deferred ZinCelestial Customizer ownership work.
- Preserve BuddyPress Nouveau and Legacy behavior.
- Preserve plugin business logic and data ownership.
- Expose documented tokens for plugins, widgets, templates, and later ZinCelestial systems.

### Completion conditions
- Complete supported default-theme and template coverage.
- Correct initial mode without a light flash.
- Working visitor, member, site, and network preference boundaries.
- One semantic light/dark token system.
- No supported-surface white leakage in dark mode.
- Controlled preference migration and rollback-safe retirement of obsolete code.
- Governance records identify everything retained, migrated, replaced, disabled, or removed.

## Stage 33: ZinCelestial Widget Builder and Intelligent Widget Platform

### Status
- Future milestone after Stage 32 unless explicitly reprioritized.
- Must not be pulled into Stage 6 or any earlier stage without explicit approval.

### Purpose
Create a complete widget design, registry, preview, placement, recommendation, and distributed-data platform using the existing ZinCelestial Community Experience Platform, Element Library, Component Library, and Signature Icon Library.

### Architecture and ownership
- `Appearance > Widgets` remains the placement and widget-instance management surface.
- Add a distinct searchable `ZinCelestial Widgets` collection without removing native WordPress blocks or widgets.
- Add `ZinCelestial Administration > Libraries > Widget Builder` for designing, registering, previewing, versioning, importing, exporting, and managing widget definitions.
- Use the existing Signature Icon Library as the only icon source.
- Store durable widget definitions, connections, synchronized records, caches, analytics, credentials, and audit history in an appropriate plugin or platform service so theme changes do not destroy operational data.
- Preserve classic-widget, block-widget, registered-sidebar, Command Hub region, and native WordPress compatibility.

### Central widget registry
Each widget record may define:
- Stable key, title, description, category, version, status, and deprecation state.
- Signature Icon key and accessible fallback label.
- Data source, supported contexts, permissions, dependency checks, and cache policy.
- Display variants, responsive capabilities, light/dark presentation, loading state, empty state, offline state, and error state.
- Placement rules, visibility rules, role and capability rules, site scope, network scope, and external-site scope.

### Widget Builder capabilities
- Widget title, subtitle, icon, header, body, footer, actions, and metadata.
- List, grid, card, ticker, calendar, chart, leaderboard, progress, gallery, and dashboard layouts.
- Real-data source selection, sorting, filtering, item limits, date ranges, image/avatar controls, and links.
- Spacing, sizing, surface, color, glow, opacity, responsive, and light/dark controls.
- Page, post, archive, member, group, site, network, role, membership, and capability conditions.
- Real permitted-data preview, duplicate, revision, rollback, import, export, reset, and presets.

### ZinCelestial Widget categories
- Basic.
- Content and Editorial.
- Members.
- Groups.
- Community and Social.
- Events and Scheduling.
- Gamification.
- Workspace and Productivity.
- Commerce.
- Analytics.
- WordPress Multisite.
- Network Administration.
- Connected External WordPress Sites.
- AI Recommendations.

### ZinCelestial versions of basic widgets
Preserve native alternatives while adding enhanced ZinCelestial versions of Search, Recent Posts, Latest Comments, Categories, Archives, Tags, Pages, Navigation Menu, Calendar, RSS, Text/Custom Content, Media, Social Links, Login/Account, and Site Information widgets.

### Built-in content and community widgets
- Top Comments with Signature Icon, comment-author avatar, and linked source post.
- New Posts and Trending Posts with Signature Icon, thumbnail, and linked title.
- Top 10 Articles, Most Liked Posts, Featured Discussion, Trending Topics, Random Helpful Post, Frequently Asked Questions, Knowledge Base, Recently Updated Documents, Resource Library Preview, Wiki Categories Browser, Quote of the Day, Horoscope, and approved-source Health widgets.
- Group Widget, Member Widget, Group Streak Tracker, Most Active Members This Week, Rising Members, Group Participation Leaderboard, Member Anniversary, Welcome New Members, Haven't Posted Recently Reminder, Group MVP of the Month, Community Health Score, Member Spotlight, Random Member Introduction, Team Recognition Board, Member Achievements, Welcome Committee List, Group Mentors Directory, New Friendship Suggestions, Shared Interests, Volunteer Opportunities, and Community Poll Results.
- Member Spotlight widgets must remain separate from the removed Member Directory Spotlight view.

### Events and scheduling widgets
- Upcoming Group Events, Countdown to Next Event, Birthday Calendar, Staff Duty Schedule, Meeting Schedule Board, RSVP Quick View, Time Zone Converter for Members, Group Holidays Calendar, Weekly Agenda, Attendance Statistics, and general Event widgets.

### Discovery, social, and gallery widgets
- Popular File Downloads, Recently Shared Files, Featured Discussion, Trending Topics, Group Knowledge Base, Frequently Asked Questions, Random Helpful Post, Recently Updated Documents, Resource Library Preview, Wiki Categories Browser, Gallery widgets, File Category Browser, Media Feed, and approved social/community discovery widgets.

### Gamification widgets
- Experience Points Leaderboard, Badge Showcase, Achievement Progress Bar, Group Challenges, Monthly Competition Tracker, Rewards Store Preview, Level Progress Widget, Quest/Mission Board, Contribution Milestones, and Activity Streak Calendar.

### Workspace and productivity widgets
- Open Tasks, Quick Notes Board, Group Goals Progress, Project Timeline, Recent Decisions Log, Action Items Tracker, Team Availability Status, Group Announcements Ticker, Poll of the Day, and Quick Links Dashboard.

### Commerce widgets
- WooCommerce products, featured products, recent products, popular products, on-sale products, cart preview, order-status summary, member purchase summary, group store preview, vendor preview, and later ZinCart integrations.
- Commerce widgets consume durable commerce services and do not store transaction ownership in the theme.

### BuddyPress analytics widgets
- Member analytics, group analytics, new members, active members, posts and activity this week, engagement trends, group growth, participation distribution, event attendance, content performance, and privacy-aware community summaries.
- Analytics must use real data, enforce permissions, and never expose private member or group information.

### WordPress Multisite widgets
- Network Sites Directory, My Sites, Featured Sites, Recently Active Sites, Newly Created Sites, Most Active Sites, Site Memberships, Site Administrators, Cross-Site Recent Posts, Cross-Site Trending Posts, Cross-Site Popular Articles, Cross-Site Latest Comments, Network Categories and Topics, Site Activity Summary, Site Growth, Site Storage Usage, Site Media Usage, Site User Count, Site Content Count, Site Health Status, Site Update Status, Site Theme Status, Site Plugin Status, Site Visibility Status, Site Registration Status, Network Announcements, Network Quick Links, Network Search, Network Events, Network Polls, and Network Statistics.

### Network administration widgets
- Network Command Center, Network Health Summary, Sites Requiring Attention, Inactive Sites, Suspended or Archived Sites, User Registration Trends, Network User Growth, Network Activity Trends, Network Storage Overview, Plugin Update Summary, Theme Update Summary, Security Notice Summary, Moderation Queue Summary, Support Request Summary, Network Task Summary, Network Event Schedule, Network Commerce Summary, Network Vendor Summary, Network Membership Summary, Network Analytics Dashboard, Cross-Site Error Summary, Integration Status, External Connection Health, Scheduled Jobs Status, Backup Status, and Network Audit Activity.
- Sensitive network widgets require explicit network capabilities.

### Connected external WordPress-site widgets
- Connected Sites Directory, External Site Status, External Recent Posts, External Featured Posts, External Trending Posts, External Latest Comments, External Categories, External Events, External Products, External Vendors, External Members, External Groups, External Activity Summary, External Site Statistics, External Site Health Summary, External Update Status, External Media Feed, External File Library, External Knowledge Base, External Announcements, External Network News, External Search Results, External Analytics Summary, External Moderation Summary, and External Connection Health.

### Connected-site registry and external integration boundaries
- Register approved standalone WordPress sites and approved external WordPress Multisite installations.
- Store site name, URL, unique connection identifier, site type, enabled data sources, authentication method, allowed endpoints, permission scope, cache duration, health, last successful contact, last error, retention policy, disconnect control, and Signature Icon.
- Use HTTPS, revocable credentials, minimum required capabilities, endpoint allowlists, request timeouts, rate limits, caching, failure backoff, normalized responses, sanitized rendering, diagnostics, manual reconnect, credential rotation, and audit records.
- Attribute remote content to its source site.
- Stop new retrieval after disconnection while preserving required audit history.
- Do not copy remote content permanently unless synchronization is explicitly enabled.

### Distributed widget controls
- One site, selected sites, all permitted sites, site-local, network-wide, or connected-external scope.
- Include/exclude rules, content type, date range, item limit, sort order, source-site badge, site name, favicon, thumbnail, avatar, metadata, cache duration, and offline/stale-data behavior.
- List, grid, ticker, chart, calendar, leaderboard, and dashboard layouts.
- Desktop, tablet, mobile, light, and dark previews.

### Five flagship ZinCelestial widgets
1. Group Command Center: announcements, activity summary, upcoming events, quick actions, and permission-aware member/moderator views.
2. Member Spotlight and Recognition: featured member, achievements, badges, anniversaries, and contribution summary.
3. Community Health Dashboard: new members, active members, content/activity totals, participation trends, and explainable engagement scoring.
4. Knowledge Hub: featured resources, FAQs, recent documents, helpful links, search, and category filtering.
5. Group Goals and Progress: milestones, progress bars, upcoming objectives, completion tracking, and related updates.

### Opt-in AI Widget Assistant
- Review only permitted site structure, public or authorized data summaries, registered widget regions, available plugins/components, and enabled connected sites.
- Suggest widgets for home pages, posts, archives, directories, profiles, groups, activity, events, stores, subsites, network dashboards, and connected external sites.
- Explain each recommendation and suggest placement, size, variant, title, accessible label, light/dark presentation, and Signature Icon.
- Detect duplicates, missing permissions, unavailable data, and low-value placements.
- Create draft widget definitions and previews only.
- Require explicit administrator approval before publishing or placement.
- No silent connection, publishing, placement, network-wide changes, private-message scanning, personal profiling, fabricated analytics, or unrestricted external access.

### Suggested delivery sequence
1. Registry and Appearance separation.
2. Widget Builder foundation.
3. Enhanced basic widgets.
4. Member and Group widgets.
5. Content and Discovery widgets.
6. Events and Scheduling widgets.
7. Gamification and Productivity widgets.
8. WooCommerce widgets.
9. WordPress Multisite widgets.
10. Network Administration widgets.
11. Connected External WordPress-site registry and widgets.
12. Analytics widgets.
13. Five flagship widgets.
14. AI Widget Assistant.
15. Final Stage 33 reconciliation.

### Completion conditions
- Native widgets and blocks remain available.
- ZinCelestial widgets are separately discoverable and use the shared registry and Signature Icon Library.
- Builder, preview, placement, import/export, permissions, responsive, and light/dark systems are operational.
- Real-data Multisite, Network, and connected external WordPress widgets enforce source attribution and permissions.
- AI assistance is opt-in, draft-first, explainable, and approval-gated.
- Durable data and credentials remain outside disposable theme presentation code.
- Governance records completed, deferred, unsupported, and protected items without removing prior roadmap scope.

