<?php
namespace ZinCelestial\BuddyX\Admin;

defined( 'ABSPATH' ) || exit;

use ZinCelestial\BuddyX\DesignSystem\SignatureIconRegistry;

final class NavigationIconControls {
    private const META = '_zcbx_signature_icon_';
    private const PLACEMENTS = array( 'before','after','above','below','icon-only' );
    private const VARIANTS = array( 'plain','badge','glow','button' );
    private const STATES = array( 'inherit','accent','muted' );
    private const PRESETS = array(
        'balanced' => array( 'size'=>20,'gap'=>7,'variant'=>'plain','opacity'=>100,'glow'=>0 ),
        'compact'  => array( 'size'=>16,'gap'=>5,'variant'=>'plain','opacity'=>90,'glow'=>0 ),
        'command'  => array( 'size'=>22,'gap'=>8,'variant'=>'badge','opacity'=>100,'glow'=>25 ),
        'neon'     => array( 'size'=>22,'gap'=>8,'variant'=>'glow','opacity'=>100,'glow'=>60 ),
    );

    public static function register(): void {
        add_action( 'wp_nav_menu_item_custom_fields', array( self::class, 'fields' ), 10, 5 );
        add_action( 'wp_update_nav_menu_item', array( self::class, 'save' ), 10, 2 );
        add_filter( 'nav_menu_item_title', array( self::class, 'render_title' ), 20, 4 );
        add_filter( 'nav_menu_css_class', array( self::class, 'classes' ), 20, 4 );
        add_filter( 'nav_menu_link_attributes', array( self::class, 'link_attributes' ), 20, 4 );
        add_action( 'wp_enqueue_scripts', array( self::class, 'enqueue' ), 40 );
        add_action( 'admin_enqueue_scripts', array( self::class, 'admin_enqueue' ) );
    }
    private static function meta( int $id, string $key, $default='' ) { $v=get_post_meta($id,self::META.$key,true); return ''===$v?$default:$v; }
    private static function icons(): array { $icons=SignatureIconRegistry::icons(); uasort($icons,static fn($a,$b)=>strcasecmp($a['label']??'',$b['label']??'')); return $icons; }
    public static function fields( int $item_id, $item, int $depth, $args, int $current_object_id ): void {
        $v=array(
            'icon'=>(string)self::meta($item_id,'icon'), 'placement'=>(string)self::meta($item_id,'placement','before'),
            'size'=>(int)self::meta($item_id,'size',20), 'gap'=>(int)self::meta($item_id,'gap',7),
            'variant'=>(string)self::meta($item_id,'variant','plain'), 'color'=>(string)self::meta($item_id,'color',''),
            'opacity'=>(int)self::meta($item_id,'opacity',100), 'glow'=>(int)self::meta($item_id,'glow',0),
            'mobile'=>(string)self::meta($item_id,'mobile','show'), 'state'=>(string)self::meta($item_id,'state','inherit'),
            'align'=>(string)self::meta($item_id,'align','center'),
        );
        ?>
        <div class="zcbx-nav-icon-fields" data-menu-item="<?php echo esc_attr($item_id); ?>">
          <p class="description description-wide"><strong><?php esc_html_e('ZinCelestial Navigation Icon','zincelestial-buddyx'); ?></strong><br><?php esc_html_e('Connected to the Signature Icon Library and Playground.','zincelestial-buddyx'); ?></p>
          <p class="description description-wide"><label><?php esc_html_e('Signature Icon','zincelestial-buddyx'); ?><select class="widefat zcbx-nav-icon-key" name="menu-item-zcbx-icon[<?php echo esc_attr($item_id); ?>]"><option value=""><?php esc_html_e('No Signature Icon','zincelestial-buddyx'); ?></option><?php foreach(self::icons() as $key=>$icon): ?><option value="<?php echo esc_attr($key); ?>" <?php selected($v['icon'],$key); ?>><?php echo esc_html($icon['label']??$key); ?></option><?php endforeach; ?></select></label></p>
          <div class="zcbx-nav-icon-grid">
          <?php self::select($item_id,'placement','Placement',array('before'=>'Before label','after'=>'After label','above'=>'Above label','below'=>'Below label','icon-only'=>'Icon only'),$v['placement']); ?>
          <?php self::select($item_id,'variant','Variant',array('plain'=>'Plain','badge'=>'Badge','glow'=>'Glow','button'=>'Button'),$v['variant']); ?>
          <?php self::number($item_id,'size','Size (px)',$v['size'],12,48); self::number($item_id,'gap','Spacing (px)',$v['gap'],0,24); ?>
          <?php self::number($item_id,'opacity','Opacity (%)',$v['opacity'],20,100); self::number($item_id,'glow','Glow (%)',$v['glow'],0,100); ?>
          <?php self::select($item_id,'align','Alignment',array('start'=>'Start','center'=>'Center','end'=>'End'),$v['align']); ?>
          <?php self::select($item_id,'mobile','Mobile visibility',array('show'=>'Show icon and label','icon'=>'Icon only','label'=>'Label only','hide'=>'Hide item'),$v['mobile']); ?>
          <?php self::select($item_id,'state','Interaction color',array('inherit'=>'Inherit menu color','accent'=>'ZinCelestial accent','muted'=>'Muted until hover'),$v['state']); ?>
          <p class="description"><label>Custom color <input type="color" name="menu-item-zcbx-color[<?php echo esc_attr($item_id); ?>]" value="<?php echo esc_attr(preg_match('/^#[0-9a-fA-F]{6}$/',$v['color'])?$v['color']:'#5546d8'); ?>"><span class="screen-reader-text">Optional custom icon color</span></label></p>
          </div>
          <p class="description description-wide zcbx-nav-icon-actions"><button type="button" class="button zcbx-nav-apply-playground"><?php esc_html_e('Apply Playground preset','zincelestial-buddyx'); ?></button><button type="button" class="button zcbx-nav-clear-icon"><?php esc_html_e('Clear icon','zincelestial-buddyx'); ?></button></p>
        </div><?php
    }
    private static function select($id,$key,$label,$options,$value):void { echo '<p class="description"><label>'.esc_html($label).'<select class="widefat zcbx-nav-'.$key.'" name="menu-item-zcbx-'.$key.'['.esc_attr($id).']">'; foreach($options as $k=>$l) echo '<option value="'.esc_attr($k).'" '.selected($value,$k,false).'>'.esc_html($l).'</option>'; echo '</select></label></p>'; }
    private static function number($id,$key,$label,$value,$min,$max):void { echo '<p class="description"><label>'.esc_html($label).'<input class="widefat zcbx-nav-'.$key.'" type="number" min="'.$min.'" max="'.$max.'" name="menu-item-zcbx-'.$key.'['.esc_attr($id).']" value="'.esc_attr($value).'"></label></p>'; }
    public static function save( int $menu_id, int $item_id ): void {
        if(!current_user_can('edit_theme_options')) return;
        $defs=array('icon'=>'','placement'=>'before','size'=>20,'gap'=>7,'variant'=>'plain','color'=>'','opacity'=>100,'glow'=>0,'mobile'=>'show','state'=>'inherit','align'=>'center');
        foreach($defs as $key=>$default){ $input=$_POST['menu-item-zcbx-'.$key][$item_id]??$default; $input=wp_unslash($input); if(in_array($key,array('size','gap','opacity','glow'),true)){ $ranges=array('size'=>array(12,48),'gap'=>array(0,24),'opacity'=>array(20,100),'glow'=>array(0,100)); $value=max($ranges[$key][0],min($ranges[$key][1],absint($input))); } elseif('color'===$key){$value=sanitize_hex_color($input)?:'';} else {$value=sanitize_key($input);} update_post_meta($item_id,self::META.$key,$value); }
    }
    private static function config(int $id):array { return array('icon'=>(string)self::meta($id,'icon'),'placement'=>(string)self::meta($id,'placement','before'),'size'=>(int)self::meta($id,'size',20),'gap'=>(int)self::meta($id,'gap',7),'variant'=>(string)self::meta($id,'variant','plain'),'color'=>(string)self::meta($id,'color'),'opacity'=>(int)self::meta($id,'opacity',100),'glow'=>(int)self::meta($id,'glow',0),'mobile'=>(string)self::meta($id,'mobile','show'),'state'=>(string)self::meta($id,'state','inherit'),'align'=>(string)self::meta($id,'align','center')); }
    public static function render_title( string $title, $item, $args, int $depth ): string {
        $c=self::config((int)$item->ID); if(!$c['icon']||!isset(self::icons()[$c['icon']])) return $title;
        $svg=SignatureIconRegistry::render($c['icon']); if(!$svg) return $title;
        $icon='<span class="zcbx-nav-signature-icon zcbx-signature-icon-wrap--'.esc_attr($c['variant']).'" aria-hidden="true">'.$svg.'</span>';
        $safe='<span class="zcbx-nav-label">'.$title.'</span>';
        if('icon-only'===$c['placement']) return $icon.'<span class="screen-reader-text">'.wp_strip_all_tags($title).'</span>';
        return in_array($c['placement'],array('after','below'),true)?$safe.$icon:$icon.$safe;
    }
    public static function classes(array $classes,$item,$args,int $depth):array { $c=self::config((int)$item->ID); if(!$c['icon']) return $classes; foreach(array('zcbx-nav-has-signature-icon','zcbx-nav-icon-'.$c['placement'],'zcbx-nav-mobile-'.$c['mobile'],'zcbx-nav-state-'.$c['state'],'zcbx-nav-align-'.$c['align']) as $x)$classes[]=$x; return array_unique($classes); }
    public static function link_attributes(array $atts,$item,$args,$depth):array { $c=self::config((int)$item->ID); if(!$c['icon']) return $atts; $style='--zcbx-nav-icon-size:'.max(12,min(48,$c['size'])).'px;--zcbx-nav-icon-gap:'.max(0,min(24,$c['gap'])).'px;--zcbx-nav-icon-opacity:'.max(20,min(100,$c['opacity']))/100 .';--zcbx-nav-icon-glow:'.max(0,min(100,$c['glow']))/10 .'px;'; if($c['color'])$style.='--zcbx-nav-icon-color:'.esc_attr($c['color']).';'; $atts['style']=trim(($atts['style']??'').$style); return $atts; }
    public static function enqueue():void { wp_enqueue_style('zcbx-navigation-icon-controls',get_stylesheet_directory_uri().'/assets/navigation-icon-controls.css',array('zcbx-signature-icons'),ZCBX_VERSION); }
    public static function admin_enqueue(string $hook):void { if('nav-menus.php'!==$hook)return; wp_enqueue_script('zcbx-navigation-icon-controls-admin',get_stylesheet_directory_uri().'/assets/navigation-icon-controls-admin.js',array('jquery'),ZCBX_VERSION,true); wp_add_inline_script('zcbx-navigation-icon-controls-admin','window.ZCBX_NAV_ICON_PRESETS='.wp_json_encode(self::PRESETS).';','before'); }
}
