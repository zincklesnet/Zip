<?php
namespace ZinCelestial\BuddyX\Admin;
defined( 'ABSPATH' ) || exit;

final class AdvancedSideMenusPage {
    private const OPTION = 'zcbx_advanced_side_menus';
    private const PRESETS = array( 'expanded'=>'Expanded Panel', 'compact'=>'Compact Icon Rail', 'expandable'=>'Expandable Rail', 'floating'=>'Floating Utility Dock', 'glass'=>'Command Glass Panel' );
    public static function register(): void {
        add_action( 'admin_menu', array( self::class, 'menu' ), 40 );
        add_action( 'admin_post_zcbx_save_advanced_side_menus', array( self::class, 'save' ) );
    }
    public static function menu(): void {
        add_theme_page( __( 'Advanced Side Menus', 'zincelestial-buddyx' ), __( 'Advanced Side Menus', 'zincelestial-buddyx' ), 'edit_theme_options', 'zcbx-advanced-side-menus', array( self::class, 'render' ) );
    }
    public static function defaults(): array {
        $side = array( 'enabled'=>1,'preset'=>'expanded','width'=>320,'rail_width'=>82,'position'=>'center','default_state'=>'closed','display_mode'=>'overlay','trigger_icon'=>'hamburger','background'=>'#121222','text'=>'#f5f3ff','accent'=>'#70f3dc','border'=>'#4c4966','separator'=>'#3b3950','hover_background'=>'#243447','hover_text'=>'#ffffff','hover_icon'=>'#70f3dc','hover_border'=>'#70f3dc','hover_radius'=>12,'hover_effect'=>'lift','hover_transition'=>180,'hover_glow'=>0,'hide_controls_open'=>1,'allow_page_scroll'=>1,'trigger_offset'=>64,'trigger_preset'=>'rounded','close_scale'=>'adaptive','popup_enabled'=>1,'popup_position'=>'auto','popup_style'=>'glass','popup_font_size'=>14,'popup_width'=>220,'popup_padding'=>12,'popup_radius'=>14,'popup_opacity'=>92,'popup_blur'=>16,'popup_delay'=>180,'popup_text'=>'#ffffff','popup_background'=>'#121222','popup_border'=>'#70f3dc','opacity'=>96,'blur'=>18,'radius'=>20,'shadow'=>1,'glow'=>0,'header_enabled'=>1,'header_title'=>'','header_shortcode'=>'','footer_enabled'=>0,'footer_text'=>'','footer_shortcode'=>'','separators'=>1,'close_on_select'=>0,'remember_state'=>1,'desktop'=>1,'tablet'=>1,'mobile'=>1 );
        return array( 'left'=>$side, 'right'=>$side );
    }
    public static function get(): array { return wp_parse_args( (array) get_option( self::OPTION, array() ), self::defaults() ); }
    private static function sanitize_side( array $in ): array {
        $d=self::defaults()['left']; $o=$d;
        foreach(array('enabled','shadow','glow','header_enabled','footer_enabled','separators','close_on_select','remember_state','desktop','tablet','mobile','hover_glow','hide_controls_open','allow_page_scroll','popup_enabled') as $k)$o[$k]=empty($in[$k])?0:1;
        $choices=array('preset'=>array_keys(self::PRESETS),'position'=>array('top','center','bottom'),'default_state'=>array('closed','expanded','compact'),'display_mode'=>array('overlay','push','floating'),'trigger_icon'=>array('hamburger','dots','arrow','grid','command'),'hover_effect'=>array('none','fill','lift','slide','underline','glow'),'trigger_preset'=>array('rounded','square','pill','glass','minimal'),'close_scale'=>array('fixed','adaptive','compact'),'popup_position'=>array('auto','top','right','bottom','left'),'popup_style'=>array('minimal','card','glass','neon','solid'));
        foreach($choices as $k=>$allowed){$v=sanitize_key((string)($in[$k]??$d[$k]));$o[$k]=in_array($v,$allowed,true)?$v:$d[$k];}
        foreach(array('width'=>array(240,520),'rail_width'=>array(64,120),'opacity'=>array(20,100),'blur'=>array(0,40),'radius'=>array(0,36),'hover_radius'=>array(0,36),'hover_transition'=>array(0,600),'trigger_offset'=>array(0,240),'popup_font_size'=>array(10,28),'popup_width'=>array(120,420),'popup_padding'=>array(4,32),'popup_radius'=>array(0,40),'popup_opacity'=>array(20,100),'popup_blur'=>array(0,40),'popup_delay'=>array(0,1200)) as $k=>$range)$o[$k]=max($range[0],min($range[1],absint($in[$k]??$d[$k])));
        foreach(array('background','text','accent','border','separator','hover_background','hover_text','hover_icon','hover_border','popup_text','popup_background','popup_border') as $k)$o[$k]=sanitize_hex_color((string)($in[$k]??$d[$k]))?:$d[$k];
        $o['header_title']=sanitize_text_field((string)($in['header_title']??''));$o['footer_text']=sanitize_text_field((string)($in['footer_text']??''));
        $o['header_shortcode']=sanitize_textarea_field((string)($in['header_shortcode']??''));$o['footer_shortcode']=sanitize_textarea_field((string)($in['footer_shortcode']??''));
        return $o;
    }
    public static function save(): void {
        if(!current_user_can('edit_theme_options'))wp_die(esc_html__('Access denied.','zincelestial-buddyx'));
        check_admin_referer('zcbx_save_advanced_side_menus');
        $raw=(array)($_POST['zcbx_advanced_side_menus']??array());
        update_option(self::OPTION,array('left'=>self::sanitize_side((array)($raw['left']??array())),'right'=>self::sanitize_side((array)($raw['right']??array()))),false);
        wp_safe_redirect(add_query_arg(array('page'=>'zcbx-advanced-side-menus','updated'=>'1'),admin_url('themes.php')));exit;
    }
    private static function field( string $side, string $key, string $label, string $type, $value, array $options=array() ): void {
        $name='zcbx_advanced_side_menus['.$side.']['.$key.']'; echo '<label class="zcbx-asm-field"><span>'.esc_html($label).'</span>';
        if('checkbox'===$type)echo '<input type="checkbox" name="'.esc_attr($name).'" value="1" '.checked(!empty($value),true,false).'>';
        elseif('select'===$type){echo '<select name="'.esc_attr($name).'">';foreach($options as $v=>$l)echo '<option value="'.esc_attr($v).'" '.selected($value,$v,false).'>'.esc_html($l).'</option>';echo '</select>';}
        elseif('textarea'===$type)echo '<textarea name="'.esc_attr($name).'" rows="2">'.esc_textarea((string)$value).'</textarea>';
        else echo '<input type="'.esc_attr($type).'" name="'.esc_attr($name).'" value="'.esc_attr((string)$value).'">'; echo '</label>';
    }
    private static function panel( string $side, array $s ): void {
        echo '<section class="zcbx-asm-panel"><h2>'.esc_html(ucfirst($side).' Side Menu').'</h2><div class="zcbx-asm-grid">';
        self::field($side,'enabled','Enable this side','checkbox',$s['enabled']); self::field($side,'preset','Style preset','select',$s['preset'],self::PRESETS);
        self::field($side,'width','Expanded width (240–520px)','number',$s['width']); self::field($side,'rail_width','Compact rail width (64–120px)','number',$s['rail_width']);
        self::field($side,'position','Trigger position','select',$s['position'],array('top'=>'Top','center'=>'Center','bottom'=>'Bottom'));self::field($side,'trigger_offset','Trigger top offset px','number',$s['trigger_offset']);self::field($side,'trigger_preset','Trigger preset','select',$s['trigger_preset'],array('rounded'=>'Rounded square','square'=>'Square','pill'=>'Pill','glass'=>'Glass','minimal'=>'Minimal'));self::field($side,'close_scale','Close control sizing','select',$s['close_scale'],array('fixed'=>'Fixed 44px','adaptive'=>'Adaptive to panel width','compact'=>'Compact')); self::field($side,'default_state','Default state','select',$s['default_state'],array('closed'=>'Closed','expanded'=>'Expanded','compact'=>'Compact'));
        self::field($side,'display_mode','Display mode','select',$s['display_mode'],array('overlay'=>'Overlay','push'=>'Push content','floating'=>'Floating')); self::field($side,'trigger_icon','Trigger icon','select',$s['trigger_icon'],array('hamburger'=>'Hamburger','dots'=>'Three dots','arrow'=>'Arrow','grid'=>'Grid','command'=>'Command'));
        foreach(array('background'=>'Background','text'=>'Text','accent'=>'Accent','border'=>'Border','separator'=>'Separator') as $k=>$l)self::field($side,$k,$l,'color',$s[$k]);
        self::field($side,'opacity','Surface opacity %','number',$s['opacity']);self::field($side,'blur','Backdrop blur px','number',$s['blur']);self::field($side,'radius','Corner radius px','number',$s['radius']);
        self::field($side,'hover_effect','Item hover effect','select',$s['hover_effect'],array('none'=>'None','fill'=>'Color fill','lift'=>'Lift','slide'=>'Slide','underline'=>'Underline','glow'=>'Glow'));self::field($side,'hover_background','Hover background','color',$s['hover_background']);self::field($side,'hover_text','Hover text','color',$s['hover_text']);self::field($side,'hover_icon','Hover icon','color',$s['hover_icon']);self::field($side,'hover_border','Hover border','color',$s['hover_border']);self::field($side,'hover_radius','Hover radius px','number',$s['hover_radius']);self::field($side,'hover_transition','Hover transition ms','number',$s['hover_transition']);self::field($side,'popup_enabled','Enable hover popup','checkbox',$s['popup_enabled']);self::field($side,'popup_position','Popup position','select',$s['popup_position'],array('auto'=>'Automatic','top'=>'Top','right'=>'Right','bottom'=>'Bottom','left'=>'Left'));self::field($side,'popup_style','Popup style','select',$s['popup_style'],array('minimal'=>'Minimal tooltip','card'=>'Rounded card','glass'=>'Glass','neon'=>'Neon','solid'=>'Solid'));self::field($side,'popup_font_size','Popup font size px','number',$s['popup_font_size']);self::field($side,'popup_width','Popup width px','number',$s['popup_width']);self::field($side,'popup_padding','Popup padding px','number',$s['popup_padding']);self::field($side,'popup_radius','Popup radius px','number',$s['popup_radius']);self::field($side,'popup_opacity','Popup opacity %','number',$s['popup_opacity']);self::field($side,'popup_blur','Popup blur px','number',$s['popup_blur']);self::field($side,'popup_delay','Popup delay ms','number',$s['popup_delay']);self::field($side,'popup_text','Popup text','color',$s['popup_text']);self::field($side,'popup_background','Popup background','color',$s['popup_background']);self::field($side,'popup_border','Popup border','color',$s['popup_border']);
        foreach(array('shadow'=>'Shadow','glow'=>'Accent glow','separators'=>'Menu separators','close_on_select'=>'Close after menu selection','remember_state'=>'Remember open/closed state','desktop'=>'Show on desktop','tablet'=>'Show on tablet','mobile'=>'Show on mobile','hover_glow'=>'Hover glow','hide_controls_open'=>'Hide trigger and resize controls while open','allow_page_scroll'=>'Allow page scrolling while menu is open') as $k=>$l)self::field($side,$k,$l,'checkbox',$s[$k]);
        self::field($side,'header_enabled','Enable menu header','checkbox',$s['header_enabled']);self::field($side,'header_title','Menu header title','text',$s['header_title']);self::field($side,'header_shortcode','Header shortcode','textarea',$s['header_shortcode']);
        self::field($side,'footer_enabled','Enable menu footer','checkbox',$s['footer_enabled']);self::field($side,'footer_text','Menu footer text','text',$s['footer_text']);self::field($side,'footer_shortcode','Footer shortcode','textarea',$s['footer_shortcode']);
        echo '</div></section>';
    }
    public static function render(): void {
        if(!current_user_can('edit_theme_options'))return;$s=self::get();
        echo '<div class="wrap zcbx-asm-admin"><h1>'.esc_html__('ZinCelestial Advanced Side Menus','zincelestial-buddyx').'</h1><p>'.esc_html__('Configure independent Left and Right menus. Menu links remain assigned in Appearance > Menus.','zincelestial-buddyx').'</p>';
        if(isset($_GET['updated']))echo '<div class="notice notice-success is-dismissible"><p>'.esc_html__('Advanced Side Menu settings saved.','zincelestial-buddyx').'</p></div>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="zcbx_save_advanced_side_menus">';wp_nonce_field('zcbx_save_advanced_side_menus');self::panel('left',$s['left']);self::panel('right',$s['right']);submit_button(__('Save Advanced Side Menu Settings','zincelestial-buddyx'));echo '</form></div>';
        echo '<style>.zcbx-asm-panel{margin:18px 0;padding:20px;border:1px solid #c3c4c7;border-radius:12px;background:#fff}.zcbx-asm-grid{display:grid;grid-template-columns:repeat(2,minmax(260px,1fr));gap:14px 22px}.zcbx-asm-field{display:grid;grid-template-columns:minmax(150px,1fr) minmax(120px,1fr);align-items:center;gap:12px}.zcbx-asm-field input:not([type=checkbox]),.zcbx-asm-field select,.zcbx-asm-field textarea{width:100%}@media(max-width:782px){.zcbx-asm-grid{grid-template-columns:1fr}.zcbx-asm-field{grid-template-columns:1fr}}</style>';
    }
}
