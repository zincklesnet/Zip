<?php
namespace ZinCelestial\BuddyX\Community;
defined( 'ABSPATH' ) || exit;

/** Dedicated boxed site header for Member and Group Command front pages. */
final class CommandPageHeader {
    private static bool $rendered = false;

    public static function register(): void {
        add_action( 'after_setup_theme', array( self::class, 'register_menus' ), 45 );
        add_action( 'bp_after_member_header', array( self::class, 'render_member' ), 10 );
        add_action( 'bp_after_group_header', array( self::class, 'render_group' ), 10 );
        add_action( 'wp_enqueue_scripts', array( self::class, 'assets' ), 65 );
    }

    public static function register_menus(): void {
        register_nav_menus( array(
            'zcbx-command-left'   => __( 'ZinCelestial Command Header: Left', 'zincelestial-buddyx' ),
            'zcbx-command-center' => __( 'ZinCelestial Command Header: Center Main Menu', 'zincelestial-buddyx' ),
            'zcbx-command-right'  => __( 'ZinCelestial Command Header: Right', 'zincelestial-buddyx' ),
        ) );
    }

    private static function member_front(): bool {
        if ( ! function_exists( 'bp_is_user' ) || ! bp_is_user() ) return false;
        if ( function_exists( 'bp_is_user_front' ) ) return (bool) bp_is_user_front();
        $component = function_exists( 'bp_current_component' ) ? (string) bp_current_component() : '';
        return '' === $component || 'front' === $component;
    }

    private static function group_front(): bool {
        if ( ! function_exists( 'bp_is_group' ) || ! bp_is_group() ) return false;
        if ( function_exists( 'bp_is_group_home' ) ) return (bool) bp_is_group_home();
        $action = function_exists( 'bp_current_action' ) ? (string) bp_current_action() : '';
        return '' === $action || 'home' === $action;
    }

    public static function assets(): void {
        if ( ! self::member_front() && ! self::group_front() ) return;
        $path = ZCBX_PATH . 'assets/command-page-header.css';
        wp_enqueue_style( 'zcbx-command-page-header', ZCBX_URL . 'assets/command-page-header.css', array( 'zcbx-command-frontpage-ownership' ), is_readable( $path ) ? (string) filemtime( $path ) : ZCBX_VERSION );
    }

    public static function render_member(): void { if ( self::member_front() ) self::render(); }
    public static function render_group(): void { if ( self::group_front() ) self::render(); }

    private static function menu( string $location, string $class ): void {
        wp_nav_menu( array(
            'theme_location' => $location,
            'container'      => 'nav',
            'container_class'=> $class,
            'menu_class'     => $class . '__menu',
            'fallback_cb'    => false,
            'depth'          => 2,
        ) );
    }

    private static function render(): void {
        if ( self::$rendered ) return;
        self::$rendered = true;
        $logo_id = (int) get_theme_mod( 'custom_logo' );
        $logo = $logo_id ? wp_get_attachment_image( $logo_id, 'full', false, array( 'class'=>'zcbx-command-page-header__logo-image', 'loading'=>'eager', 'decoding'=>'async' ) ) : '';
        $icon = function_exists( 'get_site_icon_url' ) ? (string) get_site_icon_url( 192 ) : '';
        echo '<header class="zcbx-command-page-header" data-zcbx-command-header="29R.82">';
        echo '<div class="zcbx-command-page-header__inner">';
        echo '<section class="zcbx-command-page-header__left" aria-label="' . esc_attr__( 'Command header left section', 'zincelestial-buddyx' ) . '">';
        echo '<a class="zcbx-command-page-header__logo" href="' . esc_url( home_url( '/' ) ) . '" aria-label="' . esc_attr( get_bloginfo( 'name' ) ) . '">';
        if ( $logo ) echo wp_kses_post( $logo ); else echo '<span class="zcbx-command-page-header__site-name">' . esc_html( get_bloginfo( 'name' ) ) . '</span>';
        echo '</a>';
        self::menu( 'zcbx-command-left', 'zcbx-command-menu zcbx-command-menu--left' );
        echo '</section>';
        echo '<section class="zcbx-command-page-header__center" aria-label="' . esc_attr__( 'Command main menu', 'zincelestial-buddyx' ) . '">';
        self::menu( 'zcbx-command-center', 'zcbx-command-menu zcbx-command-menu--center' );
        echo '</section>';
        echo '<section class="zcbx-command-page-header__right" aria-label="' . esc_attr__( 'Command header right section', 'zincelestial-buddyx' ) . '">';
        self::menu( 'zcbx-command-right', 'zcbx-command-menu zcbx-command-menu--right' );
        if ( $icon ) echo '<a class="zcbx-command-page-header__monogram" href="' . esc_url( home_url( '/' ) ) . '" aria-label="' . esc_attr__( 'Site home', 'zincelestial-buddyx' ) . '"><img src="' . esc_url( $icon ) . '" width="48" height="48" alt="" loading="eager" decoding="async"></a>';
        echo '</section>';
        echo '</div></header>';
        do_action( 'zcbx_command_page_header_after' );
    }
}
