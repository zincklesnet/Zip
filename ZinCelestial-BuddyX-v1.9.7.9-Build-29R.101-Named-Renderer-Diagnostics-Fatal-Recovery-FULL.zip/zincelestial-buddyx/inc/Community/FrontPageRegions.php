<?php
namespace ZinCelestial\BuddyX\Community;
defined( 'ABSPATH' ) || exit;

final class FrontPageRegions {
    public static function register(): void {
        add_action( 'widgets_init', array( self::class, 'register_sidebars' ) );
        add_action( 'wp_enqueue_scripts', array( self::class, 'assets' ) );
        add_action( 'zcbx_member_command_hub_after', array( self::class, 'render_member_regions' ), 20 );
        add_action( 'zcbx_group_command_hub_after', array( self::class, 'render_group_regions' ), 20 );
    }

    public static function assets(): void {
        if ( ! self::enabled() ) return;
        $path = ZCBX_PATH . 'assets/command-hub-frontpage-regions.css';
        wp_enqueue_style( 'zcbx-command-hub-frontpage-regions', ZCBX_URL . 'assets/command-hub-frontpage-regions.css', array(), is_readable( $path ) ? (string) filemtime( $path ) : ZCBX_VERSION );
    }

    public static function register_sidebars(): void {
        $common = array(
            'before_widget' => '<section id="%1$s" class="widget %2$s zcbx-command-region__widget">',
            'after_widget'  => '</section>',
            'before_title'  => '<h3 class="zcbx-command-region__title">',
            'after_title'   => '</h3>',
        );
        register_sidebar( array_merge( $common, array(
            'name' => __( 'ZinCelestial Member Command Hub: Primary', 'zincelestial-buddyx' ),
            'id' => 'zcbx-member-command-primary',
            'description' => __( 'Primary member front-page region displayed below the Member Command Hub.', 'zincelestial-buddyx' ),
        ) ) );
        register_sidebar( array_merge( $common, array(
            'name' => __( 'ZinCelestial Member Command Hub: Secondary', 'zincelestial-buddyx' ),
            'id' => 'zcbx-member-command-secondary',
            'description' => __( 'Secondary member front-page region. Empty regions are not rendered.', 'zincelestial-buddyx' ),
        ) ) );
        register_sidebar( array_merge( $common, array(
            'name' => __( 'ZinCelestial Group Command Hub: Primary', 'zincelestial-buddyx' ),
            'id' => 'zcbx-group-command-primary',
            'description' => __( 'Primary group front-page region displayed below the Group Command Hub.', 'zincelestial-buddyx' ),
        ) ) );
        register_sidebar( array_merge( $common, array(
            'name' => __( 'ZinCelestial Group Command Hub: Secondary', 'zincelestial-buddyx' ),
            'id' => 'zcbx-group-command-secondary',
            'description' => __( 'Secondary group front-page region. Empty regions are not rendered.', 'zincelestial-buddyx' ),
        ) ) );
    }

    private static function enabled(): bool {
        $settings = function_exists( 'zcbx_settings' ) ? (array) zcbx_settings() : array();
        return ! empty( $settings['command_hub_frontpage_regions_enabled'] );
    }

    public static function render_member_regions( int $user_id ): void {
        if ( ! self::enabled() ) return;
        self::render( 'member', 'zcbx-member-command-primary', 'zcbx-member-command-secondary', $user_id );
    }

    public static function render_group_regions( int $group_id ): void {
        if ( ! self::enabled() ) return;
        self::render( 'group', 'zcbx-group-command-primary', 'zcbx-group-command-secondary', $group_id );
    }

    private static function render( string $context, string $primary, string $secondary, int $object_id ): void {
        $has_primary = is_active_sidebar( $primary );
        $has_secondary = is_active_sidebar( $secondary );
        if ( ! $has_primary && ! $has_secondary ) return;
        $classes = 'zcbx-command-regions zcbx-command-regions--' . $context;
        if ( $has_primary && $has_secondary ) $classes .= ' zcbx-command-regions--split';
        echo '<section class="' . esc_attr( $classes ) . '" aria-label="' . esc_attr__( 'Command Hub front-page regions', 'zincelestial-buddyx' ) . '">';
        if ( $has_primary ) {
            echo '<div class="zcbx-command-region zcbx-command-region--primary">';
            dynamic_sidebar( $primary );
            echo '</div>';
        }
        if ( $has_secondary ) {
            echo '<aside class="zcbx-command-region zcbx-command-region--secondary">';
            dynamic_sidebar( $secondary );
            echo '</aside>';
        }
        echo '</section>';
        do_action( 'zcbx_command_hub_frontpage_regions_after', $context, $object_id );
    }
}
