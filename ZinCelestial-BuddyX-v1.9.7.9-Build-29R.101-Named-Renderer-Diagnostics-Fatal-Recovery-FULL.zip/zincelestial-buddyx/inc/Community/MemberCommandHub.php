<?php
namespace ZinCelestial\BuddyX\Community;
defined( 'ABSPATH' ) || exit;

/**
 * Stage 6 Member Command Hub foundation.
 *
 * Adds a native-hook overview shell to BuddyPress member front pages. The
 * existing BuddyPress profile navigation and template content remain intact.
 */
final class MemberCommandHub {
    private static bool $rendered = false;

    public static function register(): void {
        add_filter( 'body_class', array( self::class, 'body_classes' ), 45 );
        add_action( 'bp_after_member_header', array( self::class, 'render' ), 20 );
        add_action( 'wp_enqueue_scripts', array( self::class, 'enqueue' ), 45 );
    }

    private static function enabled(): bool {
        $settings = function_exists( 'zcbx_settings' ) ? (array) zcbx_settings() : array();
        return ! empty( $settings['member_command_hub_enabled'] );
    }

    private static function is_member_front(): bool {
        if ( ! self::enabled() || ! function_exists( 'bp_is_user' ) || ! bp_is_user() ) return false;
        if ( function_exists( 'bp_is_user_front' ) ) return (bool) bp_is_user_front();
        $component = function_exists( 'bp_current_component' ) ? (string) bp_current_component() : '';
        return '' === $component || 'front' === $component;
    }

    public static function body_classes( array $classes ): array {
        if ( self::is_member_front() ) $classes[] = 'zcbx-member-command-hub-active';
        return $classes;
    }

    public static function enqueue(): void {
        if ( ! self::enabled() || ! function_exists( 'bp_is_user' ) || ! bp_is_user() ) return;
        $path = ZCBX_PATH . 'assets/member-command-hub.css';
        wp_enqueue_style( 'zcbx-member-command-hub', ZCBX_URL . 'assets/member-command-hub.css', array(), is_readable( $path ) ? (string) filemtime( $path ) : ZCBX_VERSION );
    }

    private static function member_url( string $component = '' ): string {
        $base = function_exists( 'bp_displayed_user_domain' ) ? (string) bp_displayed_user_domain() : '';
        return $component ? trailingslashit( $base . $component ) : $base;
    }

    private static function count_value( string $type, int $user_id ): int {
        if ( 'friends' === $type && function_exists( 'friends_get_total_friend_count' ) ) return (int) friends_get_total_friend_count( $user_id );
        if ( 'groups' === $type && function_exists( 'bp_get_total_group_count_for_user' ) ) return (int) bp_get_total_group_count_for_user( $user_id );
        return 0;
    }

    public static function render(): void {
        if ( self::$rendered || ! self::is_member_front() ) return;
        self::$rendered = true;
        $user_id = function_exists( 'bp_displayed_user_id' ) ? (int) bp_displayed_user_id() : 0;
        $name = function_exists( 'bp_get_displayed_user_fullname' ) ? (string) bp_get_displayed_user_fullname() : '';
        $avatar = function_exists( 'bp_core_fetch_avatar' ) ? bp_core_fetch_avatar( array( 'item_id' => $user_id, 'type' => 'full', 'width' => 128, 'height' => 128, 'html' => true, 'alt' => sprintf( __( 'Profile image for %s', 'zincelestial-buddyx' ), $name ) ) ) : '';
        $last_active = function_exists( 'bp_get_last_activity' ) ? (string) bp_get_last_activity( $user_id ) : '';
        $friends = self::count_value( 'friends', $user_id );
        $groups = self::count_value( 'groups', $user_id );

        echo '<section class="zcbx-member-command-hub" aria-labelledby="zcbx-member-command-hub-title">';
        echo '<div class="zcbx-member-command-hub__identity">';
        if ( $avatar ) echo '<div class="zcbx-member-command-hub__avatar">' . wp_kses_post( $avatar ) . '</div>';
        echo '<div><span class="zcbx-member-command-hub__eyebrow">' . esc_html__( 'Member Command Hub', 'zincelestial-buddyx' ) . '</span>';
        echo '<h2 id="zcbx-member-command-hub-title">' . esc_html( $name ) . '</h2>';
        if ( $last_active ) echo '<p>' . esc_html( $last_active ) . '</p>';
        echo '</div></div>';

        echo '<div class="zcbx-member-command-hub__metrics" aria-label="' . esc_attr__( 'Member overview', 'zincelestial-buddyx' ) . '">';
        echo '<a href="' . esc_url( self::member_url( 'friends' ) ) . '"><strong>' . esc_html( number_format_i18n( $friends ) ) . '</strong><span>' . esc_html__( 'Connections', 'zincelestial-buddyx' ) . '</span></a>';
        echo '<a href="' . esc_url( self::member_url( 'groups' ) ) . '"><strong>' . esc_html( number_format_i18n( $groups ) ) . '</strong><span>' . esc_html__( 'Groups', 'zincelestial-buddyx' ) . '</span></a>';
        echo '<a href="' . esc_url( self::member_url( 'activity' ) ) . '"><strong aria-hidden="true">&#10022;</strong><span>' . esc_html__( 'Activity', 'zincelestial-buddyx' ) . '</span></a>';
        echo '</div>';
        echo '<nav class="zcbx-member-command-hub__actions" aria-label="' . esc_attr__( 'Member command shortcuts', 'zincelestial-buddyx' ) . '">';
        echo '<a href="' . esc_url( self::member_url( 'profile' ) ) . '">' . esc_html__( 'Profile details', 'zincelestial-buddyx' ) . '</a>';
        echo '<a href="' . esc_url( self::member_url( 'activity' ) ) . '">' . esc_html__( 'Recent activity', 'zincelestial-buddyx' ) . '</a>';
        echo '<a href="' . esc_url( self::member_url( 'groups' ) ) . '">' . esc_html__( 'Community groups', 'zincelestial-buddyx' ) . '</a>';
        echo '</nav>';
        echo '</section>';
        do_action( 'zcbx_member_command_hub_after', $user_id );
    }
}
