<?php
namespace ZinCelestial\BuddyX\Community;
defined( 'ABSPATH' ) || exit;

/**
 * Stage 6D Command Hub appearance foundation.
 *
 * Reuses the existing schema-version-1 member/group background and cover
 * settings. No second appearance system or settings store is introduced.
 */
final class CommandHubAppearance {
    public static function register(): void {
        add_action( 'wp_enqueue_scripts', array( self::class, 'enqueue' ), 55 );
    }

    public static function enqueue(): void {
        $settings = function_exists( 'zcbx_settings' ) ? (array) zcbx_settings() : array();
        if ( function_exists( 'bp_is_user' ) && bp_is_user() && ! empty( $settings['member_command_hub_enabled'] ) ) {
            self::add_css( 'zcbx-member-command-hub', '.zcbx-member-command-hub', 'profile', $settings );
        }
        if ( function_exists( 'bp_is_group' ) && bp_is_group() && ! empty( $settings['group_command_hub_enabled'] ) ) {
            self::add_css( 'zcbx-group-command-hub', '.zcbx-group-command-hub', 'group', $settings );
        }
    }

    private static function add_css( string $handle, string $selector, string $context, array $settings ): void {
        $enabled = ! empty( $settings[ $context . '_background_enabled' ] );
        $desktop = esc_url_raw( (string) ( $settings[ $context . '_cover_image' ] ?? '' ) );
        if ( '' === $desktop ) $desktop = esc_url_raw( (string) ( $settings[ $context . '_background_image' ] ?? '' ) );
        $mobile = esc_url_raw( (string) ( $settings[ $context . '_cover_mobile_image' ] ?? '' ) );
        if ( '' === $mobile ) $mobile = esc_url_raw( (string) ( $settings[ $context . '_background_mobile_image' ] ?? '' ) );
        if ( ! $enabled || '' === $desktop ) return;

        $position = sanitize_text_field( (string) ( $settings[ $context . '_cover_image_position' ] ?? $settings[ $context . '_background_position' ] ?? 'center center' ) );
        $repeat = sanitize_key( (string) ( $settings[ $context . '_cover_image_repeat' ] ?? $settings[ $context . '_background_repeat' ] ?? 'no-repeat' ) );
        $fit = sanitize_key( (string) ( $settings[ $context . '_cover_image_fit' ] ?? $settings[ $context . '_background_size' ] ?? 'cover' ) );
        $overlay = sanitize_hex_color( (string) ( $settings[ $context . '_cover_image_overlay' ] ?? $settings[ $context . '_background_overlay' ] ?? '#000000' ) ) ?: '#000000';
        $opacity = (float) ( $settings[ $context . '_cover_image_overlay_opacity' ] ?? $settings[ $context . '_background_overlay_opacity' ] ?? 0 );
        $opacity = max( 0, min( 1, $opacity ) );
        [$r,$g,$b] = self::rgb( $overlay );
        $safe_url = esc_url_raw( $desktop );
        $css = sprintf(
            '%1$s{background-image:linear-gradient(rgba(%2$d,%3$d,%4$d,%5$s),rgba(%2$d,%3$d,%4$d,%5$s)),url("%6$s");background-position:%7$s;background-repeat:%8$s;background-size:%9$s;}',
            $selector, $r, $g, $b, rtrim( rtrim( number_format( $opacity, 2, '.', '' ), '0' ), '.' ), esc_url( $safe_url ), esc_attr( $position ), esc_attr( $repeat ), esc_attr( $fit )
        );
        if ( '' !== $mobile ) {
            $css .= sprintf( '@media(max-width:782px){%1$s{background-image:linear-gradient(rgba(%2$d,%3$d,%4$d,%5$s),rgba(%2$d,%3$d,%4$d,%5$s)),url("%6$s");}}', $selector, $r, $g, $b, rtrim( rtrim( number_format( $opacity, 2, '.', '' ), '0' ), '.' ), esc_url( $mobile ) );
        }
        wp_add_inline_style( $handle, $css );
    }

    private static function rgb( string $hex ): array {
        $hex = ltrim( $hex, '#' );
        if ( 3 === strlen( $hex ) ) $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
        return array( hexdec( substr( $hex, 0, 2 ) ), hexdec( substr( $hex, 2, 2 ) ), hexdec( substr( $hex, 4, 2 ) ) );
    }
}
