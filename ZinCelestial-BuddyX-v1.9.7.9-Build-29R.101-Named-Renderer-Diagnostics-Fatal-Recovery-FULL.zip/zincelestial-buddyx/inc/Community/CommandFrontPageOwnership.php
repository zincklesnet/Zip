<?php
namespace ZinCelestial\BuddyX\Community;
defined( 'ABSPATH' ) || exit;

/**
 * Owns BuddyPress member/group front-page presentation without replacing
 * BuddyPress data, permissions, URLs, actions, navigation, or other screens.
 */
final class CommandFrontPageOwnership {
    private static array $buffers = array();

    public static function register(): void {
        add_filter( 'body_class', array( self::class, 'body_classes' ), 60 );
        add_filter( 'sidebars_widgets', array( self::class, 'frontpage_sidebars' ), PHP_INT_MAX );
        add_action( 'wp_enqueue_scripts', array( self::class, 'assets' ), 60 );

        add_action( 'bp_before_member_header', array( self::class, 'begin_member_header' ), 0 );
        add_action( 'bp_after_member_header', array( self::class, 'end_member_header' ), 0 );
        add_action( 'bp_before_member_body', array( self::class, 'begin_member_body' ), 0 );
        add_action( 'bp_after_member_body', array( self::class, 'end_member_body' ), PHP_INT_MAX );

        add_action( 'bp_before_group_header', array( self::class, 'begin_group_header' ), 0 );
        add_action( 'bp_after_group_header', array( self::class, 'end_group_header' ), 0 );
        add_action( 'bp_before_group_body', array( self::class, 'begin_group_body' ), 0 );
        add_action( 'bp_after_group_body', array( self::class, 'end_group_body' ), PHP_INT_MAX );
    }

    private static function member_front(): bool {
        if ( ! function_exists( 'bp_is_user' ) || ! bp_is_user() ) return false;
        $settings = function_exists( 'zcbx_settings' ) ? (array) zcbx_settings() : array();
        if ( empty( $settings['member_command_hub_enabled'] ) ) return false;
        if ( function_exists( 'bp_is_user_front' ) ) return (bool) bp_is_user_front();
        $component = function_exists( 'bp_current_component' ) ? (string) bp_current_component() : '';
        return '' === $component || 'front' === $component;
    }

    private static function group_front(): bool {
        if ( ! function_exists( 'bp_is_group' ) || ! bp_is_group() ) return false;
        $settings = function_exists( 'zcbx_settings' ) ? (array) zcbx_settings() : array();
        if ( empty( $settings['group_command_hub_enabled'] ) ) return false;
        if ( function_exists( 'bp_is_group_home' ) ) return (bool) bp_is_group_home();
        $action = function_exists( 'bp_current_action' ) ? (string) bp_current_action() : '';
        return '' === $action || 'home' === $action;
    }

    public static function body_classes( array $classes ): array {
        if ( self::member_front() ) $classes[] = 'zcbx-member-command-frontpage-owned';
        if ( self::group_front() ) $classes[] = 'zcbx-group-command-frontpage-owned';
        return $classes;
    }


    /**
     * Remove every non-Command widget area from owned front pages without
     * deleting or moving saved widget assignments.
     */
    public static function frontpage_sidebars( array $sidebars ): array {
        $member = self::member_front();
        $group  = self::group_front();
        if ( ! $member && ! $group ) return $sidebars;

        $allowed = $member
            ? array( 'zcbx-member-command-primary', 'zcbx-member-command-secondary' )
            : array( 'zcbx-group-command-primary', 'zcbx-group-command-secondary' );

        foreach ( $sidebars as $sidebar_id => $widgets ) {
            if ( 'wp_inactive_widgets' === $sidebar_id ) continue;
            if ( ! in_array( (string) $sidebar_id, $allowed, true ) ) {
                $sidebars[ $sidebar_id ] = array();
            }
        }
        return $sidebars;
    }

    public static function assets(): void {
        if ( ! self::member_front() && ! self::group_front() ) return;
        $path = ZCBX_PATH . 'assets/command-frontpage-ownership.css';
        wp_enqueue_style( 'zcbx-command-frontpage-ownership', ZCBX_URL . 'assets/command-frontpage-ownership.css', array(), is_readable( $path ) ? (string) filemtime( $path ) : ZCBX_VERSION );
    }

    private static function begin( string $key ): void {
        if ( isset( self::$buffers[ $key ] ) ) return;
        self::$buffers[ $key ] = ob_get_level();
        ob_start();
    }

    private static function end( string $key ): void {
        if ( ! isset( self::$buffers[ $key ] ) ) return;
        $level = self::$buffers[ $key ];
        unset( self::$buffers[ $key ] );
        while ( ob_get_level() > $level ) ob_end_clean();
    }

    public static function begin_member_header(): void { if ( self::member_front() ) self::begin( 'member_header' ); }
    public static function end_member_header(): void { self::end( 'member_header' ); }
    public static function begin_member_body(): void { if ( self::member_front() ) self::begin( 'member_body' ); }
    public static function end_member_body(): void { self::end( 'member_body' ); }
    public static function begin_group_header(): void { if ( self::group_front() ) self::begin( 'group_header' ); }
    public static function end_group_header(): void { self::end( 'group_header' ); }
    public static function begin_group_body(): void { if ( self::group_front() ) self::begin( 'group_body' ); }
    public static function end_group_body(): void { self::end( 'group_body' ); }
}
