<?php
namespace ZinCelestial\BuddyX\Community;
defined( 'ABSPATH' ) || exit;

/** Stage 6B Group Command Hub foundation. */
final class GroupCommandHub {
    private static bool $rendered = false;
    public static function register(): void {
        add_filter( 'body_class', array( self::class, 'body_classes' ), 46 );
        add_action( 'bp_after_group_header', array( self::class, 'render' ), 20 );
        add_action( 'wp_enqueue_scripts', array( self::class, 'enqueue' ), 46 );
    }
    private static function enabled(): bool {
        $settings = function_exists( 'zcbx_settings' ) ? (array) zcbx_settings() : array();
        return ! empty( $settings['group_command_hub_enabled'] );
    }
    private static function is_group_front(): bool {
        if ( ! self::enabled() || ! function_exists( 'bp_is_group' ) || ! bp_is_group() ) return false;
        if ( function_exists( 'bp_is_group_home' ) ) return (bool) bp_is_group_home();
        $action = function_exists( 'bp_current_action' ) ? (string) bp_current_action() : '';
        return '' === $action || 'home' === $action;
    }
    public static function body_classes( array $classes ): array {
        if ( self::is_group_front() ) $classes[] = 'zcbx-group-command-hub-active';
        return $classes;
    }
    public static function enqueue(): void {
        if ( ! self::enabled() || ! function_exists( 'bp_is_group' ) || ! bp_is_group() ) return;
        $path = ZCBX_PATH . 'assets/group-command-hub.css';
        wp_enqueue_style( 'zcbx-group-command-hub', ZCBX_URL . 'assets/group-command-hub.css', array(), is_readable( $path ) ? (string) filemtime( $path ) : ZCBX_VERSION );
    }
    public static function render(): void {
        if ( self::$rendered || ! self::is_group_front() || ! function_exists( 'groups_get_current_group' ) ) return;
        $group = groups_get_current_group();
        if ( empty( $group->id ) ) return;
        self::$rendered = true;
        $group_id = (int) $group->id;
        $name = isset( $group->name ) ? (string) $group->name : '';
        $description = function_exists( 'bp_get_group_description_excerpt' ) ? (string) bp_get_group_description_excerpt( $group ) : '';
        $permalink = function_exists( 'bp_get_group_permalink' ) ? (string) bp_get_group_permalink( $group ) : '';
        $members = function_exists( 'groups_get_total_member_count' ) ? (int) groups_get_total_member_count( $group_id ) : 0;
        $avatar = function_exists( 'bp_core_fetch_avatar' ) ? bp_core_fetch_avatar( array( 'item_id'=>$group_id, 'object'=>'group', 'type'=>'full', 'width'=>104, 'height'=>104, 'alt'=>sprintf( esc_attr__( 'Group avatar for %s', 'zincelestial-buddyx' ), $name ) ) ) : '';
        echo '<section class="zcbx-group-command-hub" aria-labelledby="zcbx-group-command-hub-title">';
        echo '<div class="zcbx-group-command-hub__identity">';
        if ( $avatar ) echo '<div class="zcbx-group-command-hub__avatar">' . wp_kses_post( $avatar ) . '</div>';
        echo '<div><span class="zcbx-group-command-hub__eyebrow">' . esc_html__( 'Group Command Hub', 'zincelestial-buddyx' ) . '</span>';
        echo '<h2 id="zcbx-group-command-hub-title">' . esc_html( $name ) . '</h2>';
        if ( $description ) echo '<p>' . wp_kses_post( $description ) . '</p>';
        echo '</div></div>';
        echo '<div class="zcbx-group-command-hub__metrics" aria-label="' . esc_attr__( 'Group overview', 'zincelestial-buddyx' ) . '">';
        echo '<a href="' . esc_url( trailingslashit( $permalink . 'members' ) ) . '"><strong>' . esc_html( number_format_i18n( $members ) ) . '</strong><span>' . esc_html__( 'Members', 'zincelestial-buddyx' ) . '</span></a>';
        echo '<a href="' . esc_url( trailingslashit( $permalink . 'activity' ) ) . '"><strong aria-hidden="true">&#10022;</strong><span>' . esc_html__( 'Activity', 'zincelestial-buddyx' ) . '</span></a>';
        echo '</div>';
        echo '<nav class="zcbx-group-command-hub__actions" aria-label="' . esc_attr__( 'Group command shortcuts', 'zincelestial-buddyx' ) . '">';
        echo '<a href="' . esc_url( $permalink ) . '">' . esc_html__( 'Group overview', 'zincelestial-buddyx' ) . '</a>';
        echo '<a href="' . esc_url( trailingslashit( $permalink . 'activity' ) ) . '">' . esc_html__( 'Group activity', 'zincelestial-buddyx' ) . '</a>';
        echo '<a href="' . esc_url( trailingslashit( $permalink . 'members' ) ) . '">' . esc_html__( 'Group members', 'zincelestial-buddyx' ) . '</a>';
        echo '</nav></section>';
        do_action( 'zcbx_group_command_hub_after', $group_id );
    }
}
