<?php
namespace ZinCelestial\BuddyX\Community;
defined( 'ABSPATH' ) || exit;

/**
 * Stage 6C Community Layout Framework foundation.
 *
 * Adds a coordinated presentation layer through native BuddyPress wrappers.
 * No BuddyPress template files, URLs, permissions, actions, or content are replaced.
 */
final class CommunityLayoutFramework {
    public static function register(): void {
        add_filter( 'body_class', array( self::class, 'body_classes' ), 50 );
        add_action( 'wp_enqueue_scripts', array( self::class, 'enqueue' ), 50 );
    }

    private static function enabled(): bool {
        $settings = function_exists( 'zcbx_settings' ) ? (array) zcbx_settings() : array();
        return ! empty( $settings['community_layout_enabled'] );
    }

    private static function is_community(): bool {
        if ( ! self::enabled() || ! function_exists( 'buddypress' ) ) return false;
        return function_exists( 'is_buddypress' ) && is_buddypress();
    }

    public static function body_classes( array $classes ): array {
        if ( self::is_community() ) $classes[] = 'zcbx-community-layout-framework';
        return $classes;
    }

    public static function enqueue(): void {
        if ( ! self::is_community() ) return;
        wp_enqueue_style( 'zcbx-community-layout-framework', ZCBX_URL . 'assets/community-layout-framework.css', array(), ZCBX_VERSION );
    }
}
