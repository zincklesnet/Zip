<?php
namespace ZinCelestial\BuddyX\Community;
defined( 'ABSPATH' ) || exit;

final class CommandHubWidgets {
    public static function register(): void {
        add_action( 'widgets_init', array( self::class, 'widgets' ) );
        add_action( 'wp_enqueue_scripts', array( self::class, 'assets' ) );
    }
    public static function widgets(): void {
        register_widget( MemberSummaryWidget::class );
        register_widget( MemberActivityWidget::class );
        register_widget( MemberConnectionsWidget::class );
        register_widget( MemberGroupsWidget::class );
        register_widget( GroupSummaryWidget::class );
        register_widget( ContextStatusWidget::class );
    }
    public static function assets(): void {
        if ( ! function_exists( 'bp_is_user' ) || ( ! bp_is_user() && ! bp_is_group() ) ) return;
        $path = ZCBX_PATH . 'assets/command-hub-widgets.css';
        wp_enqueue_style( 'zcbx-command-hub-widgets', ZCBX_URL . 'assets/command-hub-widgets.css', array(), is_readable( $path ) ? (string) filemtime( $path ) : ZCBX_VERSION );
    }
}

abstract class CommandHubWidget extends \WP_Widget {
    protected function title( array $instance, string $fallback ): string { return ! empty( $instance['title'] ) ? (string) $instance['title'] : $fallback; }
    public function form( $instance ): void {
        $title = isset( $instance['title'] ) ? (string) $instance['title'] : '';
        echo '<p><label for="' . esc_attr( $this->get_field_id( 'title' ) ) . '">' . esc_html__( 'Title:', 'zincelestial-buddyx' ) . '</label>';
        echo '<input class="widefat" id="' . esc_attr( $this->get_field_id( 'title' ) ) . '" name="' . esc_attr( $this->get_field_name( 'title' ) ) . '" type="text" value="' . esc_attr( $title ) . '"></p>';
    }
    public function update( $new, $old ): array { return array( 'title' => sanitize_text_field( $new['title'] ?? '' ) ); }
    protected function open( array $args, string $title ): void { echo $args['before_widget']; if ( $title ) echo $args['before_title'] . esc_html( $title ) . $args['after_title']; echo '<div class="zcbx-command-widget">'; }
    protected function close( array $args ): void { echo '</div>' . $args['after_widget']; }
    protected function item( string $label, string $value, string $url = '' ): void {
        $content = '<span class="zcbx-command-widget__label">' . esc_html( $label ) . '</span><strong class="zcbx-command-widget__value">' . esc_html( $value ) . '</strong>';
        echo $url ? '<a class="zcbx-command-widget__item" href="' . esc_url( $url ) . '">' . $content . '</a>' : '<span class="zcbx-command-widget__item">' . $content . '</span>';
    }
}

final class MemberSummaryWidget extends CommandHubWidget {
    public function __construct(){ parent::__construct('zcbx-member-summary',__('ZinCelestial: Member Summary','zincelestial-buddyx'),array('description'=>__('Real member profile summary for Member Command Hub regions.','zincelestial-buddyx'))); }
    public function widget($args,$instance): void { if(!function_exists('bp_is_user')||!bp_is_user())return; $id=(int)bp_displayed_user_id(); $this->open($args,$this->title($instance,__('Member Summary','zincelestial-buddyx'))); echo get_avatar($id,72,'',get_the_author_meta('display_name',$id),array('class'=>'zcbx-command-widget__avatar')); echo '<p class="zcbx-command-widget__name">'.esc_html(bp_core_get_user_displayname($id)).'</p>'; $this->item(__('Last active','zincelestial-buddyx'),function_exists('bp_get_last_activity')?strip_tags(bp_get_last_activity($id)):__('Available','zincelestial-buddyx')); $this->close($args); }
}
final class MemberActivityWidget extends CommandHubWidget {
    public function __construct(){ parent::__construct('zcbx-member-activity',__('ZinCelestial: Member Activity','zincelestial-buddyx'),array('description'=>__('Member activity count and shortcut.','zincelestial-buddyx'))); }
    public function widget($args,$instance): void { if(!function_exists('bp_is_user')||!bp_is_user())return; $id=(int)bp_displayed_user_id(); $count=function_exists('bp_activity_total_favorites_for_user')?(int)bp_activity_total_favorites_for_user($id):0; $url=trailingslashit(bp_displayed_user_domain()).(function_exists('bp_get_activity_slug')?bp_get_activity_slug():'activity'); $this->open($args,$this->title($instance,__('Activity','zincelestial-buddyx'))); $this->item(__('Activity favorites','zincelestial-buddyx'),(string)$count,$url); $this->close($args); }
}
final class MemberConnectionsWidget extends CommandHubWidget {
    public function __construct(){ parent::__construct('zcbx-member-connections',__('ZinCelestial: Member Connections','zincelestial-buddyx'),array('description'=>__('BuddyPress friendship total and shortcut.','zincelestial-buddyx'))); }
    public function widget($args,$instance): void { if(!function_exists('bp_is_user')||!bp_is_user())return; $id=(int)bp_displayed_user_id(); $count=function_exists('friends_get_total_friend_count')?(int)friends_get_total_friend_count($id):0; $url=trailingslashit(bp_displayed_user_domain()).(function_exists('bp_get_friends_slug')?bp_get_friends_slug():'friends'); $this->open($args,$this->title($instance,__('Connections','zincelestial-buddyx'))); $this->item(__('Friends','zincelestial-buddyx'),(string)$count,$url); $this->close($args); }
}
final class MemberGroupsWidget extends CommandHubWidget {
    public function __construct(){ parent::__construct('zcbx-member-groups',__('ZinCelestial: Member Groups','zincelestial-buddyx'),array('description'=>__('BuddyPress group membership total and shortcut.','zincelestial-buddyx'))); }
    public function widget($args,$instance): void { if(!function_exists('bp_is_user')||!bp_is_user())return; $id=(int)bp_displayed_user_id(); $count=function_exists('groups_total_groups_for_user')?(int)groups_total_groups_for_user($id):0; $url=trailingslashit(bp_displayed_user_domain()).(function_exists('bp_get_groups_slug')?bp_get_groups_slug():'groups'); $this->open($args,$this->title($instance,__('Groups','zincelestial-buddyx'))); $this->item(__('Memberships','zincelestial-buddyx'),(string)$count,$url); $this->close($args); }
}
final class GroupSummaryWidget extends CommandHubWidget {
    public function __construct(){ parent::__construct('zcbx-group-summary',__('ZinCelestial: Group Summary','zincelestial-buddyx'),array('description'=>__('Real BuddyPress group summary for Group Command Hub regions.','zincelestial-buddyx'))); }
    public function widget($args,$instance): void { if(!function_exists('bp_is_group')||!bp_is_group())return; $group=groups_get_current_group(); if(empty($group->id))return; $this->open($args,$this->title($instance,__('Group Summary','zincelestial-buddyx'))); echo bp_core_fetch_avatar(array('item_id'=>$group->id,'object'=>'group','type'=>'thumb','class'=>'zcbx-command-widget__avatar')); echo '<p class="zcbx-command-widget__name">'.esc_html($group->name).'</p>'; $this->item(__('Members','zincelestial-buddyx'),(string)(int)$group->total_member_count,bp_get_group_permalink($group).'members/'); $this->close($args); }
}
final class ContextStatusWidget extends CommandHubWidget {
    public function __construct(){ parent::__construct('zcbx-context-status',__('ZinCelestial: Community Status','zincelestial-buddyx'),array('description'=>__('Context-aware member or group visibility status.','zincelestial-buddyx'))); }
    public function widget($args,$instance): void { if(!function_exists('bp_is_user'))return; $this->open($args,$this->title($instance,__('Community Status','zincelestial-buddyx'))); if(bp_is_user()){ $id=(int)bp_displayed_user_id(); $this->item(__('Profile','zincelestial-buddyx'),bp_core_get_user_displayname($id)); $this->item(__('Visibility','zincelestial-buddyx'),__('Member profile','zincelestial-buddyx')); } elseif(bp_is_group()){ $g=groups_get_current_group(); $status=!empty($g->status)?ucfirst($g->status):__('Group','zincelestial-buddyx'); $this->item(__('Group visibility','zincelestial-buddyx'),$status); } $this->close($args); }
}
