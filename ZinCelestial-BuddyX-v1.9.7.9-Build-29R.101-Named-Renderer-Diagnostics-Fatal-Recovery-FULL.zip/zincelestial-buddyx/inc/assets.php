<?php
defined('ABSPATH') || exit;

function zcbx_register_assets() {
    add_action('wp_enqueue_scripts', 'zcbx_assets', 30);
}

function zcbx_assets() {
    $parent = wp_get_theme(get_template());
    $settings = zcbx_settings();

    wp_enqueue_style('buddyx-parent', get_template_directory_uri() . '/style.css', array(), $parent->get('Version'));
    wp_enqueue_style('zcbx-header', ZCBX_URL . 'assets/header.css', array('buddyx-parent'), ZCBX_VERSION);
    wp_enqueue_style('zcbx-header-nav', ZCBX_URL . 'assets/header-nav.css', array('zcbx-header'), ZCBX_VERSION);
    wp_enqueue_style('zcbx-subheader-removal', ZCBX_URL . 'assets/subheader-removal.css', array('zcbx-header-nav'), ZCBX_VERSION);

    if (!empty($settings['light_foundation'])) {
        wp_enqueue_style('zcbx-light', ZCBX_URL . 'assets/light.css', array('zcbx-header-nav'), ZCBX_VERSION);
    }

    $is_buddypress = function_exists('is_buddypress') && is_buddypress();
    if (!empty($settings['community_layout_enabled']) && $is_buddypress) {
        wp_enqueue_style('zcbx-community-layout-framework', ZCBX_URL . 'assets/community-layout-framework.css', array('zcbx-header-nav'), ZCBX_VERSION);
        wp_enqueue_style('zcbx-activity-communication-foundation', ZCBX_URL . 'assets/activity-communication-foundation.css', array('zcbx-community-layout-framework'), ZCBX_VERSION);
        add_filter('body_class', 'zcbx_community_layout_body_class');
    }

    if (!empty($settings['profile_header_enabled']) && 'native' !== $settings['profile_header_layout'] && function_exists('zcbx_is_member_page') && zcbx_is_member_page()) {
        wp_enqueue_style('zcbx-profile-header', ZCBX_URL . 'assets/profile-header.css', array('zcbx-header'), ZCBX_VERSION);
        wp_enqueue_style('zcbx-profile-experience', ZCBX_URL . 'assets/profile-experience.css', array('zcbx-profile-header'), ZCBX_VERSION);
        wp_enqueue_script('zcbx-profile-experience', ZCBX_URL . 'assets/profile-experience.js', array(), ZCBX_VERSION, true);
        wp_localize_script('zcbx-profile-experience', 'ZCBX_PLATFORM', $settings);
    }
}

function zcbx_community_layout_body_class($classes) {
    $classes[] = 'zcbx-community-layout-enabled';
    return array_values(array_unique($classes));
}
