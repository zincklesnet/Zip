<?php
namespace ZinCelestial\BuddyX\Core;
defined( 'ABSPATH' ) || exit;
final class Bootstrap {
 private const LEGACY=array('settings','save-engine','assets','header-nav','profile-header','platform','refinement-runtime','admin','sidebar-system-removal');
 public static function boot():void{require_once ZCBX_PATH.'inc/Core/Autoloader.php';Autoloader::register();foreach(self::LEGACY as $m){$f=ZCBX_PATH.'inc/'.$m.'.php';if(is_readable($f))require_once $f;}add_action('after_setup_theme',array(self::class,'setup'),30);}
 public static function setup():void{
  load_child_theme_textdomain('zincelestial-buddyx',ZCBX_PATH.'languages');add_theme_support('responsive-embeds');add_theme_support('align-wide');add_theme_support('woocommerce');
  \ZinCelestial\BuddyX\Settings\MigrationRunner::run();
  \ZinCelestial\BuddyX\DesignSystem\Runtime::register();\ZinCelestial\BuddyX\DesignSystem\SignatureIconRuntime::register();
  if(is_callable('zcbx_register_assets'))zcbx_register_assets();if(is_callable('zcbx_register_header_navigation'))zcbx_register_header_navigation();
  \ZinCelestial\BuddyX\Community\ProfileHeader::register();\ZinCelestial\BuddyX\Community\BuddyPressServices::register();\ZinCelestial\BuddyX\Community\MemberDirectoryExperience::register();\ZinCelestial\BuddyX\Community\MemberCommandHub::register();\ZinCelestial\BuddyX\Community\GroupCommandHub::register();\ZinCelestial\BuddyX\Community\CommandFrontPageOwnership::register();\ZinCelestial\BuddyX\Community\CommandPageHeader::register();\ZinCelestial\BuddyX\Community\AdvancedSideMenus::register();\ZinCelestial\BuddyX\Community\FrontPageRegions::register();\ZinCelestial\BuddyX\Community\CommandHubAppearance::register();\ZinCelestial\BuddyX\Community\CommunityLayoutFramework::register();\ZinCelestial\BuddyX\Community\CommandHubWidgets::register();\ZinCelestial\BuddyX\Admin\CommunityExperiencePage::register();\ZinCelestial\BuddyX\Admin\AdvancedSideMenusPage::register();\ZinCelestial\BuddyX\Admin\NavigationIconControls::register();\ZinCelestial\BuddyX\Platform\Runtime::register();\ZinCelestial\BuddyX\Compatibility\PluginAdapters::register();\ZinCelestial\BuddyX\Compatibility\IntegrationRegistry::register_defaults();\ZinCelestial\BuddyX\Compatibility\WooCommerceServices::register();\ZinCelestial\BuddyX\Compatibility\WooCommerce\Marketplaces\MarketplaceAdapterRegistry::register();\ZinCelestial\BuddyX\Core\DashboardWidgetRegistry::register_defaults();\ZinCelestial\BuddyX\Core\ModuleRegistry::boot();\ZinCelestial\BuddyX\Admin\Controller::register();do_action('zcbx_booted');
 }
}
