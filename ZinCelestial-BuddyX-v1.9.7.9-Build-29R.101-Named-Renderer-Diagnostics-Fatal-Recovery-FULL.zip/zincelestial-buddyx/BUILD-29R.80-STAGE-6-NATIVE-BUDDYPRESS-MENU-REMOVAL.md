# Build 29R.80: Stage 6 Native BuddyPress Menu Removal

- Version: 1.9.6.0
- Baseline: `ZinCelestial-BuddyX-v1.9.5.9-Build-29R.79-Stage-6-Native-Widget-Area-Removal-FULL.zip`
- Package: `ZinCelestial-BuddyX-v1.9.6.0-Build-29R.80-Stage-6-Native-BuddyPress-Menu-Removal-FULL.zip`
- Removes native BuddyPress member/group menus only on owned Command front pages.
- Preserves Command Header shortcuts and other BuddyPress screens.
- Stage 6 remains active.
- Stage 7 is not started.
- Settings schema remains Version 1.
- Validation remains request-only.
