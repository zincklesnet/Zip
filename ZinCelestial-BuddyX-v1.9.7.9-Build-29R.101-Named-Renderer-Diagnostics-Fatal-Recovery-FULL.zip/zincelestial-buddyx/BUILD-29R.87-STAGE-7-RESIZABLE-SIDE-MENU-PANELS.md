# Build 29R.87: Stage 7 Resizable Side Menu Panels

- Version: 1.9.7.2
- Baseline: `ZinCelestial-BuddyX-v1.9.7.1-Build-29R.86-Stage-7-Accordion-Nested-Menu-Groups-FULL.zip`
- Package: `ZinCelestial-BuddyX-v1.9.7.2-Build-29R.87-Stage-7-Resizable-Side-Menu-Panels-FULL.zip`
- Adds independent 240–520 pixel desktop panel resizing.
- Saves widths locally per browser and per side.
- Adds pointer and keyboard resizing.
- Mobile widths remain fixed and responsive.
- Stage 7 remains active and incomplete.
- Stage 6 Command pages remain protected and permanently boxed.
- Settings schema remains Version 1.
- Validation remains request-only.
