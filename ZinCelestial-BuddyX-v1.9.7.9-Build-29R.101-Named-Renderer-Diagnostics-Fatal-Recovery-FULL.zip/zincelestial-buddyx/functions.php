<?php
defined( 'ABSPATH' ) || exit;
if(!defined('ZCBX_VERSION'))define('ZCBX_VERSION','1.9.7.9');
if(!defined('ZCBX_PATH'))define('ZCBX_PATH',trailingslashit(get_stylesheet_directory()));
if(!defined('ZCBX_URL'))define('ZCBX_URL',trailingslashit(get_stylesheet_directory_uri()));
$bootstrap=ZCBX_PATH.'inc/Core/Bootstrap.php';
if(is_readable($bootstrap)){require_once $bootstrap;\ZinCelestial\BuddyX\Core\Bootstrap::boot();}
unset($bootstrap);

