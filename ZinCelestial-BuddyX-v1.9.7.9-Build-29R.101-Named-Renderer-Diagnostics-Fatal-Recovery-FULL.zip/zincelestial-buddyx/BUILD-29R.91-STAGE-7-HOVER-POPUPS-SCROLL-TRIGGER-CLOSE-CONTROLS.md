# Build 29R.91: Stage 7 Hover Popups, Scroll, Trigger, and Close Controls

- Version: 1.9.7.6
- Baseline: `ZinCelestial-BuddyX-v1.9.7.5-Build-29R.90-Stage-7-Menu-Item-Hover-Open-Control-Cleanup-FULL.zip`
- Package: `ZinCelestial-BuddyX-v1.9.7.6-Build-29R.91-Stage-7-Hover-Popups-Scroll-Trigger-Close-Controls-FULL.zip`
- Adds configurable accessible popup cards for menu items.
- Fixes page scrolling while a menu is expanded through an enabled-by-default option.
- Adds top trigger offset and five trigger presets.
- Adds adaptive close-control sizing.
- Preserves Build 29R.90 hover and expanded-control behavior.
- Stage 7 remains active and incomplete.
- Main settings schema remains Version 1.
- Validation remains request-only.
