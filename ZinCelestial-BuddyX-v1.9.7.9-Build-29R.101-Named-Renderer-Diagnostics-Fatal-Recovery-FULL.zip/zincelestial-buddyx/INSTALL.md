# Install ZinCelestial-BuddyX 1.9.7.6 Build 29R.91

Complete package based on `ZinCelestial-BuddyX-v1.9.7.5-Build-29R.90-Stage-7-Menu-Item-Hover-Open-Control-Cleanup-FULL.zip`. Configure all new controls separately for Left and Right under Appearance > Advanced Side Menus.

Package: `ZinCelestial-BuddyX-v1.9.7.6-Build-29R.91-Stage-7-Hover-Popups-Scroll-Trigger-Close-Controls-FULL.zip`

# Install ZinCelestial-BuddyX 1.9.7.5 Build 29R.90

Complete package based on `ZinCelestial-BuddyX-v1.9.7.4-Build-29R.89-Stage-7-Side-Menu-Administration-Style-Presets-FULL.zip`. Configure hover styles and open-state control visibility in Appearance > Advanced Side Menus.

Package: `ZinCelestial-BuddyX-v1.9.7.5-Build-29R.90-Stage-7-Menu-Item-Hover-Open-Control-Cleanup-FULL.zip`

# Install ZinCelestial-BuddyX 1.9.7.4 Build 29R.89

Complete package based on `ZinCelestial-BuddyX-v1.9.7.3-Build-29R.88-Stage-7-Side-Menu-Runtime-Isolation-Recovery-FULL.zip`. Configure presentation in Appearance > Advanced Side Menus and continue assigning menu links in Appearance > Menus. Existing assignments remain intact.

Package: `ZinCelestial-BuddyX-v1.9.7.4-Build-29R.89-Stage-7-Side-Menu-Administration-Style-Presets-FULL.zip`

# Install ZinCelestial-BuddyX 1.9.7.3 Build 29R.88

Complete recovery package based on `ZinCelestial-BuddyX-v1.9.7.2-Build-29R.87-Stage-7-Resizable-Side-Menu-Panels-FULL.zip`. Existing assigned Advanced Side Menus remain assigned; no menu recreation is required.

Package: `ZinCelestial-BuddyX-v1.9.7.3-Build-29R.88-Stage-7-Side-Menu-Runtime-Isolation-Recovery-FULL.zip`

# Install ZinCelestial-BuddyX 1.9.7.2 Build 29R.87

Complete package based on `ZinCelestial-BuddyX-v1.9.7.1-Build-29R.86-Stage-7-Accordion-Nested-Menu-Groups-FULL.zip`. Assigned Advanced Side Menus gain desktop resize handles automatically; saved widths are local to each browser.

Package: `ZinCelestial-BuddyX-v1.9.7.2-Build-29R.87-Stage-7-Resizable-Side-Menu-Panels-FULL.zip`

# Install ZinCelestial-BuddyX 1.9.7.1 Build 29R.86

Complete package based on `ZinCelestial-BuddyX-v1.9.7.0-Build-29R.85-Stage-7-Advanced-Side-Menus-Foundation-FULL.zip`. Existing assigned Advanced Side Menus automatically gain accordion controls for parent items with children.

Package: `ZinCelestial-BuddyX-v1.9.7.1-Build-29R.86-Stage-7-Accordion-Nested-Menu-Groups-FULL.zip`

# Install ZinCelestial-BuddyX 1.9.7.0 Build 29R.85

Complete package based on `ZinCelestial-BuddyX-v1.9.6.4-Build-29R.84-Stage-6-Final-Reconciliation-FULL.zip`. Assign menus to `ZinCelestial Advanced Side Menu: Left` and/or `ZinCelestial Advanced Side Menu: Right`; unassigned locations do not render a panel or toggle.

Package: `ZinCelestial-BuddyX-v1.9.7.0-Build-29R.85-Stage-7-Advanced-Side-Menus-Foundation-FULL.zip`

# Install ZinCelestial-BuddyX 1.9.6.4 Build 29R.84

Complete reconciliation package based on `ZinCelestial-BuddyX-v1.9.6.3-Build-29R.83-Stage-6-Edge-to-Edge-Mapped-Command-Cover-FULL.zip`. Existing Command menus, covers, widget assignments, and schema Version 1 settings remain preserved.

Package: `ZinCelestial-BuddyX-v1.9.6.4-Build-29R.84-Stage-6-Final-Reconciliation-FULL.zip`

# Install ZinCelestial-BuddyX 1.9.6.3 Build 29R.83

Complete package based on `ZinCelestial-BuddyX-v1.9.6.2-Build-29R.82-Stage-6-Dedicated-Command-Header-Foundation-FULL.zip`. Configure the three independent Command menu locations in WordPress menu management; no global menu links are copied automatically.

Package: `ZinCelestial-BuddyX-v1.9.6.3-Build-29R.83-Stage-6-Edge-to-Edge-Mapped-Command-Cover-FULL.zip`

# Install ZinCelestial-BuddyX 1.9.6.2 Build 29R.82

Complete package based on `ZinCelestial-BuddyX-v1.9.6.1-Build-29R.81-Stage-6-Permanent-Boxed-Command-Layout-FULL.zip`. Assign optional menus to the three new Command Header locations under WordPress menu management. Empty Command menu locations remain empty and do not copy global menu links.

Package: `ZinCelestial-BuddyX-v1.9.6.2-Build-29R.82-Stage-6-Dedicated-Command-Header-Foundation-FULL.zip`

# Install ZinCelestial-BuddyX 1.9.6.1 Build 29R.81

Complete package based on `ZinCelestial-BuddyX-v1.9.6.0-Build-29R.80-Stage-6-Native-BuddyPress-Menu-Removal-FULL.zip`. This build permanently enforces boxed Member and Group Command pages without changing saved assignments or schema Version 1.

Package: `ZinCelestial-BuddyX-v1.9.6.1-Build-29R.81-Stage-6-Permanent-Boxed-Command-Layout-FULL.zip`

# Install ZinCelestial-BuddyX 1.9.6.0 Build 29R.80

Complete package based on `ZinCelestial-BuddyX-v1.9.5.9-Build-29R.79-Stage-6-Native-Widget-Area-Removal-FULL.zip`. This build removes native BuddyPress menus from owned Command front pages without changing other BuddyPress screens, saved assignments, or schema Version 1.

Package: `ZinCelestial-BuddyX-v1.9.6.0-Build-29R.80-Stage-6-Native-BuddyPress-Menu-Removal-FULL.zip`

# Install ZinCelestial-BuddyX 1.9.5.9 Build 29R.79

Complete package based on `ZinCelestial-BuddyX-v1.9.5.8-Build-29R.78-Stage-6-Command-Frontpage-Ownership-Foundation-FULL.zip`. This build removes residual native and theme widget areas from owned Command front pages without changing saved assignments or schema Version 1.

Package: `ZinCelestial-BuddyX-v1.9.5.9-Build-29R.79-Stage-6-Native-Widget-Area-Removal-FULL.zip`

# Install ZinCelestial-BuddyX 1.9.5.8 Build 29R.78

Complete package based on `ZinCelestial-BuddyX-v1.9.5.6-Build-29R.76-Stage-6-Command-Hub-Widget-Region-Recovery-FULL.zip`. This build establishes ZinCelestial Command ownership of member/group front pages while preserving BuddyPress-connected data, permissions, navigation, actions, and schema Version 1.

Package: `ZinCelestial-BuddyX-v1.9.5.8-Build-29R.78-Stage-6-Command-Frontpage-Ownership-Foundation-FULL.zip`

# Install ZinCelestial-BuddyX 1.9.5.6 Build 29R.76

Complete recovery package based on `ZinCelestial-BuddyX-v1.9.5.5-Build-29R.75-Stage-6-Native-Header-Region-Recovery-FULL.zip`. This build corrects the Command Hub region settings accessor without changing saved widget assignments or settings schema Version 1.

Package: `ZinCelestial-BuddyX-v1.9.5.6-Build-29R.76-Stage-6-Command-Hub-Widget-Region-Recovery-FULL.zip`

# Install ZinCelestial-BuddyX 1.9.5.5 Build 29R.75

Complete recovery package based on `ZinCelestial-BuddyX-v1.9.5.2-Build-29R.72-Stage-6-Responsive-Accessibility-Coverage-FULL.zip`. This build moves Member and Group Command Hubs to native BuddyPress after-header hooks and corrects independent asset loading without changing schema Version 1.

Package: `ZinCelestial-BuddyX-v1.9.5.5-Build-29R.75-Stage-6-Native-Header-Region-Recovery-FULL.zip`

# Install ZinCelestial-BuddyX 1.9.5.2 Build 29R.72

Complete theme package based on `ZinCelestial-BuddyX-v1.9.5.1-Build-29R.71-Roadmap-Dark-Mode-Widget-Platform-Reconciliation-FULL.zip`. This build adds responsive and accessibility implementation coverage to existing Stage 6 Command Hub surfaces without changing schema Version 1.

Package: `ZinCelestial-BuddyX-v1.9.5.2-Build-29R.72-Stage-6-Responsive-Accessibility-Coverage-FULL.zip`

# Install ZinCelestial-BuddyX 1.9.5.1 Build 29R.71

This is a complete theme package built from `ZinCelestial-BuddyX-v1.9.5.0-Build-29R.70-Stage-6-Command-Hub-Widget-Expansion-Foundation-FULL.zip`. It appends future roadmap Stages 32 and 33 without changing Stage 6 runtime behavior. Settings schema Version 1 and the standard WordPress/BuddyX Customizer are preserved.

Package: `ZinCelestial-BuddyX-v1.9.5.1-Build-29R.71-Roadmap-Dark-Mode-Widget-Platform-Reconciliation-FULL.zip`

# Build 29R.70 Stage 6 Command Hub Widget Expansion Foundation

- Version: 1.9.5.0
- Build: 29R.70
- Package: `ZinCelestial-BuddyX-v1.9.5.0-Build-29R.70-Stage-6-Command-Hub-Widget-Expansion-Foundation-FULL.zip`
- Baseline: complete Build 29R.69 package
- Settings schema: 1, unchanged

## Scope

- Adds real-data Member Summary, Member Activity, Member Connections, Member Groups, Group Summary, and Community Status widgets.
- Widgets are designed for the existing Member and Group Command Hub primary and secondary regions.
- Preserves native BuddyPress permissions, URLs, data, and fallback behavior.
- Reuses existing ZinCelestial surfaces and design tokens.
- Stage 6 remains active and incomplete.

No live, installation, visual, or accessibility validation was performed.
