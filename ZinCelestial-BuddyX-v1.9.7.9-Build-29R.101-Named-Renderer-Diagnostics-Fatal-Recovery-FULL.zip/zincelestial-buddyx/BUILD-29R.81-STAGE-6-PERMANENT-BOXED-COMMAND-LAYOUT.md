# Build 29R.81: Stage 6 Permanent Boxed Command Layout

- Version: 1.9.6.1
- Baseline: `ZinCelestial-BuddyX-v1.9.6.0-Build-29R.80-Stage-6-Native-BuddyPress-Menu-Removal-FULL.zip`
- Package: `ZinCelestial-BuddyX-v1.9.6.1-Build-29R.81-Stage-6-Permanent-Boxed-Command-Layout-FULL.zip`
- Member and Group Command pages are boxed permanently.
- Full-width Command layouts are unsupported.
- Boxed ownership covers the Command header and both widget regions.
- Stage 6 remains active.
- Stage 7 is not started.
- Settings schema remains Version 1.
- Validation remains request-only.
